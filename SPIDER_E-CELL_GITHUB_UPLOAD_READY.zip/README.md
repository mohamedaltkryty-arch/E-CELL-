# SPIDER E-CELL — Android APK

مشروع Android لتشغيل واجهة Spider الأصلية مع نواة E-CELL Python داخل التطبيق عبر Chaquopy. لا يحتاج Termux بعد تثبيت التطبيق.

## البناء التلقائي

يحتوي جذر المستودع على الحزمة المصدرية `SPIDER_E-CELL_GITHUB_UPLOAD.zip` وملف GitHub Actions. عند كل Push إلى `main`، يستخرج Workflow ملفات المشروع من الحزمة، يفحص Python والاختبارات، ثم ينفذ `assembleDebug` ويتحقق من اسم الحزمة ويحسب SHA-256.

بعد نجاح التشغيل: افتح **Actions** ثم أحدث تشغيل **Build SPIDER E-CELL APK** ثم نزّل Artifact باسم `SPIDER-E-CELL-debug-apk`، وفك ضغطه وثبّت `app-debug.apk`.

## مواصفات البناء

- Application ID: `com.spider.ecell`
- Version: `1.2.1` (versionCode 121)
- minSdk 24، compileSdk/targetSdk 35
- JDK 17، Gradle 8.13، Android Gradle Plugin 8.13.2
- Chaquopy 17.2.0 وPython 3.11
- ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`

## التشغيل والخصوصية

قاعدة البيانات والذاكرة داخل مساحة التطبيق الخاصة. ميزة البحث على الإنترنت تحتاج اتصالاً. الناتج الحالي Debug وموقّع بمفتاح debug الخاص ببيئة GitHub Actions؛ صالح للتثبيت والاختبار، أما النشر الدائم فيحتاج مفتاح توقيع خاصاً.
