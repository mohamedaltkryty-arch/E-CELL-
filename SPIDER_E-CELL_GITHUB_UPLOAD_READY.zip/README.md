# SPIDER E-CELL — Android

A single Android app that preserves the existing Spider interface and runs the E-CELL Python core through Chaquopy. Local database, memory, and project files remain in app-private storage; Termux is not required after installation.

## DeepSeek Harness integration

The source now includes a Harness SDK JSON-RPC 2.0 bridge (`stdin/stdout`), local API routes, Android Keystore-backed credential storage, a pinned on-demand Ubuntu/Node rootfs installer, and a PRoot launcher. The original Spider UI stylesheet is preserved.

Harness-specific requirements are ARM64 (`arm64-v8a`) and Android 8.0/API 26+. The base app retains minSdk 24, but the Harness feature is disabled on unsupported devices. Initial installation downloads an approximately 408MB compressed Ubuntu/Node/Harness rootfs and needs additional free space for extraction and SDK package setup.

Chat commands: `/harness help`, `/harness setup`, `/harness install`, `/harness status`, `/harness init`, `/harness ask <prompt>`, `/harness wait`, `/harness stop`, and `/harness remove-key`. The default DeepSeek route is `deepseek-official` with `deepseek-v4-flash`. The API key is encrypted at rest using Android Keystore.

The rootfs is downloaded on demand, not embedded in the base APK. The installer pins the manifest size/SHA-256 and the rootfs size/SHA-256, restricts download redirects, validates archive paths/link targets, and extracts without `tarfile.extractall`. CI obtains the ARM64 PRoot and loader from the community Android v0.3.7 release, verifies the source APK and each extracted ELF hash, then packages them in the Spider APK. At runtime, the app proves that Android can actually execute PRoot/loader rather than trusting mode bits alone.

## Validation status

Run `PYTHONPATH=app/src/main/python python -m unittest discover -s tests -v`. The tests cover the JSON-RPC transport, safe rootfs extraction, digest validation, and native staging/probes. They do not replace an on-device Android test. This source should not be described as a verified working APK until Android CI succeeds and `/harness install`, `/harness init`, and a real agent request have passed on an ARM64 phone.

## Build

Android Gradle Plugin 8.13.2, Chaquopy 17.2.0, Python 3.11, compile/target SDK 35, minSdk 24. GitHub Actions validates Python, stages the pinned native PRoot files, builds `assembleDebug`, and checks the native ARM64 entries in the output APK.

See `THIRD_PARTY_NOTICES.md` for PRoot/loader provenance, hashes, and GPL/AGPL obligations. Never commit API keys or private app data.
