# THIRD-PARTY NOTICES — SPIDER E-CELL Harness integration

This project uses a separately built Android PRoot runner and loader extracted from the DeepSeek Harness Android community release `v0.3.7` (`https://github.com/dphmoblie/deepseek-harness-android`). The community app is MIT-licensed; the imported native ELF files have separate upstream provenance and license obligations and are not covered solely by the community app's MIT license.

| APK entry | Upstream artifact | SHA-256 | License/provenance |
|---|---|---|---|
| `lib/arm64-v8a/libdsh_proot.so` | `app-release.apk` → `liboperit_proot.so` (renamed) | `cb40a1ced11cee76569b4008a9e478c87883ce831152be4eb9570763b82e580d` | PRoot GPL-2.0-or-later; built using Operit2 Android runtime tooling |
| `lib/arm64-v8a/libdsh_proot_loader.so` | `app-release.apk` → `liboperit_loader.so` (renamed) | `f149774236db1e69b36cc1e4ed3866c7094db2eee52da0d4956aa63a9bb26929` | PRoot GPL-2.0-or-later; built using Operit2 Android runtime tooling |

The imported PRoot source/build provenance is Operit2 commit `dc4c3a9405dc7ed3ef69b2ac9a6ace65374d77cf`, particularly `tools/android-runtime/`, which pins Termux PRoot v5.1.107.78 and applies `tools/android-runtime/patches/termux-proot-operit-android.patch`: `https://github.com/AAswordman/Operit2/tree/dc4c3a9405dc7ed3ef69b2ac9a6ace65374d77cf/tools/android-runtime`. Operit2 is licensed under AGPL-3.0; PRoot source headers permit GPL-2.0-or-later. Keep all corresponding notices and provide the complete corresponding source, including this exact upstream commit, patch, and build instructions, when distributing the native binaries. Upstream Android release source archive: `https://github.com/dphmoblie/deepseek-harness-android/releases/download/v0.3.7/corresponding-source.tar.gz` (SHA-256 `799d518dc2305b2e18cc0191cc94b7128366594a3b78a6c5cf72e127b200e642`).

DeepSeek Harness itself is MIT-licensed and its official source is `https://github.com/deepseek-ai/deepseek-harness`. The on-demand rootfs is obtained from the v0.3.7 community Android release and contains Ubuntu 24.04 ARM64, Node.js, Harness and transitive packages. Each component keeps its own license and notices; the compressed rootfs is not included in the base APK. If the rootfs is redistributed or embedded, include the complete package-level Ubuntu/Node/npm license inventory and corresponding source obligations for the exact contents.

This file records the known imported artifacts and is not a full transitive SBOM. Before public redistribution, generate a complete inventory for the precise Android APK and rootfs, include full GPL/AGPL license texts and source-offer information, and review all Ubuntu and npm package notices. No secret API credentials or user data are part of the source bundle.
