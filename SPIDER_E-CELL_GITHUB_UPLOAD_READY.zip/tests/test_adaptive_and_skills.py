import gzip
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from spider import database, adaptive, skill_runtime, learning
from spider.brain import LocalBrain


class AdaptiveSkillTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_dir, self.old_path = database.DATA_DIR, database.DB_PATH
        self.old_learning_dir = learning.DATA_DIR
        database.DATA_DIR = Path(self.tmp.name)
        database.DB_PATH = Path(self.tmp.name) / "test.sqlite3"
        learning.DATA_DIR = Path(self.tmp.name)
        database.init_db()

    def tearDown(self):
        database.DATA_DIR, database.DB_PATH = self.old_dir, self.old_path
        learning.DATA_DIR = self.old_learning_dir
        self.tmp.cleanup()

    def test_feedback_trains_and_persists_compact_intent_model(self):
        for prompt in (
            "احسب مجموع رقمين بسرعة", "كم يساوي 5 ضرب 7", "أوجد ناتج القسمة",
            "نفذ عملية جمع حسابية", "احسب النسبة المئوية",
        ):
            adaptive.add_example(prompt, "الإجابة الحسابية الصحيحة", "math")
        for prompt in (
            "ابن تطبيق هاتف جديد", "أنشئ موقع ويب متكامل", "برمج لعبة ثنائية الأبعاد",
            "طوّر مشروع Python", "صمم تطبيق Android",
        ):
            adaptive.add_example(prompt, "متطلبات البناء والخطوات", "build")
        prediction = adaptive.predict("احسب ناتج ضرب 9 في 4")
        self.assertIsNotNone(prediction)
        self.assertEqual(prediction["intent"], "math")
        self.assertEqual(prediction["examples"], 10)
        status = adaptive.status()
        self.assertEqual(status["examples"], 10)
        self.assertGreater(status["model_bytes"], 0)
        self.assertTrue((Path(self.tmp.name) / "models" / "adaptive_intent.json.gz").exists())

    def test_local_brain_reuses_user_approved_answer_for_similar_chat(self):
        adaptive.add_example(
            "كيف أرتب ملفات المشروع في Termux على الهاتف",
            "أنشئ مجلداً للمصدر ومجلداً للبيانات، ثم احفظ نسخة احتياطية قبل التحديث.",
            "chat",
        )
        response = LocalBrain().respond({"message": "كيف أنظم ملفات المشروع في Termux على هاتفي"})
        self.assertIn("إجابة مسترجعة من تصحيح سابق", response["answer"])
        self.assertIn("نسخة احتياطية", response["answer"])
        self.assertTrue(response["learned_corrections"])

    def test_feedback_examples_are_retrievable_as_local_experience(self):
        adaptive.add_example("كيف أحسب مساحة مستطيل", "المساحة تساوي الطول مضروباً في العرض", "math")
        hits = adaptive.retrieve_corrections("احسب مساحة المستطيل")
        self.assertTrue(hits)
        self.assertIn("الطول", hits[0]["correction"])

    def test_native_skill_executes_only_whitelisted_steps(self):
        created = skill_runtime.create_skill(
            "عداد كلمات", "تنظيف النص وحساب الكلمات",
            [
                {"id": "clean", "op": "text.strip", "from": "input.text"},
                {"id": "lower", "op": "text.lower", "from": "clean"},
                {"id": "count", "op": "text.word_count", "from": "lower"},
            ], output="count")
        result = skill_runtime.execute_skill(created["id"], {"text": "  Spider E-Cell builds skills  "})
        self.assertEqual(result["result"], 5)
        self.assertEqual(result["steps_completed"], 3)

    def test_skill_runtime_rejects_arbitrary_code_and_network_ops(self):
        with self.assertRaises(ValueError):
            skill_runtime.validate_manifest({"name": "unsafe", "steps": [
                {"id": "x", "op": "python.exec", "from": "input"}
            ]})
        with self.assertRaises(ValueError):
            skill_runtime.validate_manifest({"name": "unsafe", "steps": [
                {"id": "x", "op": "http.get", "from": "input"}
            ]})

    def test_runtime_rejects_catastrophic_regex(self):
        with self.assertRaises(ValueError):
            skill_runtime._run_op("text.regex_extract", "a" * 1000 + "!", {"pattern": "(a+)+$"})

    def test_json_and_csv_native_operations(self):
        manifest = {
            "name": "CSV columns", "steps": [
                {"id": "parsed", "op": "csv.summary", "from": "input.csv"}
            ], "output": "parsed"
        }
        result = skill_runtime.execute_manifest(manifest, {"csv": "name,age\nAli,20\nSara,22"})
        self.assertEqual(result["result"]["rows"], 2)
        self.assertEqual(result["result"]["headers"], ["name", "age"])

    def test_python_api_extraction_is_static_and_safe(self):
        source = '''\n"""sample"""\ndef add(a: int, b: int = 1):\n    """Add two numbers."""\n    return a + b\nclass Calculator:\n    def multiply(self, x, y):\n        return x * y\n'''
        symbols = learning._extract_python_api("src/math.py", source)
        names = {x["name"] for x in symbols}
        self.assertEqual(names, {"add", "Calculator"})
        self.assertIn("Add two numbers", next(x["doc"] for x in symbols if x["name"] == "add"))
        self.assertTrue(any(x.startswith("multiply(") for x in next(x["methods"] for x in symbols if x["name"] == "Calculator")))

    def test_github_spider_skill_manifest_becomes_runnable(self):
        meta = {"full_name": "octocat/native-skill", "private": False, "default_branch": "main",
                "html_url": "https://github.com/octocat/native-skill", "description": "Native sample",
                "license": {"spdx_id": "MIT"}}
        dsl = json.dumps({"name": "Word count", "description": "Count input words", "steps": [
            {"id": "count", "op": "text.word_count", "from": "input.text"}
        ], "output": "count"})
        tree = {"truncated": False, "tree": [
            {"type": "blob", "path": "README.md", "size": 55},
            {"type": "blob", "path": "SPIDER_SKILL.json", "size": len(dsl)},
            {"type": "blob", "path": "src/math.py", "size": 60},
        ]}
        def fake_fetch(url, **kwargs):
            if "SPIDER_SKILL.json" in url:
                body = dsl
            elif "README.md" in url:
                body = "# Native sample\nA Spider compatible word count skill."
            else:
                body = 'def sum_values(a, b):\n    """Sum two numeric values."""\n    return a + b\n'
            return body.encode(), "text/plain", "utf-8", url, {}
        with patch.object(learning, "_github_json", side_effect=[(meta, {}), (tree, {})]), \
             patch.object(learning, "_fetch", side_effect=fake_fetch):
            result = learning.import_github("https://github.com/octocat/native-skill")
        self.assertEqual(result["runtime"], "spider-dsl-v1")
        run = skill_runtime.execute_skill(result["skill"], {"text": "hello local spider"})
        self.assertEqual(run["result"], 3)
        listed = learning.list_skills()
        self.assertTrue(listed[0]["can_run"])
        import sqlite3
        con = sqlite3.connect(database.DB_PATH)
        try:
            blob = con.execute("SELECT manifest_gzip FROM skills WHERE id=?", (result["skill"],)).fetchone()[0]
        finally:
            con.close()
        manifest = json.loads(gzip.decompress(blob).decode())
        self.assertTrue(manifest["api_symbols"])


    def test_uploaded_zip_with_spider_descriptor_is_native_skill(self):
        import base64, io, zipfile
        buf = io.BytesIO()
        descriptor = json.dumps({"name": "Text length", "steps": [
            {"id": "size", "op": "text.length", "from": "input.text"}
        ], "output": "size"})
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("project/SPIDER_SKILL.json", descriptor)
            z.writestr("project/README.md", "A Spider-native skill descriptor for text length.")
        result = learning.learn_uploaded_archive("length-skill.zip", base64.b64encode(buf.getvalue()).decode())
        self.assertEqual(result["runtime"], "spider-dsl-v1")
        out = skill_runtime.execute_skill(result["skill"], {"text": "Spider E-CELL"})
        self.assertEqual(out["result"], 13)

    def test_duplicate_feedback_updates_existing_training_example(self):
        a = adaptive.add_example("احسب 2 + 2", "الناتج أربعة", "math")
        b = adaptive.add_example("احسب 2 + 2", "الناتج يساوي أربعة", "math")
        self.assertEqual(a["id"], b["id"])
        self.assertEqual(adaptive.count_examples(), 1)
        hits = adaptive.retrieve_corrections("احسب 2 + 2")
        self.assertIn("يساوي", hits[0]["correction"])

    def test_ast_compiler_translates_pure_python_string_function(self):
        source = '''
def normalize_text(value):
    """Normalize text using common whitespace and case rules."""
    return value.strip().lower()
'''
        compiled = learning._compile_python_function("src/text.py", source)
        self.assertIsNotNone(compiled)
        self.assertEqual(compiled["translation"], "safe-ast-subset")
        result = skill_runtime.execute_manifest(compiled["manifest"], {"value": "  SPIDER   E-CELL  "})
        self.assertEqual(result["result"], "spider   e-cell")

    def test_python_split_without_separator_matches_python_whitespace_semantics(self):
        source = '''
def words(value):
    return value.split()
'''
        compiled = learning._compile_python_function("src/words.py", source)
        result = skill_runtime.execute_manifest(compiled["manifest"], {"value": "  spider\t e-cell\nlocal "})
        self.assertEqual(result["result"], ["spider", "e-cell", "local"])

    def test_python_str_builtin_is_stringified_not_returned_as_raw_value(self):
        source = '''
def to_text(value):
    return str(value)
'''
        compiled = learning._compile_python_function("src/stringify.py", source)
        result = skill_runtime.execute_manifest(compiled["manifest"], {"value": {"a": 1}})
        self.assertEqual(result["result"], '{"a":1}')

    def test_github_import_auto_compiles_supported_pure_python_function(self):
        meta = {"full_name": "octocat/compact-tool", "private": False, "default_branch": "main",
                "html_url": "https://github.com/octocat/compact-tool", "description": "Compact utility",
                "license": {"spdx_id": "MIT"}}
        tree = {"truncated": False, "tree": [
            {"type": "blob", "path": "README.md", "size": 50},
            {"type": "blob", "path": "src/normalize.py", "size": 100},
        ]}
        def fake_fetch(url, **kwargs):
            body = "# Compact tool\nA tiny pure text normalization helper." if "README.md" in url else \
                   'def normalize(value):\n    """Normalize whitespace and case."""\n    return value.strip().lower()\n'
            return body.encode(), "text/plain", "utf-8", url, {}
        with patch.object(learning, "_github_json", side_effect=[(meta, {}), (tree, {})]), \
             patch.object(learning, "_fetch", side_effect=fake_fetch):
            imported = learning.import_github("https://github.com/octocat/compact-tool")
        self.assertEqual(imported["runtime"], "spider-dsl-v1")
        self.assertIn("حوّل Spider الدالة النقية normalize", imported["note"])
        result = skill_runtime.execute_skill(imported["skill"], {"value": "  SPIDER  "})
        self.assertEqual(result["result"], "spider")

    def test_generic_github_skill_stays_reference_only(self):
        meta = {"full_name": "octocat/reference", "private": False, "default_branch": "main",
                "html_url": "https://github.com/octocat/reference", "description": "Reference sample",
                "license": None}
        tree = {"truncated": False, "tree": [
            {"type": "blob", "path": "README.md", "size": 60},
            {"type": "blob", "path": "src/lib.py", "size": 60},
        ]}
        def fake_fetch(url, **kwargs):
            body = "# Reference\nThis project contains a sample Python utility." if "README.md" in url else \
                   'def normalize(value):\n    """Normalize a value."""\n    import hashlib\n    return hashlib.md5(value.encode()).hexdigest()\n'
            return body.encode(), "text/plain", "utf-8", url, {}
        with patch.object(learning, "_github_json", side_effect=[(meta, {}), (tree, {})]), \
             patch.object(learning, "_fetch", side_effect=fake_fetch):
            result = learning.import_github("https://github.com/octocat/reference")
        self.assertEqual(result["runtime"], "reference-only")
        self.assertGreaterEqual(result["api_symbols"], 1)
        with self.assertRaises(ValueError):
            skill_runtime.execute_skill(result["skill"], {})


if __name__ == "__main__":
    unittest.main()
