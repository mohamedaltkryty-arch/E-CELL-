import hashlib
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPIDER = ROOT / "app" / "src" / "main" / "python" / "spider"
HTML = SPIDER / "static" / "index.html"

class FrontendIntegrityTests(unittest.TestCase):
    def test_original_spider_stylesheet_is_unchanged(self):
        html = HTML.read_text(encoding="utf-8")
        css = html.split("<style>", 1)[1].split("</style>", 1)[0]
        design = json.loads((ROOT / "DESIGN_PRESERVATION.json").read_text(encoding="utf-8"))
        self.assertEqual(hashlib.sha256(css.encode()).hexdigest(), design["css_sha256"])
        self.assertEqual(len(css.encode()), design["css_bytes"])

    def test_frontend_has_no_remote_ai_provider_and_uses_local_gateway(self):
        html = HTML.read_text(encoding="utf-8").lower()
        for forbidden in ("claude", "chat/completions", "openai.com", "anthropic.com"):
            self.assertNotIn(forbidden, html)
        self.assertIn("/api/brain/chat", html)
        self.assertIn("/api/state", html)
        self.assertIn("/api/cells", html)
        self.assertIn("/api/github/import", html)
        self.assertIn("/api/learning/search", html)

    def test_spider_tabs_and_ecell_controls_are_present(self):
        html = HTML.read_text(encoding="utf-8")
        for label in ("محادثة", "الذاكرة", "العناكب", "الإضافات", "المزيد", "شبكة E-CELL", "إنشاء خلية"):
            self.assertIn(label, html)
        self.assertIn("serviceWorker.register('/sw.js')", html)

    def test_worker_is_isolated_and_networkless(self):
        worker = (SPIDER / "static" / "extension-worker.js").read_text(encoding="utf-8")
        for api in ("fetch", "XMLHttpRequest", "WebSocket", "EventSource", "importScripts", "indexedDB"):
            self.assertIn("self." + api + " = undefined", worker)
        sw = (SPIDER / "static" / "sw.js").read_text(encoding="utf-8")
        self.assertIn("if (url.origin !== self.location.origin) return", sw)

if __name__ == "__main__":
    unittest.main()
