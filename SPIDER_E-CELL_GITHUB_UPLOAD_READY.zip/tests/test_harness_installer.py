import gzip
import hashlib
import io
import json
import os
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from spider import harness_installer as installer


def make_tar_gz(entries):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for name, kind, value, mode in entries:
            info = tarfile.TarInfo(name)
            info.mode = mode
            if kind == "dir":
                info.type = tarfile.DIRTYPE
                archive.addfile(info)
            elif kind == "file":
                payload = value if isinstance(value, bytes) else value.encode("utf-8")
                info.size = len(payload)
                archive.addfile(info, io.BytesIO(payload))
            elif kind == "symlink":
                info.type = tarfile.SYMTYPE
                info.linkname = value
                archive.addfile(info)
            elif kind == "hardlink":
                info.type = tarfile.LNKTYPE
                info.linkname = value
                archive.addfile(info)
    return output.getvalue()


class HarnessInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write_archive(self, raw):
        path = self.root / "rootfs.tar.gz"
        path.write_bytes(raw)
        return path

    def test_extracts_files_and_rebases_absolute_symlink_into_rootfs(self):
        entries = [
            (".", "dir", "", 0o755),
            ("bin", "dir", "", 0o755),
            ("usr/local/bin", "dir", "", 0o755),
            ("bin/sh", "file", "#!/bin/sh\necho ok\n", 0o755),
            ("usr/local/bin/dsh", "file", "#!/bin/sh\nexit 0\n", 0o755),
            ("usr/bin/sh", "symlink", "/bin/sh", 0o777),
            ("usr/local/bin/dsh-link", "symlink", "dsh", 0o777),
            ("usr/local/bin/dsh-hard", "hardlink", "usr/local/bin/dsh", 0o777),
        ]
        archive = self.write_archive(make_tar_gz(entries))
        stage = self.root / "stage"
        expected = sum(len(x[2] if isinstance(x[2], bytes) else x[2].encode()) for x in entries if x[1] == "file")
        self.assertEqual(installer.extract_rootfs(archive, stage, expected), expected)
        self.assertEqual((stage / "usr/local/bin/dsh").read_text(), "#!/bin/sh\nexit 0\n")
        self.assertTrue(os.access(stage / "usr/local/bin/dsh", os.X_OK))
        self.assertTrue((stage / "usr/bin/sh").is_symlink())
        self.assertEqual((stage / "usr/bin/sh").resolve(), (stage / "bin/sh").resolve())
        self.assertEqual((stage / "usr/local/bin/dsh-link").read_text(), "#!/bin/sh\nexit 0\n")
        self.assertEqual((stage / "usr/local/bin/dsh-hard").read_text(), "#!/bin/sh\nexit 0\n")

    def test_rejects_traversal_and_removes_partial_stage(self):
        archive = self.write_archive(make_tar_gz([("../escape", "file", "bad", 0o644)]))
        stage = self.root / "stage"
        with self.assertRaises(installer.HarnessInstallError) as raised:
            installer.extract_rootfs(archive, stage, 3)
        self.assertEqual(raised.exception.code, "ARCHIVE_PATH_INVALID")
        self.assertFalse(stage.exists())
        self.assertFalse((self.root / "escape").exists())

    def test_rejects_duplicate_archive_entries(self):
        archive = self.write_archive(make_tar_gz([
            ("usr/bin/a", "file", "x", 0o644),
            ("usr/bin/a", "file", "y", 0o644),
        ]))
        stage = self.root / "stage"
        with self.assertRaises(installer.HarnessInstallError) as raised:
            installer.extract_rootfs(archive, stage, 2)
        self.assertEqual(raised.exception.code, "ARCHIVE_DUPLICATE_ENTRY")

    def test_rejects_symlink_that_escapes_rootfs(self):
        archive = self.write_archive(make_tar_gz([("usr/bin/out", "symlink", "../../../../outside", 0o777)]))
        stage = self.root / "stage"
        with self.assertRaises(installer.HarnessInstallError) as raised:
            installer.extract_rootfs(archive, stage, 0)
        self.assertEqual(raised.exception.code, "ARCHIVE_LINK_INVALID")

    def test_fails_closed_when_directory_symlinks_are_unavailable(self):
        rootfs = self.root / "rootfs"
        rootfs.mkdir()
        target = rootfs / "usr" / "bin"
        target.mkdir(parents=True)
        (target / "tool").write_text("#!/bin/sh\nexit 0\n")
        with patch.object(installer.os, "symlink", side_effect=OSError(13, "denied")):
            with self.assertRaises(installer.HarnessInstallError) as raised:
                installer._copy_link_fallback(rootfs / "bin", target, rootfs)
        self.assertEqual(raised.exception.code, "ROOTFS_SYMLINK_UNAVAILABLE")

    def test_parse_manifest_pins_architecture_compression_and_entrypoint(self):
        raw = json.dumps({
            "schemaVersion": 1,
            "runtimeId": "dsh-android-arm64",
            "version": "0.3.7",
            "architecture": "arm64-v8a",
            "rootfs": {
                "url": "https://github.com/dphmoblie/deepseek-harness-android/releases/download/v0.3.7/rootfs.bundle",
                "sha256": "a" * 64,
                "compressedBytes": 4096,
                "extractedBytes": 8192,
                "compression": "gzip",
            },
            "entrypoints": {
                "harness": ["/usr/local/bin/dsh", "web", "--host", "127.0.0.1", "--port", "4173"],
            },
        }, separators=(",", ":")).encode()
        with patch.object(installer, "MANIFEST_BYTES", len(raw)), patch.object(installer, "MANIFEST_SHA256", hashlib.sha256(raw).hexdigest()):
            manifest = installer._parse_runtime_manifest(raw)
        self.assertEqual(manifest["version"], "0.3.7")
        self.assertEqual(manifest["harnessArgv"][-1], "4173")

    def test_manifest_rejects_non_gzip_payload(self):
        raw = json.dumps({
            "schemaVersion": 1,
            "runtimeId": "dsh-android-arm64",
            "version": "0.3.7",
            "architecture": "arm64-v8a",
            "rootfs": {
                "url": "https://github.com/dphmoblie/deepseek-harness-android/releases/download/v0.3.7/rootfs.bundle",
                "sha256": "a" * 64,
                "compressedBytes": 4096,
                "extractedBytes": 8192,
                "compression": "xz",
            },
            "entrypoints": {"harness": ["/usr/local/bin/dsh", "web", "--host", "127.0.0.1", "--port", "4173"]},
        }, separators=(",", ":")).encode()
        with patch.object(installer, "MANIFEST_BYTES", len(raw)), patch.object(installer, "MANIFEST_SHA256", hashlib.sha256(raw).hexdigest()):
            with self.assertRaises(installer.HarnessInstallError) as raised:
                installer._parse_runtime_manifest(raw)
        self.assertEqual(raised.exception.code, "ARCHIVE_COMPRESSION_UNSUPPORTED")

    def test_redirects_are_restricted_to_pinned_release_hosts(self):
        handler = installer._PinnedRedirectHandler()
        request = installer.urllib.request.Request("https://github.com/example/release")
        with self.assertRaises(installer.HarnessInstallError):
            handler.redirect_request(request, None, 302, "Found", {}, "https://evil.example/payload")


if __name__ == "__main__":
    unittest.main()
