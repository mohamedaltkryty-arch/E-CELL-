import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from spider import database
from spider import learning
from spider.brain import LocalBrain


class LearningTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_dir, self.old_path, self.old_learning_dir = database.DATA_DIR, database.DB_PATH, learning.DATA_DIR
        database.DATA_DIR = Path(self.tmp.name)
        database.DB_PATH = Path(self.tmp.name) / "test.sqlite3"
        learning.DATA_DIR = Path(self.tmp.name)
        database.init_db()

    def tearDown(self):
        database.DATA_DIR, database.DB_PATH, learning.DATA_DIR = self.old_dir, self.old_path, self.old_learning_dir
        self.tmp.cleanup()

    def test_search_parser_extracts_result(self):
        html = '''<div class="result results_links"><div class="result__body"><h2><a class="result__a" href="https://docs.python.org/3/">Python Docs</a></h2><a class="result__snippet">Official language documentation</a></div></div>'''
        parser = learning._SearchParser()
        parser.feed(html)
        self.assertEqual(len(parser.results), 1)
        self.assertIn("Python Docs", parser.results[0]["title"])
        self.assertEqual(parser.results[0]["url"], "https://docs.python.org/3/")

    def test_github_url_parsing_repo_and_file(self):
        self.assertEqual(learning._github_parts("https://github.com/octocat/Hello-World"),
                         ("octocat", "Hello-World", "", ""))
        self.assertEqual(learning._github_parts("https://github.com/octocat/Hello-World/blob/main/src/app.py"),
                         ("octocat", "Hello-World", "main", "src/app.py"))
        self.assertEqual(learning._github_parts("https://github.com/octocat/demo/tree/feature%2Fv2/src"),
                         ("octocat", "demo", "feature/v2", "src"))

    def test_reject_non_github_or_non_https(self):
        with self.assertRaises(ValueError):
            learning._github_parts("http://github.com/a/b")
        with self.assertRaises(ValueError):
            learning._github_parts("https://example.com/a/b")

    def test_private_network_target_rejected(self):
        with self.assertRaises(ValueError):
            learning._fetch("https://127.0.0.1/admin")

    def test_public_hostname_resolving_to_private_ip_rejected(self):
        import socket
        private_answer = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.4.0.8", 443))]
        with patch.object(learning.socket, "getaddrinfo", return_value=private_answer):
            with self.assertRaises(ValueError):
                learning._validate_remote_url("https://example.org/redirect")

    def test_public_hostname_resolution_is_accepted(self):
        import socket
        public_answer = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))]
        with patch.object(learning.socket, "getaddrinfo", return_value=public_answer):
            self.assertEqual(learning._validate_remote_url("https://example.org/docs"), "example.org")

    def test_long_skill_is_chunked_and_tail_remains_searchable(self):
        body = ("architecture retrieval index mobile software engineering\n" * 900)
        body += "ZEBRA_UNIQUE_FINAL_COMPONENT_IMPLEMENTATION"
        result = learning.learn_uploaded_file("long-skill.md", body)
        self.assertGreater(result["bytes_learned"], 9_000)
        hits = LocalBrain().search_index("ZEBRA_UNIQUE_FINAL_COMPONENT_IMPLEMENTATION")
        self.assertTrue(hits)
        self.assertTrue(any("part-" in hit["source"] for hit in hits))

    def test_uploaded_file_becomes_persistent_compressed_skill(self):
        result = learning.learn_uploaded_file("demo.py", "def add(a, b):\n    return a + b\n\nThis function adds two values.")
        self.assertEqual(result["files_learned"], 1)
        self.assertEqual(learning.status()["skills"], 1)
        self.assertEqual(learning.status()["skill_files"], 1)
        hits = LocalBrain().search_index("function adds values")
        self.assertTrue(hits)
        self.assertIn("def add", hits[0]["body"])
        skill_dir = Path(self.tmp.name) / "skills" / result["skill"]
        self.assertTrue((skill_dir / "SKILL.md").is_file())
        self.assertFalse((skill_dir / "sources").exists())

    def test_github_import_indexes_readme_and_sources_without_execution(self):
        meta = {"full_name": "octocat/demo", "private": False, "default_branch": "main",
                "html_url": "https://github.com/octocat/demo", "description": "Tiny sample",
                "license": {"spdx_id": "MIT"}}
        tree = {"truncated": False, "sha": "abc", "tree": [
            {"type": "blob", "path": "README.md", "size": 50},
            {"type": "blob", "path": "src/math.py", "size": 55},
        ]}
        def fake_fetch(url, **kwargs):
            body = "# Demo skill\n\nTiny sample arithmetic library." if "README.md" in url else "def plus(a, b):\n    return a + b\n\n# arithmetic operation"
            return body.encode(), "text/plain", "utf-8", url, {}
        with patch.object(learning, "_github_json", side_effect=[(meta, {}), (tree, {})]), \
             patch.object(learning, "_fetch", side_effect=fake_fetch):
            result = learning.import_github("https://github.com/octocat/demo")
        self.assertEqual(result["files_learned"], 2)
        self.assertEqual(learning.status()["skills"], 1)
        hits = LocalBrain().search_index("arithmetic operation plus")
        self.assertTrue(hits)
        self.assertIn("plus", hits[0]["body"])
        self.assertIn("لم يتم تثبيت أو تشغيل", result["note"])

    def test_zip_archive_extracts_safe_text_files(self):
        import base64
        import io
        import zipfile
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("project/README.md", "# Archive sample\n\nA small reusable module for text processing.")
            z.writestr("project/main.py", "def normalize_text(value):\n    return value.strip().lower()\n")
            z.writestr("../escape.py", "should not be extracted")
            z.writestr("project/image.bin", b"\x00\x01\x02")
        result = learning.learn_uploaded_archive("sample.zip", base64.b64encode(buf.getvalue()).decode())
        self.assertEqual(result["files_learned"], 2)
        self.assertEqual(learning.status()["skills"], 1)
        hits = LocalBrain().search_index("normalize text strip lower")
        self.assertTrue(hits)
        self.assertIn("normalize_text", hits[0]["body"])

    def test_search_result_is_saved_and_indexed(self):
        learning.save_source("https://docs.python.org/3/", "Python Docs",
                             "Official documentation for the Python language", "search", "")
        self.assertEqual(learning.status()["sources"], 1)
        self.assertEqual(len(learning.search_sources("Python")), 1)

    def test_startup_reindexes_saved_memories_and_user_messages_without_networking_them(self):
        database.save_state({
            "mem": [{"id": "memory-1", "content": "A reusable local memory about mobile interface architecture", "tags": ["mobile", "architecture"]}],
            "convs": [{"id": "conversation-1", "msgs": [
                {"role": "user", "content": "Explain how to build a resilient local database for Android applications"},
                {"role": "assistant", "content": "Assistant-generated text is excluded from the re-indexer."}
            ]}]
        })
        with patch.object(learning, "search_web", return_value=[]):
            result = learning.startup_sync()
        self.assertGreaterEqual(result["local_docs"], 2)
        hits = LocalBrain().search_index("resilient local database Android")
        self.assertTrue(hits)
        self.assertTrue(any("conversation:conversation-1:user:0" == x["source"] for x in hits))
        self.assertFalse(any("assistant" in x["source"] for x in hits))


if __name__ == "__main__":
    unittest.main()
