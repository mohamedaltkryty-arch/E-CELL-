import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from spider import harness_native


class HarnessNativeStagingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.native = self.root / "apk-lib"
        self.native.mkdir()
        self.data = self.root / "app-data"
        self.data.mkdir()
        self.files = {
            "libdsh_proot.so": b"#!/bin/sh\nexit 0\n",
            "libdsh_proot_loader.so": b"#!/bin/sh\nexit 0\n",
        }
        self.digests = {}
        for name, value in self.files.items():
            path = self.native / name
            path.write_bytes(value)
            path.chmod(0o755)
            self.digests[name] = hashlib.sha256(value).hexdigest()

    def tearDown(self):
        self.temp.cleanup()

    def test_prefers_apk_backed_symlinks_and_records_exec_probes(self):
        with patch.dict(harness_native.PINNED_NATIVE, self.digests, clear=True):
            result = harness_native.stage_native_runtime(str(self.native), str(self.data))
        self.assertTrue(result["available"])
        self.assertTrue(Path(result["runner"]).is_symlink())
        self.assertTrue(Path(result["loader"]).is_symlink())
        marker = json.loads((self.data / "harness" / "native-runtime.json").read_text())
        self.assertIn("apk-symlink:started", marker["runnerProbe"])
        self.assertIn("apk-symlink:started", marker["loaderProbe"])
        self.assertEqual(marker["nativeLibraryDirectory"], str(self.native.resolve()))

    def test_falls_back_to_private_copy_only_after_symlink_denial(self):
        real_symlink = os.symlink
        def reject_symlink(source, destination):
            if ".link-" in str(destination):
                raise PermissionError("symlink denied")
            return real_symlink(source, destination)
        with patch.dict(harness_native.PINNED_NATIVE, self.digests, clear=True), patch.object(
            harness_native.os, "symlink", side_effect=reject_symlink
        ):
            result = harness_native.stage_native_runtime(str(self.native), str(self.data))
        self.assertTrue(result["available"])
        self.assertIn("private-copy:started", result["runnerProbe"])
        self.assertFalse(Path(result["runner"]).is_symlink())

    def test_rejects_hash_mismatch_before_staging(self):
        wrong = {name: "0" * 64 for name in self.files}
        with patch.dict(harness_native.PINNED_NATIVE, wrong, clear=True):
            with self.assertRaises(RuntimeError):
                harness_native.stage_native_runtime(str(self.native), str(self.data))

    def test_missing_arm64_libraries_is_reported_not_assumed_available(self):
        empty = self.root / "empty"
        empty.mkdir()
        result = harness_native.stage_native_runtime(str(empty), str(self.data))
        self.assertFalse(result["available"])
        self.assertEqual(result["reason"], "arm64-native-runtime-not-packaged")


if __name__ == "__main__":
    unittest.main()
