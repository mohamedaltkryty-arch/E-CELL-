import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from spider.harness_sandbox import SANDBOX_RUNNER_SCRIPT, sandbox_provider_patch


class HarnessSandboxTests(unittest.TestCase):
    def test_landlock_shell_adapter_passes_shell_syntax_check(self):
        shell = shutil.which("sh")
        if shell is None:
            self.skipTest("POSIX shell is unavailable")
        with tempfile.TemporaryDirectory() as directory:
            script = Path(directory) / "sandbox-runner.sh"
            script.write_text(SANDBOX_RUNNER_SCRIPT, encoding="utf-8")
            result = subprocess.run([shell, "-n", str(script)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_overlay_targets_the_exact_sandbox_plugin_id(self):
        patch = sandbox_provider_patch()
        self.assertEqual(len(patch), 1)
        self.assertEqual(patch[0]["id"], "sandbox")
        config = patch[0]["config"]
        self.assertEqual(config["runnerCommand"], ["/bin/sh", "/root/.dsh-mobile/sandbox-runner.sh"])
        self.assertEqual(config["runnerFailureSignatures"], ["dsh-sandbox-runner: "])
        self.assertEqual(json.loads(json.dumps(patch))[0]["id"], "sandbox")

    def test_adapter_fails_closed_for_unknown_bwrap_arguments(self):
        self.assertIn('*) fail "unsupported argument: $argument" ;;', SANDBOX_RUNNER_SCRIPT)
        self.assertIn('exec "$LAUNCHER" $GRANT_ARGS -- "$@"', SANDBOX_RUNNER_SCRIPT)


if __name__ == "__main__":
    unittest.main()
