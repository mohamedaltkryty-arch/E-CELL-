import json
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path

from spider import database
from spider.brain import LocalBrain, safe_math, detect_intent, retrieve_memories
from spider.server import LocalServer, SpiderHandler

class LocalCoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_dir, self.old_path = database.DATA_DIR, database.DB_PATH
        database.DATA_DIR = Path(self.tmp.name)
        database.DB_PATH = Path(self.tmp.name) / "test.sqlite3"
        database.init_db()
        self.brain = LocalBrain()

    def tearDown(self):
        database.DATA_DIR, database.DB_PATH = self.old_dir, self.old_path
        self.tmp.cleanup()

    def test_seed_cells_exist(self):
        codes = {c["code"] for c in database.list_cells()}
        self.assertTrue({"CORE", "BRAIN", "MEMORY", "PLANNER", "ANALYZER", "BUILDER"}.issubset(codes))

    def test_dynamic_cell_create_and_pause(self):
        cell = database.create_cell("RESEARCH", "خلية البحث", "تحليل مصادر محلية")
        self.assertEqual(cell["code"], "RESEARCH")
        self.assertEqual(database.set_cell_status(cell["id"], "paused")["status"], "paused")

    def test_math_is_safe(self):
        self.assertEqual(safe_math("احسب 125 × 8 + 4"), 1004)
        self.assertIsNone(safe_math("احسب __import__('os').system('id')"))

    def test_intent_and_memory_retrieval(self):
        self.assertEqual(detect_intent("ضع خطة لبناء تطبيق"), "plan")
        mem = [{"id": "1", "content": "مشروع Spider يعمل محلياً على Android", "tags": ["Spider"]}]
        self.assertEqual(retrieve_memories("Spider Android محلي", mem)[0]["id"], "1")

    def test_local_chat_routes_into_cell(self):
        out = self.brain.respond({"message": "ضع خطة لبناء تطبيق محلي", "history": [], "memories": []})
        self.assertEqual(out["intent"], "plan")
        self.assertEqual(out["cell_id"], "planner")
        self.assertIn("خطة العمل", out["answer"])
        self.assertEqual(database.stats()["tasks"], 1)

    def test_custom_cell_can_receive_matching_work(self):
        cell = database.create_cell("RESEARCH", "خلية البحث", "بحث وتحليل البيانات المحلية")
        out = self.brain.respond({"message": "حلل بحث البيانات المحلية", "history": [], "memories": []})
        self.assertEqual(out["cell_id"], cell["id"])

    def test_dynamic_cell_limit_is_resource_bounded(self):
        limit = database.dynamic_cell_limit()
        self.assertGreaterEqual(limit, 64)
        self.assertLessEqual(limit, 8192)

    def test_local_index_is_built_and_retrieved(self):
        result = self.brain.index_local_data([{"source": "memory", "content": "Spider E-CELL memory cell local Android project"}])
        self.assertEqual(result["indexed_documents"], 1)
        hits = self.brain.search_index("Spider Android local")
        self.assertTrue(hits)
        self.assertIn("Spider", hits[0]["body"])

    def test_state_round_trip(self):
        state = {"convs": [{"id": "c1", "msgs": []}], "mem": [], "cells": []}
        database.save_state(state)
        self.assertEqual(database.get_state(), state)

    def test_local_http_smoke(self):
        server = LocalServer(("127.0.0.1", 0), SpiderHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            with urllib.request.urlopen(base + "/api/health") as r:
                self.assertEqual(r.status, 200)
                self.assertEqual(json.loads(r.read())["mode"], "local-core-with-internet-learning")
            with urllib.request.urlopen(base + "/api/learning/status") as r:
                self.assertEqual(r.status, 200)
                self.assertIn("indexed_docs", json.loads(r.read()))
            with urllib.request.urlopen(base + "/api/skills") as r:
                self.assertEqual(r.status, 200)
                self.assertEqual(json.loads(r.read())["skills"], [])
            with urllib.request.urlopen(base + "/") as r:
                self.assertEqual(r.status, 200)
                self.assertIn("connect-src 'self'", r.headers.get("Content-Security-Policy", ""))
                self.assertNotIn("unsafe-eval", r.headers.get("Content-Security-Policy", ""))
                self.assertIn("Spider", r.read().decode("utf-8"))
            with urllib.request.urlopen(base + "/extension-worker.js") as r:
                policy = r.headers.get("Content-Security-Policy", "")
                self.assertIn("connect-src 'none'", policy)
                self.assertIn("unsafe-eval", policy)
            req = urllib.request.Request(base + "/api/brain/chat", data=json.dumps({"message": "مرحبا", "history": [], "memories": []}).encode(), headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req) as r:
                body = json.loads(r.read())
                self.assertIn("أهلاً", body["answer"])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

if __name__ == "__main__":
    unittest.main()
