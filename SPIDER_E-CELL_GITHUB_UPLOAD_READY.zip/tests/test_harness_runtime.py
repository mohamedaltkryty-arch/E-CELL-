import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

from spider.harness_runtime import HarnessJsonRpcClient, HarnessRuntime, HarnessRuntimeError


_FAKE_RUNTIME = r'''
import json, sys
for line in sys.stdin:
    request = json.loads(line)
    method = request.get("method")
    request_id = request.get("id")
    if method == "initialize":
        assert request.get("params", {}).get("approvalRequests") is True
        result = {"serverInfo": {"name": "deepseek-harness-sdk-runtime", "version": "test"}}
        print(json.dumps({"jsonrpc":"2.0","id":"approval-rpc-1","method":"approval/request","params":{"sessionId":"session-A","toolName":"file.write","reason":"Write one project file"}}), flush=True)
    elif method is None:
        print(json.dumps({"jsonrpc":"2.0","method":"approval.resolved","params":{"outcome":request.get("result",{}).get("outcome")}}), flush=True)
        continue
    elif method == "test/approval-ready":
        result = {"ready": True}
    elif method == "session/prompt":
        params = request.get("params", {})
        print(json.dumps({"jsonrpc":"2.0","method":"session.event","params":{"sessionId":params.get("sessionId"),"event":{"type":"test"}}}), flush=True)
        result = {"messageId": "message-001"}
    elif method in ("session/wait", "session/resume", "shutdown"):
        result = {}
    else:
        print(json.dumps({"jsonrpc":"2.0","id":request_id,"error":{"code":-32601,"message":"unknown method"}}), flush=True)
        continue
    if request_id is not None:
        print(json.dumps({"jsonrpc":"2.0","id":request_id,"result":result}), flush=True)
'''


class HarnessRpcTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def make_client(self):
        return HarnessJsonRpcClient(
            [sys.executable, "-u", "-c", _FAKE_RUNTIME],
            cwd=str(self.workspace),
            env={"PATH": os.environ.get("PATH", "")},
        )

    def test_initialize_prompt_and_notification_stream(self):
        client = self.make_client()
        try:
            client.start()
            result = client.initialize(provider="deepseek-official", model="deepseek-test", cwd=str(self.workspace))
            self.assertEqual(result["serverInfo"]["name"], "deepseek-harness-sdk-runtime")

            receipt = client.prompt("session-A", "اختبار تكامل")
            self.assertEqual(receipt["messageId"], "message-001")

            deadline = time.time() + 2
            snapshot = client.events_since(0, "session-A")
            while not snapshot["events"] and time.time() < deadline:
                time.sleep(0.01)
                snapshot = client.events_since(0, "session-A")
            session_events = [event for event in snapshot["events"] if event["method"] == "session.event"]
            self.assertTrue(session_events)
            self.assertEqual(session_events[0]["event"]["type"], "test")
            self.assertGreaterEqual(snapshot["latestSequence"], len(snapshot["events"]))
        finally:
            client.close()

    def test_server_approval_request_requires_explicit_user_decision(self):
        client = self.make_client()
        try:
            client.start()
            client.initialize(provider="deepseek-official", model="deepseek-test", cwd=str(self.workspace))
            deadline = time.time() + 2
            approvals = client.pending_approvals()
            while not approvals and time.time() < deadline:
                time.sleep(0.01)
                approvals = client.pending_approvals()
            self.assertEqual(len(approvals), 1)
            approval_id = approvals[0]["approvalId"]
            self.assertEqual(approvals[0]["toolName"], "file.write")
            result = client.answer_approval(approval_id, "allowed-once")
            self.assertEqual(result["outcome"], "allowed-once")
            self.assertTrue(client.request("test/approval-ready", timeout=2)["ready"])
            deadline = time.time() + 2
            events = client.events_since(0)["events"]
            while not any(event["method"] == "approval.resolved" and event["outcome"] == "allowed-once" for event in events) and time.time() < deadline:
                time.sleep(0.01)
                events = client.events_since(0)["events"]
            self.assertTrue(any(event["method"] == "approval.resolved" and event["outcome"] == "allowed-once" for event in events))
            with self.assertRaises(HarnessRuntimeError):
                client.answer_approval(approval_id, "allowed-once")
        finally:
            client.close()

    def test_runtime_resume_uses_persisted_local_session_by_default(self):
        runtime = HarnessRuntime(str(self.root))
        runtime.root.mkdir(parents=True, exist_ok=True)
        runtime._session_file.write_text(json.dumps({"sessionId": "saved-session-42"}), encoding="utf-8")
        client = self.make_client()
        client.start()
        client.initialize(provider="deepseek-official", model="deepseek-test", cwd=str(self.workspace))
        runtime._client = client
        try:
            result = runtime.resume()
            self.assertEqual(result["sessionId"], "saved-session-42")
            self.assertEqual(result["result"], {})
        finally:
            runtime.close()

    def test_prompt_requires_successful_initialize(self):
        client = self.make_client()
        try:
            client.start()
            with self.assertRaises(HarnessRuntimeError) as raised:
                client.prompt("session-A", "hello")
            self.assertEqual(raised.exception.code, "HARNESS_NOT_INITIALIZED")
        finally:
            client.close()

    def test_runtime_status_fails_closed_when_payload_missing(self):
        runtime = HarnessRuntime(str(self.root))
        status = runtime.status()
        self.assertFalse(status["available"])
        self.assertEqual(status["runtimeState"], "runtime_missing")
        self.assertIn("PRoot", status["missing"])
        self.assertIn("Ubuntu rootfs", status["missing"])

    def test_invalid_model_route_rejected(self):
        client = self.make_client()
        try:
            with self.assertRaises(HarnessRuntimeError) as raised:
                client.initialize(provider="deepseek-official", model="", cwd=str(self.workspace))
            self.assertEqual(raised.exception.code, "MODEL_ROUTE_REQUIRED")
        finally:
            client.close()


if __name__ == "__main__":
    unittest.main()
