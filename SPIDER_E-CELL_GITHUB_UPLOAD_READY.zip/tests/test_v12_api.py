import json
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path

from spider import database
from spider.server import LocalServer, SpiderHandler


class V12APITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_dir, self.old_path = database.DATA_DIR, database.DB_PATH
        database.DATA_DIR = Path(self.tmp.name)
        database.DB_PATH = Path(self.tmp.name) / "api.sqlite3"
        database.init_db()
        self.server = LocalServer(("127.0.0.1", 0), SpiderHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        database.DATA_DIR, database.DB_PATH = self.old_dir, self.old_path
        self.tmp.cleanup()

    def call(self, path, payload=None):
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.base + path, data=data,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as response:
            return response.status, json.loads(response.read().decode("utf-8"))

    def test_feedback_and_status_endpoints(self):
        status, result = self.call("/api/brain/feedback", {
            "prompt": "كيف أرتب خطة تطوير تطبيق؟",
            "correction": "ابدأ بتحديد النطاق ثم المتطلبات ثم الاختبارات.",
            "intent": "plan",
        })
        self.assertEqual(status, 201)
        self.assertEqual(result["examples"], 1)
        status, model = self.call("/api/brain/adaptive")
        self.assertEqual(status, 200)
        self.assertEqual(model["examples"], 1)
        self.assertGreater(model["model_bytes"], 0)

    def test_create_and_execute_skill_endpoints(self):
        status, created = self.call("/api/skills/create", {
            "name": "Trim text", "description": "Remove outer whitespace",
            "steps": [{"id": "clean", "op": "text.strip", "from": "input.value"}],
            "output": "clean",
        })
        self.assertEqual(status, 201)
        status, result = self.call("/api/skills/run", {
            "id": created["id"], "inputs": {"value": "  spider local  "},
        })
        self.assertEqual(status, 200)
        self.assertEqual(result["result"], "spider local")

    def test_invalid_skill_is_rejected_by_api(self):
        req = urllib.request.Request(self.base + "/api/skills/create",
            data=json.dumps({"name": "unsafe", "steps": [
                {"id": "x", "op": "os.system", "from": "input"}
            ]}).encode(), headers={"Content-Type": "application/json"})
        with self.assertRaises(Exception):
            urllib.request.urlopen(req, timeout=5)


if __name__ == "__main__":
    unittest.main()
