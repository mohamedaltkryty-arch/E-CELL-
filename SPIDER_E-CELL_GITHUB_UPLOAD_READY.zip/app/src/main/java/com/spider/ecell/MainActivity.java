package com.spider.ecell;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private ProgressBar progress;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9, 11, 16));
        getWindow().setNavigationBarColor(Color.rgb(9, 11, 16));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9, 11, 16));
        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(90, 90, Gravity.CENTER);
        root.addView(progress, pp);
        status = new TextView(this);
        status.setText("SPIDER E-CELL\nجارٍ تشغيل النواة المحلية...");
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        sp.topMargin = 125;
        root.addView(status, sp);
        setContentView(root);
        startCore();
    }

    private void startCore() {
        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python.getInstance().getModule("android_entry")
                    .callAttr("start_server", getFilesDir().getAbsolutePath() + "/spider-data");
                handler.post(this::showApp);
            } catch (Throwable error) {
                handler.post(() -> status.setText("تعذر تشغيل النواة:\n" + error.getMessage()));
            }
        }).start();
    }

    private void showApp() {
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setBackgroundColor(Color.rgb(9, 11, 16));
        root.removeAllViews();
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        webView.loadUrl("http://127.0.0.1:8765/");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
