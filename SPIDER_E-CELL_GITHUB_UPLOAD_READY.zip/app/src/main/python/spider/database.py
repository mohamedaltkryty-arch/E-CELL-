import json
import os
import sqlite3
from contextlib import contextmanager
from .config import DATA_DIR, DB_PATH

@contextmanager
def db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

CELL_SEEDS = [
    ("core", "CORE", "المنسّق المركزي", "orchestrator", "توجيه الطلبات وربط الخلايا"),
    ("brain", "BRAIN", "العقل المحلي", "reasoning", "تحليل الطلبات وبناء الاستجابات محلياً"),
    ("memory", "MEMORY", "خلية الذاكرة", "memory", "الفهرسة والاسترجاع وحفظ السياق"),
    ("planner", "PLANNER", "خلية التخطيط", "planning", "تقسيم الأهداف إلى مهام وخطوات"),
    ("analyzer", "ANALYZER", "خلية التحليل", "analysis", "تصنيف الطلبات واستخراج عناصرها"),
    ("builder", "BUILDER", "خلية البناء", "builder", "صياغة مخططات المشاريع ومخرجاتها"),
    ("guardian", "GUARDIAN", "خلية الحماية", "security", "التحقق من العمليات والحدود"),
    ("evolver", "EVOLVER", "خلية التطور", "learning", "بناء فهرس معرفي من بيانات المستخدم المحلية"),
]

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS app_state (
            id INTEGER PRIMARY KEY CHECK(id=1),
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS cells (
            id TEXT PRIMARY KEY,
            code TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            role TEXT NOT NULL,
            description TEXT NOT NULL,
            parent_id TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            runs INTEGER NOT NULL DEFAULT 0,
            last_run TEXT
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cell_id TEXT NOT NULL,
            intent TEXT NOT NULL,
            input_text TEXT NOT NULL,
            result TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'completed',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cell_id) REFERENCES cells(id)
        );
        CREATE TABLE IF NOT EXISTS brain_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            detail TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS model_docs (
            id TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            body TEXT NOT NULL,
            token_count INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS model_terms (
            doc_id TEXT NOT NULL,
            term TEXT NOT NULL,
            tf REAL NOT NULL,
            PRIMARY KEY(doc_id, term),
            FOREIGN KEY(doc_id) REFERENCES model_docs(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS learning_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            status TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            query_count INTEGER NOT NULL DEFAULT 0,
            results_count INTEGER NOT NULL DEFAULT 0,
            error TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS web_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            snippet TEXT NOT NULL DEFAULT '',
            body_gzip BLOB NOT NULL DEFAULT X'',
            body_hash TEXT NOT NULL DEFAULT '',
            source_type TEXT NOT NULL DEFAULT 'web',
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS skills (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            source_url TEXT NOT NULL,
            summary TEXT NOT NULL DEFAULT '',
            manifest_gzip BLOB NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS skill_files (
            skill_id TEXT NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
            path TEXT NOT NULL,
            body_gzip BLOB NOT NULL,
            byte_count INTEGER NOT NULL,
            sha256 TEXT NOT NULL,
            PRIMARY KEY(skill_id,path)
        );
        CREATE TABLE IF NOT EXISTS adaptive_examples (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prompt TEXT NOT NULL,
            correction TEXT NOT NULL,
            intent TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_model_terms_term ON model_terms(term);
        CREATE INDEX IF NOT EXISTS idx_web_sources_updated ON web_sources(updated_at);
        CREATE INDEX IF NOT EXISTS idx_skill_files_skill ON skill_files(skill_id);
        CREATE INDEX IF NOT EXISTS idx_tasks_created ON tasks(created_at);
        CREATE INDEX IF NOT EXISTS idx_events_created ON brain_events(created_at);
        """)
        for cid, code, name, role, desc in CELL_SEEDS:
            con.execute("""INSERT OR IGNORE INTO cells(id,code,name,role,description,parent_id)
                          VALUES(?,?,?,?,?,?)""", (cid, code, name, role, desc,
                          None if cid == "core" else "core"))

def get_state():
    with db() as con:
        row = con.execute("SELECT payload FROM app_state WHERE id=1").fetchone()
        if not row:
            return None
        try:
            return json.loads(row["payload"])
        except json.JSONDecodeError:
            return None

def save_state(state):
    payload = json.dumps(state, ensure_ascii=False, separators=(",", ":"))
    with db() as con:
        con.execute("""INSERT INTO app_state(id,payload,updated_at) VALUES(1,?,CURRENT_TIMESTAMP)
                      ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, updated_at=CURRENT_TIMESTAMP""",
                     (payload,))
        # Sync app-created cells into the relational cell registry without deleting system cells.
        for cell in state.get("cells", []) if isinstance(state, dict) else []:
            if not isinstance(cell, dict):
                continue
            cid = str(cell.get("id", ""))[:64]
            code = str(cell.get("code", cid)).upper()[:32]
            name = str(cell.get("name", code))[:80]
            if cid and code:
                con.execute("""INSERT OR IGNORE INTO cells(id,code,name,role,description,parent_id,status)
                              VALUES(?,?,?,?,?,?,?)""",
                            (cid, code, name, "custom", str(cell.get("description", ""))[:500],
                             "core", str(cell.get("status", "active"))))

def list_cells():
    with db() as con:
        return [dict(r) for r in con.execute(
            "SELECT id,code,name,role,description,parent_id,status,created_at,runs,last_run FROM cells ORDER BY created_at,id")]

def dynamic_cell_limit():
    """Estimate a safe graph/metadata ceiling from current free RAM and storage."""
    memory_limit = 512
    storage_limit = 512
    try:
        pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
        available_bytes = max(1, pages * page_size)
        memory_limit = max(64, min(8192, available_bytes // (2 * 1024 * 1024)))
    except (ValueError, OSError, AttributeError):
        pass
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        stats = os.statvfs(DATA_DIR)
        free_bytes = stats.f_bavail * stats.f_frsize
        storage_limit = max(64, min(8192, free_bytes // (256 * 1024)))
    except (ValueError, OSError, AttributeError):
        pass
    return int(max(64, min(memory_limit, storage_limit)))

def create_cell(code, name, description, role="custom"):
    import re, uuid
    code = re.sub(r"[^A-Za-z0-9_-]", "", code.strip().upper())[:32]
    if len(code) < 2:
        raise ValueError("رمز الخلية يجب أن يتكون من حرفين على الأقل")
    if not name.strip():
        raise ValueError("اسم الخلية مطلوب")
    current_count = len(list_cells())
    limit = dynamic_cell_limit()
    if current_count >= limit:
        raise ValueError(f"وصل عدد الخلايا إلى الحد الآمن الحالي للجهاز ({limit}). أغلق التطبيقات الأخرى أو حرر مساحة ثم أعد المحاولة.")
    cid = "cell_" + uuid.uuid4().hex[:12]
    with db() as con:
        con.execute("INSERT INTO cells(id,code,name,role,description,parent_id) VALUES(?,?,?,?,?,?)",
                    (cid, code, name.strip()[:80], role[:32], description.strip()[:500], "core"))
        con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)", ("cell.create", code))
    return next(c for c in list_cells() if c["id"] == cid)

def set_cell_status(cell_id, status):
    if status not in ("active", "paused"):
        raise ValueError("حالة الخلية غير صالحة")
    with db() as con:
        cur = con.execute("UPDATE cells SET status=? WHERE id=? AND id!='core'", (status, cell_id))
        if not cur.rowcount:
            raise ValueError("الخلية غير موجودة أو لا يمكن إيقاف النواة")
        con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)", ("cell.status", f"{cell_id}:{status}"))
    return next(c for c in list_cells() if c["id"] == cell_id)

def record_task(cell_id, intent, input_text, result):
    with db() as con:
        con.execute("INSERT INTO tasks(cell_id,intent,input_text,result) VALUES(?,?,?,?)",
                    (cell_id, intent[:80], input_text[:4000], result[:8000]))
        con.execute("UPDATE cells SET runs=runs+1,last_run=CURRENT_TIMESTAMP WHERE id=?", (cell_id,))

def list_tasks(limit=30):
    with db() as con:
        return [dict(r) for r in con.execute(
            "SELECT id,cell_id,intent,input_text,result,status,created_at FROM tasks ORDER BY id DESC LIMIT ?",
            (max(1, min(int(limit), 200)),))]

def event(event_type, detail):
    with db() as con:
        con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)", (event_type[:80], detail[:1000]))

def stats():
    with db() as con:
        cells = con.execute("SELECT COUNT(*) FROM cells").fetchone()[0]
        active = con.execute("SELECT COUNT(*) FROM cells WHERE status='active'").fetchone()[0]
        tasks = con.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        docs = con.execute("SELECT COUNT(*) FROM model_docs").fetchone()[0]
        terms = con.execute("SELECT COUNT(*) FROM model_terms").fetchone()[0]
        events = con.execute("SELECT COUNT(*) FROM brain_events").fetchone()[0]
        try:
            sources = con.execute("SELECT COUNT(*) FROM web_sources").fetchone()[0]
            skills = con.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
        except sqlite3.OperationalError:
            sources = skills = 0
    return {"cells": cells, "active_cells": active, "cell_limit": dynamic_cell_limit(),
            "tasks": tasks, "indexed_documents": docs, "indexed_terms": terms, "events": events,
            "learned_sources": sources, "learned_skills": skills}
