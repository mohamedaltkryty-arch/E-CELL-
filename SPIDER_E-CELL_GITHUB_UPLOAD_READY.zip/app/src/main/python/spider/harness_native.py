"""Verified Android PRoot staging with real execve probes.

Android may deny execution of ordinary files copied into app data even when
chmod/access(X_OK) report success. The preferred form therefore symlinks back
to the APK's nativeLibraryDir (apk_data_file), and every candidate is tested
by actually starting it. Copies are a measured fallback, never assumed usable.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

PINNED_NATIVE = {
    "libdsh_proot.so": "cb40a1ced11cee76569b4008a9e478c87883ce831152be4eb9570763b82e580d",
    "libdsh_proot_loader.so": "f149774236db1e69b36cc1e4ed3866c7094db2eee52da0d4956aa63a9bb26929",
}


def _digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def _exec_probe(path: Path, timeout: float = 3.0) -> tuple[bool, str]:
    """Test the Android exec boundary, not just POSIX permission bits."""
    process = None
    try:
        process = subprocess.Popen(
            [str(path)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, close_fds=True, shell=False,
        )
        try:
            process.wait(timeout=timeout)
            return True, f"started-exit-{process.returncode}"
        except subprocess.TimeoutExpired:
            process.kill()
            try:
                process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                pass
            return True, "started-timeout"
    except (OSError, ValueError) as exc:
        return False, f"exec-failed-{getattr(exc, 'errno', 'unknown')}"
    finally:
        if process is not None and process.poll() is None:
            try:
                process.kill()
                process.wait(timeout=1.0)
            except Exception:
                pass


def _atomic_symlink(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = destination.with_name(f".{destination.name}.link-{os.getpid()}")
    try:
        if temporary.exists() or temporary.is_symlink():
            temporary.unlink()
        os.symlink(str(source), temporary)
        os.replace(temporary, destination)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def _atomic_copy(source: Path, destination: Path, expected_sha256: str, mode: int) -> None:
    if not source.is_file() or source.is_symlink():
        raise RuntimeError("ملف تشغيل Harness الأصلي غير صالح")
    if _digest(source) != expected_sha256:
        raise RuntimeError("فشل التحقق من بصمة ملف تشغيل Harness")
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary_name = tempfile.mkstemp(prefix=".harness-", suffix=".part", dir=str(destination.parent))
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as output, source.open("rb") as input_file:
            shutil.copyfileobj(input_file, output, length=1024 * 1024)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(temporary, mode)
        try:
            os.setxattr(temporary, "security.android.exec", b"1", follow_symlinks=False)
        except (AttributeError, OSError):
            pass
        if _digest(temporary) != expected_sha256:
            raise RuntimeError("فشل التحقق من نسخة ملف تشغيل Harness")
        os.replace(temporary, destination)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def _stage_executable(source: Path, destination: Path, expected_sha256: str) -> tuple[Path, str]:
    if not source.is_file() or source.is_symlink() or _digest(source) != expected_sha256:
        raise RuntimeError("ملف تشغيل Harness الأصلي لا يطابق البصمة المثبتة")

    # APK native libraries are executable by Android's package loading policy;
    # an app-private symlink preserves the APK-backed inode on affected ROMs.
    try:
        if destination.exists() or destination.is_symlink():
            if destination.is_symlink() and destination.resolve() == source.resolve():
                usable, detail = _exec_probe(destination)
                if usable:
                    return destination, "apk-symlink:" + detail
            destination.unlink()
        _atomic_symlink(source, destination)
        usable, detail = _exec_probe(destination)
        if usable:
            return destination, "apk-symlink:" + detail
        destination.unlink(missing_ok=True)
    except OSError:
        try:
            destination.unlink()
        except OSError:
            pass

    # Fallback is accepted only after an actual child process starts.
    _atomic_copy(source, destination, expected_sha256, 0o700)
    usable, detail = _exec_probe(destination)
    if not usable:
        raise RuntimeError("Android منع تنفيذ ملف PRoot حتى بعد النسخ الآمن (" + detail + ")")
    return destination, "private-copy:" + detail


def stage_native_runtime(native_library_directory: str, data_directory: str) -> dict[str, object]:
    """Stage only pinned native files and prove that Android can execute them."""
    native_dir = Path(native_library_directory).resolve()
    app_data = Path(data_directory).resolve()
    runner_source = native_dir / "libdsh_proot.so"
    loader_source = native_dir / "libdsh_proot_loader.so"
    runner_dest = app_data / "harness" / "bin" / "proot"
    loader_dest = app_data / "harness" / "loader" / "loader"
    if not runner_source.is_file() or not loader_source.is_file():
        return {"available": False, "reason": "arm64-native-runtime-not-packaged"}

    runner, runner_form = _stage_executable(
        runner_source, runner_dest, PINNED_NATIVE["libdsh_proot.so"])
    loader, loader_form = _stage_executable(
        loader_source, loader_dest, PINNED_NATIVE["libdsh_proot_loader.so"])

    marker = app_data / "harness" / "native-runtime.json"
    marker_payload = {
        "schemaVersion": 1,
        "nativeLibraryDirectory": str(native_dir),
        "runnerSha256": PINNED_NATIVE["libdsh_proot.so"],
        "loaderSha256": PINNED_NATIVE["libdsh_proot_loader.so"],
        "runnerPath": str(runner),
        "loaderPath": str(loader),
        "runnerProbe": runner_form,
        "loaderProbe": loader_form,
    }
    marker.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp_name = tempfile.mkstemp(prefix=".native-runtime-", suffix=".part", dir=str(marker.parent))
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(marker_payload, output, separators=(",", ":"))
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_name, marker)
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass

    return {
        "available": True,
        "runner": str(runner),
        "loader": str(loader),
        "runnerProbe": runner_form,
        "loaderProbe": loader_form,
        "rootfsInstalled": False,
    }
