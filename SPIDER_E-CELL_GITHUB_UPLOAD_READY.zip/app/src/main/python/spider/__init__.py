"""SPIDER E-CELL local runtime."""
