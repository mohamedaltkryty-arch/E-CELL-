import ast
import math
import re
import unicodedata
from collections import Counter
from . import database as store
from . import adaptive

ARABIC_STOP = set("في من على الى إلى عن مع هذا هذه ذلك تلك هو هي انا نحن انت ان أن كان تكون يتم تم قد ما لا لم لن هل أو او ثم كما بعد قبل عند بين كل بعض جدا فقط الآن ايضا أيضا كيف لماذا ماذا متى أين اين أي اى اذا إذا".split())
DIACRITICS = re.compile(r"[\u064B-\u065F\u0670\u0640]")
TOKEN_RE = re.compile(r"[\u0621-\u064A\u0660-\u0669A-Za-z0-9_]+")

CELL_BY_INTENT = {
    "status": "core", "cells": "core", "memory": "memory", "plan": "planner",
    "analyze": "analyzer", "build": "builder", "math": "analyzer", "help": "brain",
    "chat": "brain", "remember": "memory", "security": "guardian"
}

def normalize(text):
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = DIACRITICS.sub("", text).replace("ـ", "")
    return text.lower().strip()

def tokens(text):
    return [t for t in TOKEN_RE.findall(normalize(text)) if len(t) > 1 and t not in ARABIC_STOP]

def _score_memory(query, body):
    q = set(tokens(query))
    if not q:
        return 0.0
    d = tokens(body)
    if not d:
        return 0.0
    counts = Counter(d)
    overlap = sum(1 for w in q if w in counts)
    tf = sum(min(counts[w], 3) for w in q)
    return overlap / math.sqrt(len(q) * len(set(d))) + 0.025 * tf

def retrieve_memories(query, memories, limit=5):
    ranked = []
    for item in memories if isinstance(memories, list) else []:
        if not isinstance(item, dict):
            continue
        body = str(item.get("content", ""))
        score = _score_memory(query, body + " " + " ".join(item.get("tags", [])))
        if score > 0:
            ranked.append((score, item))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return [{"id": x[1].get("id"), "content": x[1].get("content", ""), "score": round(x[0], 4)}
            for x in ranked[:limit]]

def detect_intent(text):
    q = normalize(text)
    if any(x in q for x in ("كم خلية", "الخلايا", "حالة النظام", "حالة spider", "حالة سبايدر", "حالة الشبكة")):
        return "cells"
    if any(x in q for x in ("ماذا تتذكر", "ما الذي تتذكر", "اعرض الذاكرة", "ذكرياتي", "ذاكرتك", "معلوماتي المحفوظة")):
        return "memory"
    if any(x in q for x in ("احفظ", "تذكر ان", "تذكر أن", "سجل هذه المعلومة", "خزن هذه المعلومة")):
        return "remember"
    if any(x in q for x in ("فحص امن", "فحص أمان", "تحقق من الامان", "تحقق من الأمان", "هل هذا آمن", "هل هذا امن", "مخاطر", "صلاحيات")):
        return "security"
    if any(x in q for x in ("احسب", "كم يساوي", "ناتج", "اجمع", "اضرب", "اقسم", "اطرح")) or re.search(r"\d\s*[+*/×÷-]\s*\d", q):
        return "math"
    if any(x in q for x in ("خطط", "خطة", "خطوات", "كيف ابني", "كيف أبني", "كيف انشئ", "كيف أنشئ", "نفذ مشروع", "ابدأ مشروع")):
        return "plan"
    if any(x in q for x in ("ابن", "أنشئ", "انشئ", "اصنع", "صمم", "اكتب كود", "برمج", "طوّر", "طور")):
        return "build"
    if any(x in q for x in ("حلل", "تحليل", "قارن", "ما رأيك", "قيّم", "قيم", "راجع")):
        return "analyze"
    if any(x in q for x in ("ماذا تستطيع", "ماذا يمكنك", "قدراتك", "مساعده", "مساعدة", "الاوامر", "الأوامر", "كيف استخدمك")):
        return "help"
    if any(x in q for x in ("مرحبا", "السلام عليكم", "هلا", "اهلا", "أهلا", "صباح الخير", "مساء الخير")):
        return "greeting"
    return "chat"

def safe_math(text):
    s = normalize(text)
    s = s.replace("×", "*").replace("÷", "/").replace("٫", ".").replace(",", ".")
    s = re.sub(r"(احسب|كم يساوي|ناتج|يساوي|اجمع|اضرب|اقسم|اطرح)", " ", s)
    s = s.replace("زائد", "+").replace("جمع", "+").replace("ناقص", "-").replace("طرح", "-")
    s = s.replace("في", "*")
    s = re.sub(r"[^0-9+*/().%\-\s]", "", s).strip()
    if not s or len(s) > 100:
        return None
    try:
        node = ast.parse(s, mode="eval")
    except SyntaxError:
        return None
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            v = ev(n.operand); return v if isinstance(n.op, ast.UAdd) else -v
        if isinstance(n, ast.BinOp) and isinstance(n.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.Pow)):
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add): v = a + b
            elif isinstance(n.op, ast.Sub): v = a - b
            elif isinstance(n.op, ast.Mult): v = a * b
            elif isinstance(n.op, ast.Div): v = a / b
            elif isinstance(n.op, ast.Mod): v = a % b
            else:
                if abs(b) > 10 or abs(a) > 1e9: raise ValueError("range")
                v = a ** b
            if not math.isfinite(float(v)) or abs(v) > 1e15: raise ValueError("range")
            return v
        raise ValueError("unsupported")
    try:
        result = ev(node)
        return int(result) if float(result).is_integer() else round(float(result), 8)
    except Exception:
        return None

def plan_steps(text):
    q = text.strip().rstrip("؟?!.")
    return [
        ("تحديد الهدف", f"تثبيت النتيجة المطلوبة من: {q}"),
        ("تفكيك المتطلبات", "حصر المدخلات والوظائف والقيود والموارد المحلية المطلوبة."),
        ("توزيع العمل", "إسناد التحليل إلى ANALYZER والتخطيط إلى PLANNER والبناء إلى BUILDER."),
        ("التنفيذ الأولي", "إنشاء مكوّن صغير قابل للاختبار وحفظه ضمن ملفات المشروع المحلية."),
        ("التحقق", "تشغيل اختبارات الوظائف والحالات الحدّية وفحص الأمان."),
        ("الحفظ والتطوير", "حفظ النتيجة في الذاكرة وسجل المهام وتحديد التحسين التالي."),
    ]

def summarize(text, max_sentences=4):
    parts = [x.strip() for x in re.split(r"(?<=[.!؟])\s+|\n+", text) if x.strip()]
    if len(parts) <= max_sentences:
        return "\n".join("• " + x for x in parts)
    scored = []
    all_terms = Counter(tokens(text))
    for idx, sent in enumerate(parts):
        st = tokens(sent)
        score = sum(all_terms[x] for x in set(st)) / max(1, len(st))
        scored.append((score, idx, sent))
    picked = sorted(sorted(scored, reverse=True)[:max_sentences], key=lambda x: x[1])
    return "\n".join("• " + x[2] for x in picked)

class LocalBrain:
    def search_index(self, query, limit=4):
        terms = set(tokens(query))
        if not terms:
            return []
        with store.db() as con:
            total = con.execute("SELECT COUNT(*) FROM model_docs").fetchone()[0]
            if not total:
                return []
            marks = ",".join("?" for _ in terms)
            rows = con.execute(
                f"SELECT d.id,d.source,d.body,d.token_count,t.term,t.tf,"
                f"(SELECT COUNT(*) FROM model_terms z WHERE z.term=t.term) AS df "
                f"FROM model_docs d JOIN model_terms t ON t.doc_id=d.id WHERE t.term IN ({marks})",
                tuple(terms)).fetchall()
        scores = {}
        docs = {}
        for row in rows:
            did = row["id"]
            idf = math.log((1 + total) / (1 + row["df"])) + 1.0
            scores[did] = scores.get(did, 0.0) + float(row["tf"]) * idf
            docs[did] = {"source": row["source"], "body": row["body"]}
        ranked = sorted(scores, key=scores.get, reverse=True)[:limit]
        return [{"source": docs[k]["source"], "body": docs[k]["body"][:1800],
                 "score": round(scores[k], 5)} for k in ranked]

    def respond(self, payload):
        text = str(payload.get("message", "")).strip()
        if not text:
            raise ValueError("الرسالة فارغة")
        if len(text) > 8000:
            raise ValueError("الرسالة تتجاوز الحد المسموح")
        memories = payload.get("memories", [])
        history = payload.get("history", [])
        intent = detect_intent(text)
        adaptive_prediction = adaptive.predict(text)
        # The learned classifier only supplements the explicit rule router after it has
        # accumulated enough user-labelled examples. It never overrides a clear command.
        if intent == "chat" and adaptive_prediction:
            label_examples = adaptive_prediction.get("label_examples", 0)
            if (adaptive_prediction["examples"] >= 8 and label_examples >= 2
                    and adaptive_prediction["confidence"] >= 0.62
                    and adaptive_prediction["margin"] >= 0.35):
                intent = adaptive_prediction["intent"]
        matched = retrieve_memories(text, memories, 5)
        indexed = self.search_index(text, 3)
        # Reuse high-overlap corrections explicitly approved by the user. This is
        # retrieval, not a claim that the classifier has learned general language.
        learned_corrections = adaptive.retrieve_corrections(text, limit=1)
        if learned_corrections and learned_corrections[0]["similarity"] < 0.42:
            learned_corrections = []
        cells = store.list_cells()
        active_codes = {c["id"] for c in cells if c["status"] == "active"}
        cell_id = CELL_BY_INTENT.get(intent, "brain")
        # User-defined cells can receive work when their declared purpose matches the request.
        request_terms = set(tokens(text))
        custom_candidates = []
        for cell in cells:
            if cell["role"] == "custom" and cell["status"] == "active":
                descriptor = set(tokens(cell["code"] + " " + cell["name"] + " " + cell["description"]))
                overlap = len(request_terms & descriptor)
                if overlap:
                    custom_candidates.append((overlap / max(1, len(request_terms)), cell["id"]))
        if custom_candidates:
            custom_candidates.sort(reverse=True)
            if custom_candidates[0][0] >= 0.15:
                cell_id = custom_candidates[0][1]
        if cell_id not in active_codes:
            cell_id = "core"
        remember = None

        if intent == "greeting":
            answer = "أهلاً. نواة SPIDER E-CELL المحلية تعمل. اكتب طلباً مباشراً أو استخدم أوامر الذاكرة والخلايا."
        elif intent == "help":
            answer = ("قدراتي الحالية محلياً:\n"
                      "• إدارة خلايا E-CELL وإنشاء خلايا متخصصة.\n"
                      "• حفظ الذاكرة واسترجاع العناصر ذات الصلة.\n"
                      "• تخطيط الأهداف إلى خطوات ومهام.\n"
                      "• تحليل النصوص وتلخيصها.\n"
                      "• تنفيذ الحسابات الأساسية بأمان.\n"
                      "• إدارة المحادثات والإضافات والتصدير والاستعادة.\n"
                      "• تعلّم تصنيفي محلي من تصحيحاتك، ومهارات تنفيذية آمنة بصيغة Spider DSL.\n\n"
                      "ملاحظة: لا يوجد اتصال بنموذج سحابي. مصنّف التعلم صغير، وليس نموذجاً لغوياً توليدياً كبيراً.")
        elif intent in ("cells", "status"):
            active = [c for c in cells if c["status"] == "active"]
            answer = (f"حالة SPIDER E-CELL\nالخلايا المسجلة: {len(cells)}\nالخلايا النشطة: {len(active)}\n"
                      f"المهام المنفذة: {store.stats()['tasks']}\n\n"
                      + "\n".join(f"• {c['code']} — {c['name']} ({'نشطة' if c['status']=='active' else 'متوقفة'})" for c in cells))
        elif intent == "remember":
            remember = text
            answer = "التقطت معلومة للحفظ. أضيفها إلى ذاكرة Spider المحلية لتظهر في تبويب الذاكرة."
        elif intent == "memory":
            if matched:
                answer = "هذه أقرب العناصر الموجودة في الذاكرة المحلية:\n" + "\n".join(
                    f"• {x['content']}" for x in matched)
            elif memories:
                answer = "الذاكرة تحتوي عناصر، لكن لم أجد عنصراً مطابقاً بما يكفي لسؤالك. افتح تبويب الذاكرة لاستعراضها."
            else:
                answer = "لا توجد عناصر ذاكرة محفوظة بعد. استخدم الأمر /تذكر متبوعاً بالمعلومة أو أضفها من تبويب الذاكرة."
        elif intent == "security":
            answer = ("فحص الأمان المحلي الأولي:\n"
                      "• لا تُشغّل شيفرة غير موثوقة.\n"
                      "• راجع مصدر الشيفرة والترخيص والاعتماديات.\n"
                      "• امنع الشبكة والوصول إلى الملفات والبيانات الحساسة داخل الإضافات.\n"
                      "• شغّل اختبارات معزولة، ثم راجع النتائج قبل التفعيل.\n\n"
                      "هذا فحص إرشادي للنص، وليس تحليلاً أمنياً كاملاً أو ضماناً لسلامة الشيفرة.")
        elif intent == "math":
            val = safe_math(text)
            answer = f"الناتج: {val}" if val is not None else "لم أستطع استخراج عملية حسابية واضحة. اكتبها بصيغة مثل: احسب 125 × 8 + 4."
        elif intent == "plan":
            steps = plan_steps(text)
            answer = "خطة العمل الأولية:\n" + "\n".join(f"{i+1}. {name}: {desc}" for i, (name, desc) in enumerate(steps))
            answer += "\n\nهذه خطة قابلة للتعديل وليست تنفيذاً تلقائياً للخطوات."
        elif intent == "analyze":
            context = "\n".join(str(x.get("content", "")) for x in history[-6:] if isinstance(x, dict))
            if indexed:
                context += "\n" + "\n".join(x["body"][:1000] for x in indexed[:2])
            summary = summarize(text + ("\n" + context if context else ""), 4)
            answer = "قراءة تحليلية أولية:\n" + summary
            if matched:
                answer += "\n\nسياق مرتبط من ذاكرتك:\n" + "\n".join("• " + x["content"] for x in matched[:3])
            answer += "\n\nهذا تحليل نصّي محلي يعتمد على الكلمات والسياق المتاح، وليس حكماً خبيراً مستقلاً."
        elif intent == "build":
            answer = ("استلمت طلب البناء. سأحوّله إلى مواصفات قابلة للتنفيذ داخل SPIDER E-CELL.\n"
                      "1. حدّد ناتج المشروع النهائي.\n2. قسّمه إلى واجهة وبيانات ومنطق واختبارات.\n"
                      "3. اسند التحليل والتخطيط والبناء إلى خلاياها.\n"
                      "4. نفّذ كل جزء واختبره قبل دمجه.\n\n"
                      "اكتب كلمة (خطة) مع الطلب للحصول على تفصيل الخطوات، أو اذكر المنصة والوظائف المطلوبة لتوليد هيكل أدق.")
        else:
            if intent == "chat" and learned_corrections:
                learned = learned_corrections[0]
                answer = ("إجابة مسترجعة من تصحيح سابق اعتمدته أنت:\n" +
                          learned["correction"] +
                          "\n\nتم استرجاع هذه الإجابة بسبب تشابه الطلب الحالي مع المثال المحفوظ؛ راجعها إذا اختلف السياق.")
            elif matched:
                answer = ("ربطت طلبك بسياق محفوظ في ذاكرتك:\n" +
                          "\n".join("• " + x["content"] for x in matched[:3]) +
                          "\n\nأستطيع بناء إجابة أدق عند تحديد المطلوب: شرح، تحليل، خطة، أو تنفيذ.")
            else:
                answer = ("استلمت طلبك داخل النواة المحلية.\n"
                          "حتى لا أخمّن تفاصيل غير موجودة، حدّد النتيجة التي تريدها أو اكتب (خطة) لتفكيك الهدف إلى مراحل.\n\n"
                          "معالجة هذه النسخة محلية بالكامل؛ لم يتم توصيلها بخدمة ذكاء خارجية.")

        if indexed and intent not in ("greeting", "math", "cells", "status", "remember", "memory"):
            refs = []
            for item in indexed[:2]:
                excerpt = re.sub(r"\s+", " ", str(item.get("body", ""))).strip()[:750]
                source = str(item.get("source", "مصدر محلي"))
                refs.append(f"• {source}\n  {excerpt}")
            answer += "\n\nمعرفة محلية مسترجعة من المصادر التي سبق تعلّمها:\n" + "\n".join(refs)
        store.record_task(cell_id, intent, text, answer)
        store.event("brain.route", f"{intent}:{cell_id}")
        return {"answer": answer, "intent": intent, "cell_id": cell_id,
                "memory_hits": matched, "indexed_hits": indexed, "remember": remember,
                "adaptive_prediction": adaptive_prediction,
                "learned_corrections": learned_corrections,
                "adaptive_examples": adaptive.count_examples(),
                "stats": store.stats()}

    def index_local_data(self, documents):
        """Build a local TF/term index from user-owned text. No model or data is downloaded."""
        import hashlib
        clean_docs = []
        for item in documents if isinstance(documents, list) else []:
            if isinstance(item, str):
                source, body = "local", item
            elif isinstance(item, dict):
                source, body = str(item.get("source", "local")), str(item.get("text", item.get("content", "")))
            else:
                continue
            body = body.strip()[:12000]
            if len(body) < 20:
                continue
            did = hashlib.sha256((source + "\0" + body).encode("utf-8")).hexdigest()
            ts = tokens(body)
            counts = Counter(ts)
            if not counts:
                continue
            clean_docs.append((did, source[:80], body, len(ts), counts))
        with store.db() as con:
            for did, source, body, n, counts in clean_docs:
                con.execute("INSERT OR REPLACE INTO model_docs(id,source,body,token_count,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)",
                            (did, source, body, n))
                con.execute("DELETE FROM model_terms WHERE doc_id=?", (did,))
                con.executemany("INSERT INTO model_terms(doc_id,term,tf) VALUES(?,?,?)",
                                [(did, term, freq/max(1,n)) for term, freq in counts.items()])
            con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)",
                        ("brain.local_index", f"docs={len(clean_docs)}"))
        if any(c["id"] == "evolver" and c["status"] == "active" for c in store.list_cells()):
            store.record_task("evolver", "local_index", f"documents={len(clean_docs)}",
                              f"indexed_documents={len(clean_docs)}")
        return {"indexed_documents": len(clean_docs), "indexed_terms": store.stats()["indexed_terms"],
                "description": "فهرس TF/IDF محلي مبني من نصوص المستخدم فقط؛ ليس تدريب نموذج لغوي توليدي."}

brain = LocalBrain()
