"""DeepSeek Harness SDK bridge for SPIDER E-CELL.

The module implements the official newline-delimited JSON-RPC 2.0 SDK transport.
The Android PRoot/Ubuntu/Node runtime is a separately installed, app-private
payload; this module deliberately refuses to pretend that Harness is available
when that payload is missing.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Callable

MAX_FRAME_BYTES = 8 * 1024 * 1024
MAX_EVENTS = 2000
DEFAULT_REQUEST_TIMEOUT = 45.0
INITIALIZE_TIMEOUT = 180.0
WAIT_TIMEOUT = 900.0


class HarnessRuntimeError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class _PendingRequest:
    def __init__(self) -> None:
        self.event = threading.Event()
        self.result: Any = None
        self.error: HarnessRuntimeError | None = None


class _PendingServerRequest:
    def __init__(self, rpc_id: Any, params: dict[str, Any]):
        self.rpc_id = rpc_id
        self.params = params
        self.event = threading.Event()
        self.outcome: str | None = None


class HarnessJsonRpcClient:
    """Thread-safe JSON-RPC client over a child process' stdin/stdout pipes."""

    def __init__(
        self,
        command: list[str],
        *,
        cwd: str,
        env: dict[str, str] | None = None,
        popen: Callable[..., subprocess.Popen] = subprocess.Popen,
    ) -> None:
        if not command or not all(isinstance(arg, str) and arg for arg in command):
            raise HarnessRuntimeError("INVALID_LAUNCH_COMMAND", "أمر تشغيل Harness غير صالح")
        self.command = list(command)
        self.cwd = str(cwd)
        self.env = dict(env or {})
        self._popen = popen
        self._process: subprocess.Popen | None = None
        self._write_lock = threading.Lock()
        self._lock = threading.RLock()
        self._pending: dict[int, _PendingRequest] = {}
        self._server_requests: dict[str, _PendingServerRequest] = {}
        self._next_id = 1
        self._events: deque[dict[str, Any]] = deque(maxlen=MAX_EVENTS)
        self._event_sequence = 0
        self._stderr_tail: deque[str] = deque(maxlen=120)
        self._reader: threading.Thread | None = None
        self._stderr_reader: threading.Thread | None = None
        self._initialized = False
        self._closed = False
        self._exit_code: int | None = None

    @property
    def running(self) -> bool:
        process = self._process
        return process is not None and process.poll() is None and not self._closed

    def start(self) -> None:
        with self._lock:
            if self.running:
                return
            self._closed = False
            try:
                self._process = self._popen(
                    self.command,
                    cwd=self.cwd,
                    env={**os.environ, **self.env},
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    shell=False,
                )
            except (OSError, ValueError) as exc:
                raise HarnessRuntimeError("HARNESS_LAUNCH_FAILED", "تعذر تشغيل محرك DeepSeek Harness") from exc
            if self._process.stdin is None or self._process.stdout is None or self._process.stderr is None:
                self._terminate_process()
                raise HarnessRuntimeError("HARNESS_PIPE_FAILED", "قنوات الاتصال بمحرك Harness غير متاحة")
            self._reader = threading.Thread(target=self._read_stdout, name="spider-harness-jsonrpc", daemon=True)
            self._stderr_reader = threading.Thread(target=self._read_stderr, name="spider-harness-stderr", daemon=True)
            self._reader.start()
            self._stderr_reader.start()

    def initialize(
        self,
        *,
        provider: str,
        model: str,
        cwd: str,
        reasoning_effort: str | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        if not provider.strip() or not model.strip():
            raise HarnessRuntimeError("MODEL_ROUTE_REQUIRED", "يجب تحديد مزود النموذج واسمه")
        params: dict[str, Any] = {
            "cwd": str(Path(cwd).resolve()),
            "provider": provider.strip(),
            "model": model.strip(),
            "approvalRequests": True,
        }
        if reasoning_effort is not None:
            if not reasoning_effort.strip():
                raise HarnessRuntimeError("INVALID_REASONING_EFFORT", "قيمة مستوى الاستدلال غير صالحة")
            params["reasoningEffort"] = reasoning_effort.strip()
        if max_tokens is not None:
            if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens <= 0:
                raise HarnessRuntimeError("INVALID_MAX_TOKENS", "حد الرموز يجب أن يكون عدداً موجباً")
            params["maxTokens"] = max_tokens
        result = self.request("initialize", params, timeout=INITIALIZE_TIMEOUT)
        server_info = result.get("serverInfo") if isinstance(result, dict) else None
        if not isinstance(server_info, dict) or not isinstance(server_info.get("name"), str):
            raise HarnessRuntimeError("HARNESS_PROTOCOL_INVALID", "استجابة تهيئة Harness لا تطابق البروتوكول")
        if server_info["name"] != "deepseek-harness-sdk-runtime":
            raise HarnessRuntimeError("HARNESS_PROTOCOL_MISMATCH", "هوية محرك Harness غير متوافقة")
        self._initialized = True
        return {"serverInfo": server_info}

    def prompt(self, session_id: str, prompt: str) -> dict[str, str]:
        self._require_initialized()
        if not isinstance(session_id, str) or not session_id.strip() or len(session_id) > 160:
            raise HarnessRuntimeError("INVALID_SESSION_ID", "معرّف الجلسة غير صالح")
        if not isinstance(prompt, str) or not prompt.strip():
            raise HarnessRuntimeError("EMPTY_PROMPT", "اكتب رسالة قبل الإرسال")
        if len(prompt.encode("utf-8")) > 1_000_000:
            raise HarnessRuntimeError("PROMPT_TOO_LARGE", "حجم الرسالة أكبر من الحد المسموح")
        result = self.request(
            "session/prompt",
            {"sessionId": session_id, "contentBlocks": [{"type": "text", "text": prompt}]},
            timeout=DEFAULT_REQUEST_TIMEOUT,
        )
        message_id = result.get("messageId") if isinstance(result, dict) else None
        if not isinstance(message_id, str) or not message_id:
            raise HarnessRuntimeError("HARNESS_PROTOCOL_INVALID", "لم يُرجع Harness معرّف الرسالة")
        return {"messageId": message_id}

    def wait(self, session_id: str, timeout: float = WAIT_TIMEOUT) -> dict[str, Any]:
        self._require_initialized()
        if not isinstance(session_id, str) or not session_id.strip():
            raise HarnessRuntimeError("INVALID_SESSION_ID", "معرّف الجلسة غير صالح")
        result = self.request("session/wait", {"sessionId": session_id}, timeout=timeout)
        return result if isinstance(result, dict) else {}

    def resume(self, session_id: str) -> dict[str, Any]:
        self._require_initialized()
        return self.request("session/resume", {"sessionId": session_id}, timeout=DEFAULT_REQUEST_TIMEOUT)

    def events_since(self, sequence: int = 0, session_id: str | None = None) -> dict[str, Any]:
        if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 0:
            sequence = 0
        with self._lock:
            events = [
                dict(item) for item in self._events
                if item["sequence"] > sequence and (session_id is None or item.get("sessionId") == session_id)
            ]
            latest = self._event_sequence
        return {"events": events, "latestSequence": latest}

    def pending_approvals(self) -> list[dict[str, Any]]:
        with self._lock:
            return [
                {"approvalId": approval_id, **dict(item.params)}
                for approval_id, item in self._server_requests.items()
                if item.outcome is None
            ]

    def answer_approval(self, approval_id: str, outcome: str) -> dict[str, Any]:
        if outcome not in ("allowed-once", "rejected", "cancelled"):
            raise HarnessRuntimeError("INVALID_APPROVAL_OUTCOME", "قرار الموافقة غير صالح")
        with self._lock:
            pending = self._server_requests.get(approval_id)
            if pending is None or pending.outcome is not None:
                raise HarnessRuntimeError("APPROVAL_NOT_PENDING", "طلب الموافقة غير موجود أو تمت معالجته")
            pending.outcome = outcome
            pending.event.set()
        return {"ok": True, "approvalId": approval_id, "outcome": outcome}

    def request(self, method: str, params: dict[str, Any] | None = None, *, timeout: float = DEFAULT_REQUEST_TIMEOUT) -> Any:
        process = self._process
        if process is None or not self.running or process.stdin is None:
            raise HarnessRuntimeError("HARNESS_NOT_RUNNING", "محرك Harness غير مشغّل")
        with self._lock:
            request_id = self._next_id
            self._next_id += 1
            pending = _PendingRequest()
            self._pending[request_id] = pending
        frame: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id, "method": method}
        if params is not None:
            frame["params"] = params
        wire = json.dumps(frame, ensure_ascii=False, separators=(",", ":")) + "\n"
        try:
            with self._write_lock:
                process.stdin.write(wire)
                process.stdin.flush()
        except (BrokenPipeError, OSError, ValueError) as exc:
            with self._lock:
                self._pending.pop(request_id, None)
            raise HarnessRuntimeError("HARNESS_PIPE_CLOSED", "انقطع الاتصال بمحرك Harness") from exc
        if not pending.event.wait(max(0.1, float(timeout))):
            with self._lock:
                self._pending.pop(request_id, None)
            raise HarnessRuntimeError("HARNESS_REQUEST_TIMEOUT", f"انتهت مهلة طلب Harness: {method}")
        if pending.error is not None:
            raise pending.error
        return pending.result

    def close(self) -> None:
        process = self._process
        if process is None:
            self._closed = True
            return
        if self.running and self._initialized:
            try:
                self.request("shutdown", timeout=8.0)
            except HarnessRuntimeError:
                pass
        with self._lock:
            self._closed = True
        self._terminate_process()
        for thread in (self._reader, self._stderr_reader):
            if thread and thread.is_alive() and thread is not threading.current_thread():
                thread.join(timeout=1.5)
        self._fail_pending("HARNESS_CLOSED", "تم إغلاق محرك Harness")
        self._initialized = False

    def _read_stdout(self) -> None:
        process = self._process
        if process is None or process.stdout is None:
            return
        try:
            while True:
                line = process.stdout.readline(MAX_FRAME_BYTES + 2)
                if not line:
                    break
                if len(line.encode("utf-8", errors="replace")) > MAX_FRAME_BYTES or not line.endswith("\n"):
                    self._fail_pending("HARNESS_FRAME_TOO_LARGE", "أرسل Harness إطار اتصال يتجاوز الحد")
                    self._terminate_process()
                    break
                try:
                    frame = json.loads(line)
                except json.JSONDecodeError:
                    # Stdout is protocol-only. A non-JSON line is treated as a protocol failure,
                    # never displayed as a model response.
                    self._fail_pending("HARNESS_PROTOCOL_INVALID", "أرسل Harness إطار JSON غير صالح")
                    continue
                if not isinstance(frame, dict) or frame.get("jsonrpc") != "2.0":
                    continue
                if "id" in frame and ("result" in frame or "error" in frame):
                    self._resolve_response(frame)
                elif isinstance(frame.get("method"), str) and "id" in frame:
                    self._handle_server_request(frame)
                elif isinstance(frame.get("method"), str):
                    self._record_notification(frame["method"], frame.get("params"))
        except (OSError, ValueError):
            pass
        finally:
            code = process.poll()
            with self._lock:
                self._exit_code = code
            self._fail_pending("HARNESS_PROCESS_EXITED", "توقف محرك Harness أثناء تنفيذ الطلب")

    def _read_stderr(self) -> None:
        process = self._process
        if process is None or process.stderr is None:
            return
        try:
            for line in process.stderr:
                with self._lock:
                    # Keep diagnostics in memory only; never log prompts, keys, or raw stderr.
                    self._stderr_tail.append(line.rstrip()[:500])
        except (OSError, ValueError):
            pass

    def _resolve_response(self, frame: dict[str, Any]) -> None:
        try:
            request_id = int(frame.get("id"))
        except (TypeError, ValueError):
            return
        with self._lock:
            pending = self._pending.pop(request_id, None)
        if pending is None:
            return
        error = frame.get("error")
        if isinstance(error, dict):
            code = str(error.get("code", "HARNESS_REQUEST_FAILED"))[:80]
            message = str(error.get("message", "فشل طلب Harness"))[:500]
            pending.error = HarnessRuntimeError("HARNESS_REMOTE_ERROR", f"{code}: {message}")
        elif "result" in frame:
            pending.result = frame["result"]
        else:
            pending.error = HarnessRuntimeError("HARNESS_PROTOCOL_INVALID", "استجابة Harness لا تحتوي نتيجة")
        pending.event.set()

    def _handle_server_request(self, frame: dict[str, Any]) -> None:
        method = frame.get("method")
        params = frame.get("params")
        if method != "approval/request" or not isinstance(params, dict):
            self._send_server_response(frame.get("id"), error={"code": -32601, "message": "Unsupported client request"})
            return
        import uuid
        approval_id = str(uuid.uuid4())
        public_params = {
            "sessionId": str(params.get("sessionId", ""))[:160],
            "toolName": str(params.get("toolName", "unknown"))[:160],
            "callId": str(params.get("callId", ""))[:160],
            "reason": str(params.get("reason", ""))[:2000],
        }
        pending = _PendingServerRequest(frame.get("id"), public_params)
        with self._lock:
            if len(self._server_requests) >= 100:
                self._send_server_response(frame.get("id"), result={"outcome": "rejected"})
                return
            self._server_requests[approval_id] = pending
        self._record_notification("approval/request", {"approvalId": approval_id, **public_params})
        threading.Thread(
            target=self._await_server_request,
            args=(approval_id, pending),
            name="spider-harness-approval",
            daemon=True,
        ).start()

    def _await_server_request(self, approval_id: str, pending: _PendingServerRequest) -> None:
        # No tool is approved automatically. Expired, closed, or unanswered requests are denied.
        pending.event.wait(300.0)
        outcome = pending.outcome or "rejected"
        self._send_server_response(pending.rpc_id, result={"outcome": outcome})
        with self._lock:
            self._server_requests.pop(approval_id, None)

    def _send_server_response(self, rpc_id: Any, *, result: Any = None, error: dict[str, Any] | None = None) -> None:
        process = self._process
        if process is None or process.stdin is None or not self.running:
            return
        frame: dict[str, Any] = {"jsonrpc": "2.0", "id": rpc_id}
        if error is not None:
            frame["error"] = error
        else:
            frame["result"] = result if result is not None else {}
        try:
            with self._write_lock:
                process.stdin.write(json.dumps(frame, ensure_ascii=False, separators=(",", ":")) + "\n")
                process.stdin.flush()
        except (BrokenPipeError, OSError, ValueError):
            return

    def _record_notification(self, method: str, params: Any) -> None:
        if not isinstance(params, dict):
            params = {"value": params}
        with self._lock:
            self._event_sequence += 1
            self._events.append({
                **params,
                "sequence": self._event_sequence,
                "method": method,
            })

    def _fail_pending(self, code: str, message: str) -> None:
        with self._lock:
            pending = list(self._pending.values())
            self._pending.clear()
            server_requests = list(self._server_requests.values())
        for server_request in server_requests:
            if server_request.outcome is None:
                server_request.outcome = "cancelled"
                server_request.event.set()
        for item in pending:
            item.error = HarnessRuntimeError(code, message)
            item.event.set()

    def _terminate_process(self) -> None:
        process = self._process
        if process is None:
            return
        for stream in (process.stdin, process.stdout, process.stderr):
            try:
                if stream:
                    stream.close()
            except (OSError, ValueError):
                pass
        try:
            process.terminate()
            process.wait(timeout=2.0)
        except (OSError, subprocess.TimeoutExpired):
            try:
                process.kill()
                process.wait(timeout=2.0)
            except (OSError, subprocess.TimeoutExpired):
                pass

    def _require_initialized(self) -> None:
        if not self._initialized or not self.running:
            raise HarnessRuntimeError("HARNESS_NOT_INITIALIZED", "يجب تهيئة محرك Harness أولاً")


class HarnessRuntime:
    """App-private Android runtime locator and singleton SDK client."""

    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir).resolve()
        self.root = self.data_dir / "harness"
        self.rootfs = self.root / "rootfs"
        self.runner = self.root / "bin" / "proot"
        self.loader_source = self.root / "loader" / "loader"
        self.loader = self.rootfs / "root" / ".dsh-mobile" / "dsh-runner" / "loader"
        self.native_library_directory: Path | None = None
        self.workspace = self.root / "workspace"
        self.home = self.root / "home"
        self.tmp = self.root / "tmp"
        self._client: HarnessJsonRpcClient | None = None
        self._lock = threading.RLock()
        self._provider: str | None = None
        self._model: str | None = None
        from .harness_installer import HarnessRootfsInstaller
        self._installer = HarnessRootfsInstaller(str(self.root))
        self._installer_thread: threading.Thread | None = None
        self._install_result: dict[str, Any] | None = None
        self._install_error: dict[str, str] | None = None
        self._sdk_profile_ready = False
        self._guest_loader_ready = False
        self._native_runtime_verified = False
        self._session_file = self.root / "active-session.json"

    def status(self) -> dict[str, Any]:
        ready, missing = self._runtime_files_ready()
        with self._lock:
            client_running = self._client.running if self._client else False
            initialized = bool(self._client and self._client._initialized and client_running)
        install_state = self._installer.status()
        try:
            from .harness_secrets import load_credentials
            credentials_configured = bool(load_credentials(str(self.data_dir)))
        except Exception:
            credentials_configured = False
        return {
            "engine": "DeepSeek Harness SDK",
            "available": ready,
            "running": client_running,
            "initialized": initialized,
            "credentialsConfigured": credentials_configured,
            "runtimeState": "ready" if ready else "runtime_missing",
            "missing": missing,
            "architecture": "arm64-v8a",
            "nativeStageError": os.environ.get("SPIDER_HARNESS_NATIVE_STAGE_ERROR"),
            "profile": "sdk",
            "sdkProfilePrepared": self._sdk_profile_ready,
            "transport": "jsonrpc-2.0-stdio",
            "installation": install_state,
            "installResult": dict(self._install_result) if self._install_result else None,
            "installError": dict(self._install_error) if self._install_error else None,
        }

    def start_install(self) -> dict[str, Any]:
        ready, _missing = self._runtime_files_ready()
        if ready:
            return {"ok": True, "alreadyInstalled": True, "installation": self._installer.status()}
        if not self.runner.is_file() or not self.loader_source.is_file() or not self._native_runtime_is_verified():
            raise HarnessRuntimeError("HARNESS_NATIVE_RUNTIME_MISSING", "ملفات PRoot ARM64 لم تجتز فحص التنفيذ الفعلي على هذا الجهاز")
        with self._lock:
            if self._installer_thread and self._installer_thread.is_alive():
                return {"ok": True, "alreadyRunning": True, "installation": self._installer.status()}
            self._install_result = None
            self._install_error = None
            self._installer.cancel_event.clear()
            self._installer_thread = threading.Thread(target=self._install_worker, name="spider-harness-install", daemon=True)
            self._installer_thread.start()
            return {"ok": True, "accepted": True, "installation": self._installer.status()}

    def cancel_install(self) -> dict[str, Any]:
        self._installer.cancel()
        return {"ok": True, "installation": self._installer.status()}

    def _install_worker(self) -> None:
        try:
            base_ready, _base_missing = self._runtime_files_ready(require_sdk_profile=False)
            result = {"ok": True, "runtimeReused": True} if base_ready else self._installer.install()
            self._installer._set_state(state="installing_sdk_profile", progress=1.0,
                                       message="تثبيت ملف JSON-RPC SDK الرسمي داخل Node")
            self._install_sdk_profile()
            self._sdk_profile_ready = True
            result["sdkProfile"] = "@deepseek-ai/dsh-sdk-app@0.2.1-rc.1"
            with self._lock:
                self._install_result = dict(result)
                self._install_error = None
            self._installer._set_state(state="installed", progress=1.0,
                                       message="اكتمل تثبيت Harness مع SDK JSON-RPC", **result)
        except Exception as exc:
            code = str(getattr(exc, "code", "INSTALL_FAILED"))
            message = str(getattr(exc, "message", "تعذر تثبيت Harness"))
            self._installer._set_state(state="failed", progress=0.0, message=message, errorCode=code)
            with self._lock:
                self._install_result = None
                self._install_error = {"code": code, "message": message}

    def _guest_command(self, command: list[str], timeout: float) -> tuple[int, str]:
        self._ensure_guest_loader()
        self._prepare_sandbox_compat()
        self.workspace.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.home.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.tmp.mkdir(parents=True, exist_ok=True, mode=0o700)
        argv = [
            str(self.runner), "-0", "-r", str(self.rootfs), "-w", "/workspace",
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", f"{self.workspace}:/workspace", "-b", f"{self.home}:/root/.dsh",
            "-b", f"{self.native_library_directory}:/.dsh-native",
            "/usr/bin/env", "-i", "HOME=/root", "USER=root", "LOGNAME=root",
            "LANG=C.UTF-8", "TERM=xterm-256color", "DSH_HOME=/root/.dsh",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            *command,
        ]
        env = {
            "ANDROID_DATA": "/data", "ANDROID_ROOT": "/system", "HOME": str(self.home),
            "LANG": "C.UTF-8", "LD_LIBRARY_PATH": "", "PROOT_LOADER": str(self.loader),
            "PROOT_TMP_DIR": str(self.tmp), "TMPDIR": str(self.tmp),
        }
        try:
            result = subprocess.run(argv, cwd=str(self.workspace), env={**os.environ, **env},
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, encoding="utf-8", errors="replace",
                                    timeout=timeout, check=False, shell=False)
        except subprocess.TimeoutExpired as exc:
            raise HarnessRuntimeError("HARNESS_SDK_INSTALL_TIMEOUT", "انتهت مهلة تهيئة SDK داخل Harness") from exc
        except OSError as exc:
            raise HarnessRuntimeError("HARNESS_SDK_INSTALL_FAILED", "تعذر تشغيل pnpm داخل بيئة Harness") from exc
        return int(result.returncode), (result.stdout or "")[-4000:]

    def _install_sdk_profile(self) -> None:
        package_json = self.rootfs / "opt" / "dsh" / "package.json"
        pnpm_entry = self.rootfs / "opt" / "dsh" / "node_modules" / "pnpm" / "bin" / "pnpm.cjs"
        node_binary = self.rootfs / "opt" / "node" / "bin" / "node"
        if not package_json.is_file() or not pnpm_entry.is_file() or not node_binary.is_file():
            raise HarnessRuntimeError("HARNESS_PACKAGE_MANAGER_MISSING", "لم يعثر Harness على Node أو pnpm داخل Ubuntu")
        self._installer._set_state(state="installing_sdk_profile", progress=1.0,
                                   message="إضافة حزمة SDK JSON-RPC المتوافقة مع إصدار Harness")
        code, _ = self._guest_command([
            "/usr/local/bin/pnpm", "--dir", "/opt/dsh", "add", "--save-exact", "--ignore-scripts",
            "@deepseek-ai/dsh-sdk-app@0.2.1-rc.1",
        ], timeout=900.0)
        sdk_package = self.rootfs / "opt" / "dsh" / "node_modules" / "@deepseek-ai" / "dsh-sdk-app" / "package.json"
        if code != 0 or not sdk_package.is_file():
            raise HarnessRuntimeError("HARNESS_SDK_PROFILE_INSTALL_FAILED", "تعذر تثبيت حزمة SDK الرسمية داخل بيئة Node")

        # dsh loads profile bundles from its own dependency closure. Mirror the
        # official mobile rootfs build's manifest-injection mechanism so the
        # SDK bundle is resolved by the same loader as the bundled web profile.
        manifests = list((self.rootfs / "opt" / "dsh" / "node_modules" / ".pnpm").glob(
            "@deepseek-ai+dsh@*/node_modules/@deepseek-ai/dsh/package.json"))
        if not manifests:
            raise HarnessRuntimeError("HARNESS_DSH_PACKAGE_MISSING", "لم يُعثر على بيان حزمة dsh داخل Node")
        import json, tempfile
        for manifest in manifests:
            if manifest.is_symlink() or not manifest.is_file():
                raise HarnessRuntimeError("HARNESS_DSH_PACKAGE_INVALID", "مسار بيان dsh غير آمن")
            value = json.loads(manifest.read_text(encoding="utf-8"))
            dependencies = value.setdefault("dependencies", {})
            dependencies["@deepseek-ai/dsh-sdk-app"] = "*"
            fd, temporary = tempfile.mkstemp(prefix=".dsh-package-", suffix=".part", dir=str(manifest.parent))
            try:
                os.fchmod(fd, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as output:
                    json.dump(value, output, ensure_ascii=False, indent=2)
                    output.write("\n")
                    output.flush()
                    os.fsync(output.fileno())
                os.replace(temporary, manifest)
            finally:
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass

        self._installer._set_state(state="verifying_sdk_profile", progress=1.0,
                                   message="فحص أمر JSON-RPC SDK داخل Harness")
        code, _ = self._guest_command(["/usr/local/bin/dsh", "--profile", "sdk", "--help"], timeout=45.0)
        if code != 0:
            raise HarnessRuntimeError("HARNESS_SDK_PROFILE_UNAVAILABLE", "حزمة SDK ثُبتت لكن ملف تشغيل JSON-RPC لم يجتز الفحص")

    def save_credentials(self, provider: str, model: str, api_key: str) -> dict[str, Any]:
        from .harness_secrets import save_credentials
        with self._lock:
            if self._client and self._client.running:
                self._client.close()
                self._client = None
                self._provider = None
                self._model = None
        return save_credentials(str(self.data_dir), provider, model, api_key)

    def clear_credentials(self) -> dict[str, Any]:
        from .harness_secrets import delete_credentials
        with self._lock:
            if self._client and self._client.running:
                self._client.close()
                self._client = None
            self._provider = None
            self._model = None
        delete_credentials(str(self.data_dir))
        secret_file = self.home / ".dsh-mobile" / "runtime-secrets.env"
        try:
            secret_file.unlink()
        except FileNotFoundError:
            pass
        return {"ok": True, "deleted": True}

    def initialize_saved(self) -> dict[str, Any]:
        from .harness_secrets import load_credentials
        credentials = load_credentials(str(self.data_dir))
        if not credentials:
            raise HarnessRuntimeError("HARNESS_CREDENTIALS_MISSING", "لم تُحفظ بيانات مزود النموذج بعد")
        return self.initialize(credentials["provider"], credentials["model"])

    def initialize(self, provider: str, model: str, reasoning_effort: str | None = None,
                   max_tokens: int | None = None) -> dict[str, Any]:
        from .harness_secrets import load_credentials
        credentials = load_credentials(str(self.data_dir))
        if not credentials:
            raise HarnessRuntimeError("HARNESS_CREDENTIALS_MISSING", "احفظ بيانات مزود النموذج أولاً من /harness setup")
        if credentials["provider"] != provider or credentials["model"] != model:
            raise HarnessRuntimeError("HARNESS_CREDENTIALS_ROUTE_MISMATCH", "المزود والنموذج لا يطابقان بيانات الاعتماد المحفوظة")
        with self._lock:
            ready, missing = self._runtime_files_ready()
            if not ready:
                raise HarnessRuntimeError("HARNESS_RUNTIME_MISSING", "ملفات تشغيل Harness غير مثبتة: " + ", ".join(missing))
            if not self._sdk_profile_ready:
                raise HarnessRuntimeError("HARNESS_SDK_PROFILE_UNAVAILABLE", "ملف SDK لم يكتمل تثبيته؛ أعد تثبيت بيئة Harness")
            if self._client and self._client.running and self._client._initialized:
                if self._provider == provider and self._model == model:
                    return {"ok": True, "alreadyInitialized": True}
                self._client.close()
                self._client = None
            command, env = self._build_launch()
            self.workspace.mkdir(parents=True, exist_ok=True)
            self.home.mkdir(parents=True, exist_ok=True)
            self.tmp.mkdir(parents=True, exist_ok=True)
            client = HarnessJsonRpcClient(command, cwd=str(self.workspace), env=env)
            client.start()
            try:
                info = client.initialize(
                    provider=provider,
                    model=model,
                    cwd="/workspace",
                    reasoning_effort=reasoning_effort,
                    max_tokens=max_tokens,
                )
            except Exception:
                client.close()
                raise
            self._client = client
            self._provider = provider
            self._model = model
            return {"ok": True, **info}

    def prompt(self, session_id: str | None, prompt: str) -> dict[str, str]:
        with self._lock:
            client = self._require_client()
            selected = str(session_id or "").strip() or self._active_session_id()
        receipt = client.prompt(selected, prompt)
        return {**receipt, "sessionId": selected}

    def _active_session_id(self) -> str:
        import uuid
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self._session_file.is_file() and not self._session_file.is_symlink():
            try:
                import json
                value = json.loads(self._session_file.read_text(encoding="utf-8"))
                session_id = value.get("sessionId") if isinstance(value, dict) else None
                if isinstance(session_id, str) and 0 < len(session_id) <= 160:
                    return session_id
            except Exception:
                pass
        session_id = str(uuid.uuid4())
        import json, tempfile
        fd, temporary = tempfile.mkstemp(prefix=".session-", suffix=".part", dir=str(self.root))
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as output:
                json.dump({"sessionId": session_id}, output)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, self._session_file)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
        return session_id

    def wait(self, session_id: str | None = None, timeout: float = 15.0) -> dict[str, Any]:
        with self._lock:
            client = self._require_client()
            selected = str(session_id or "").strip() or self._active_session_id()
            before = client.events_since(0).get("latestSequence", 0)
        try:
            result = client.wait(selected, timeout)
            events = client.events_since(before, selected)
            return {"ok": True, "complete": True, "sessionId": selected, "result": result, **events,
                    "pendingApprovals": client.pending_approvals()}
        except HarnessRuntimeError as exc:
            if exc.code != "HARNESS_REQUEST_TIMEOUT":
                raise
            return {"ok": True, "complete": False, "sessionId": selected,
                    **client.events_since(before, selected),
                    "pendingApprovals": client.pending_approvals()}

    def resume(self, session_id: str | None = None) -> dict[str, Any]:
        with self._lock:
            client = self._require_client()
            selected = str(session_id or "").strip() or self._active_session_id()
        result = client.resume(selected)
        return {"ok": True, "sessionId": selected, "result": result}

    def events_since(self, sequence: int = 0, session_id: str | None = None) -> dict[str, Any]:
        with self._lock:
            client = self._client
        if not client:
            return {"events": [], "latestSequence": 0}
        return client.events_since(sequence, session_id)

    def pending_approvals(self) -> list[dict[str, Any]]:
        with self._lock:
            client = self._client
        return client.pending_approvals() if client else []

    def answer_approval(self, approval_id: str, outcome: str) -> dict[str, Any]:
        if not isinstance(approval_id, str) or not approval_id.strip() or len(approval_id) > 80:
            raise HarnessRuntimeError("INVALID_APPROVAL_ID", "معرّف الموافقة غير صالح")
        with self._lock:
            client = self._require_client()
        return client.answer_approval(approval_id, outcome)

    def close(self) -> None:
        with self._lock:
            client, self._client = self._client, None
            self._provider = None
            self._model = None
        if client:
            client.close()

    def _require_client(self) -> HarnessJsonRpcClient:
        client = self._client
        if client is None or not client.running or not client._initialized:
            raise HarnessRuntimeError("HARNESS_NOT_INITIALIZED", "محرك Harness غير جاهز؛ نفّذ التهيئة أولاً")
        return client

    def _has_sdk_profile_bundle(self) -> bool:
        sdk_manifest = self.rootfs / "opt" / "dsh" / "node_modules" / "@deepseek-ai" / "dsh-sdk-app" / "package.json"
        if not sdk_manifest.is_file() or sdk_manifest.is_symlink():
            return False
        manifests = (self.rootfs / "opt" / "dsh" / "node_modules" / ".pnpm").glob(
            "@deepseek-ai+dsh@*/node_modules/@deepseek-ai/dsh/package.json")
        for manifest in manifests:
            try:
                import json
                if manifest.is_file() and not manifest.is_symlink():
                    deps = json.loads(manifest.read_text(encoding="utf-8")).get("dependencies", {})
                    if "@deepseek-ai/dsh-sdk-app" in deps:
                        return True
            except Exception:
                continue
        return False

    def _runtime_files_ready(self, require_sdk_profile: bool = True) -> tuple[bool, list[str]]:
        missing: list[str] = []
        if not self.runner.is_file():
            missing.append("PRoot")
        elif not self._native_runtime_is_verified():
            missing.append("PRoot Android exec verification")
        if not self.rootfs.is_dir() or self.rootfs.is_symlink():
            missing.append("Ubuntu rootfs")
        else:
            try:
                self._ensure_guest_loader()
            except (OSError, RuntimeError):
                missing.append("PRoot loader")
            if not (self.rootfs / "usr" / "local" / "bin" / "dsh").is_file():
                missing.append("Harness CLI")
            elif require_sdk_profile and not self._has_sdk_profile_bundle():
                missing.append("SDK JSON-RPC profile")
            else:
                self._sdk_profile_ready = self._has_sdk_profile_bundle()
        return not missing, missing

    def _native_runtime_is_verified(self) -> bool:
        if self._native_runtime_verified:
            return True
        from .harness_native import PINNED_NATIVE, _digest
        marker = self.root / "native-runtime.json"
        try:
            if marker.is_symlink() or not marker.is_file():
                return False
            value = json.loads(marker.read_text(encoding="utf-8"))
            if value.get("schemaVersion") != 1:
                return False
            if value.get("runnerSha256") != PINNED_NATIVE["libdsh_proot.so"]:
                return False
            if value.get("loaderSha256") != PINNED_NATIVE["libdsh_proot_loader.so"]:
                return False
            native_raw = value.get("nativeLibraryDirectory")
            if not isinstance(native_raw, str) or not native_raw.startswith("/"):
                return False
            native_dir = Path(native_raw).resolve(strict=True)
            if not native_dir.is_dir() or str(native_dir) != native_raw:
                return False
            if _digest(native_dir / "libdsh_proot.so") != PINNED_NATIVE["libdsh_proot.so"]:
                return False
            if _digest(native_dir / "libdsh_proot_loader.so") != PINNED_NATIVE["libdsh_proot_loader.so"]:
                return False
            runner_target = self.runner.resolve(strict=True)
            loader_target = self.loader_source.resolve(strict=True)
            if str(self.runner) != value.get("runnerPath") or str(self.loader_source) != value.get("loaderPath"):
                return False
            if _digest(runner_target) != PINNED_NATIVE["libdsh_proot.so"]:
                return False
            if _digest(loader_target) != PINNED_NATIVE["libdsh_proot_loader.so"]:
                return False
            self.native_library_directory = native_dir
            self._native_runtime_verified = True
            return True
        except (OSError, ValueError, TypeError, KeyError):
            return False

    def _ensure_guest_loader(self) -> None:
        """Create a rootfs loader link to the APK ELF and probe real execve.

        Modern Android may refuse an ELF copied into app data even when its
        mode bits look executable. The symlink retains the apk_data_file inode;
        a private copy is accepted only if Android actually starts it.
        """
        if self._guest_loader_ready:
            return
        from .harness_native import PINNED_NATIVE, _atomic_copy, _digest, _exec_probe

        if not self.loader_source.is_file():
            raise RuntimeError("Harness loader has not been staged")
        source = self.loader_source.resolve(strict=True)
        if _digest(source) != PINNED_NATIVE["libdsh_proot_loader.so"]:
            raise RuntimeError("Harness loader digest is invalid")
        root = self.rootfs.resolve(strict=True)
        cursor = self.rootfs
        for part in ("root", ".dsh-mobile", "dsh-runner"):
            cursor = cursor / part
            if cursor.exists() or cursor.is_symlink():
                if cursor.is_symlink() or not cursor.is_dir() or not cursor.resolve().is_relative_to(root):
                    raise RuntimeError("Invalid Harness rootfs loader path")
            else:
                cursor.mkdir(mode=0o700)
        target = cursor / "loader"

        if target.is_symlink():
            try:
                if target.resolve(strict=True) == source and _exec_probe(target)[0]:
                    self._guest_loader_ready = True
                    return
            except OSError:
                pass
            target.unlink()
        elif target.exists():
            if not target.is_file():
                raise RuntimeError("Invalid Harness loader target")
            if _digest(target) == PINNED_NATIVE["libdsh_proot_loader.so"] and _exec_probe(target)[0]:
                self._guest_loader_ready = True
                return

        pending = cursor / ".loader.link"
        try:
            pending.unlink(missing_ok=True)
            os.symlink(str(source), pending)
            os.replace(pending, target)
            if _exec_probe(target)[0]:
                self._guest_loader_ready = True
                return
        except OSError:
            pass
        finally:
            pending.unlink(missing_ok=True)

        # Device ROMs that disallow app-created symlinks may still permit an
        # executable file in the app tree. Do not accept it without execve proof.
        if target.is_symlink() or target.exists():
            target.unlink()
        _atomic_copy(source, target, PINNED_NATIVE["libdsh_proot_loader.so"], 0o700)
        usable, detail = _exec_probe(target)
        if not usable:
            target.unlink(missing_ok=True)
            raise RuntimeError("Android refused to execute the Harness loader (" + detail + ")")
        self._guest_loader_ready = True

    def _prepare_sandbox_compat(self) -> None:
        """Install the fail-closed Landlock adapter and its SDK plugin overlay."""
        if self.native_library_directory is None or not self.native_library_directory.is_dir():
            if not self._native_runtime_is_verified() or self.native_library_directory is None:
                raise HarnessRuntimeError("HARNESS_NATIVE_RUNTIME_MISSING", "مسار مكتبات PRoot الأصلية غير متاح")
        from .harness_sandbox import SANDBOX_RUNNER_SCRIPT, sandbox_provider_patch
        mobile_dir = self.rootfs / "root" / ".dsh-mobile"
        root = self.rootfs.resolve(strict=True)
        cursor = self.rootfs / "root"
        if cursor.exists() or cursor.is_symlink():
            if cursor.is_symlink() or not cursor.is_dir() or not cursor.resolve().is_relative_to(root):
                raise HarnessRuntimeError("HARNESS_SANDBOX_PATH_INVALID", "مسار ملفات توافق Harness غير آمن")
        else:
            cursor.mkdir(mode=0o700)
        if mobile_dir.exists() or mobile_dir.is_symlink():
            if mobile_dir.is_symlink() or not mobile_dir.is_dir() or not mobile_dir.resolve().is_relative_to(root):
                raise HarnessRuntimeError("HARNESS_SANDBOX_PATH_INVALID", "مجلد توافق Harness غير آمن")
        else:
            mobile_dir.mkdir(mode=0o700)
        native_mount = self.rootfs / ".dsh-native"
        if native_mount.exists() or native_mount.is_symlink():
            if native_mount.is_symlink() or not native_mount.is_dir() or not native_mount.resolve().is_relative_to(root):
                raise HarnessRuntimeError("HARNESS_SANDBOX_PATH_INVALID", "نقطة ربط مكتبات Android غير آمنة")
        else:
            native_mount.mkdir(mode=0o755)

        script = SANDBOX_RUNNER_SCRIPT.encode("utf-8")
        if len(script) > 32 * 1024 or not script.startswith(b"#!/bin/sh\n"):
            raise HarnessRuntimeError("HARNESS_SANDBOX_SCRIPT_INVALID", "ملف توافق Landlock غير صالح")
        script_path = mobile_dir / "sandbox-runner.sh"
        self._atomic_private_file(script_path, script, mode=0o700)

        patch = sandbox_provider_patch()
        self._atomic_private_file(
            mobile_dir / "launcher-providers.patch.json",
            json.dumps(patch, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
            mode=0o600,
        )

    @staticmethod
    def _atomic_private_file(destination: Path, payload: bytes, mode: int) -> None:
        import tempfile
        destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if destination.is_symlink() or (destination.exists() and not destination.is_file()):
            raise HarnessRuntimeError("HARNESS_SANDBOX_PATH_INVALID", "ملف إعدادات توافق Harness غير آمن")
        fd, temporary = tempfile.mkstemp(prefix=".harness-config-", suffix=".part", dir=str(destination.parent))
        try:
            os.fchmod(fd, mode)
            with os.fdopen(fd, "wb") as output:
                output.write(payload)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, destination)
            os.chmod(destination, mode)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    def _build_launch(self) -> tuple[list[str], dict[str, str]]:
        self._ensure_guest_loader()
        self._prepare_sandbox_compat()
        # Credentials are AES-GCM encrypted by Android Keystore at rest. A private
        # app-owned env file carries them into the guest without exposing secrets
        # in argv, process listings, HTTP responses, or logs.
        from .harness_secrets import load_credentials
        self.workspace.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.home.mkdir(parents=True, exist_ok=True, mode=0o700)
        secret_dir = self.home / ".dsh-mobile"
        secret_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        secret_file = secret_dir / "runtime-secrets.env"
        if secret_file.exists() or secret_file.is_symlink():
            if secret_file.is_symlink() or not secret_file.is_file():
                raise HarnessRuntimeError("HARNESS_SECRET_FILE_INVALID", "ملف بيانات اعتماد Harness غير آمن")
        credentials = load_credentials(str(self.data_dir))
        if credentials:
            import shlex, tempfile
            content = "export DEEPSEEK_API_KEY=" + shlex.quote(credentials["apiKey"]) + "\n"
            fd, temporary = tempfile.mkstemp(prefix=".secrets-", suffix=".part", dir=str(secret_dir))
            try:
                os.fchmod(fd, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as output:
                    output.write(content)
                    output.flush()
                    os.fsync(output.fileno())
                os.replace(temporary, secret_file)
            finally:
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass
        elif secret_file.exists():
            secret_file.unlink()
        guest_command = [
            "/bin/sh", "-c",
            'if [ -r "$1" ]; then set -a; . "$1"; set +a; rm -f "$1"; else echo credentials-missing >&2; exit 78; fi; shift; exec "$@"',
            "spider-harness", "/root/.dsh/.dsh-mobile/runtime-secrets.env",
            "/usr/local/bin/dsh", "--patch", "/root/.dsh-mobile/launcher-providers.patch.json",
            "--profile", "sdk",
        ]
        argv = [
            str(self.runner), "-0", "-r", str(self.rootfs), "-w", "/workspace",
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", f"{self.workspace}:/workspace",
            "-b", f"{self.home}:/root/.dsh",
            "-b", f"{self.native_library_directory}:/.dsh-native",
            "/usr/bin/env", "-i",
            "HOME=/root", "USER=root", "LOGNAME=root", "LANG=C.UTF-8",
            "TERM=xterm-256color", "DSH_HOME=/root/.dsh",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            *guest_command,
        ]
        env = {
            "ANDROID_DATA": "/data",
            "ANDROID_ROOT": "/system",
            "HOME": str(self.home),
            "LANG": "C.UTF-8",
            "LD_LIBRARY_PATH": "",
            "PROOT_LOADER": str(self.loader),
            "PROOT_TMP_DIR": str(self.tmp),
            "TMPDIR": str(self.tmp),
        }
        return argv, env


_runtime: HarnessRuntime | None = None
_runtime_lock = threading.Lock()


def get_runtime(data_dir: str | None = None) -> HarnessRuntime:
    global _runtime
    with _runtime_lock:
        if data_dir is None:
            data_dir = os.environ.get("SPIDER_DATA_DIR")
        if not data_dir:
            raise HarnessRuntimeError("DATA_DIRECTORY_MISSING", "مجلد بيانات SPIDER غير محدد")
        resolved = Path(data_dir).resolve()
        if _runtime is None or _runtime.data_dir != resolved:
            if _runtime:
                _runtime.close()
            _runtime = HarnessRuntime(str(resolved))
        return _runtime


def reset_runtime_for_tests() -> None:
    global _runtime
    with _runtime_lock:
        if _runtime:
            _runtime.close()
        _runtime = None
