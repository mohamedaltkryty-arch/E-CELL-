"""Internet discovery, persistent knowledge indexing, and GitHub-to-skill ingestion.

Imported code is stored and indexed, never executed automatically. Network access is
performed by this module only; the browser-facing application remains loopback-only.
"""
from __future__ import annotations

import gzip
import ipaddress
import base64
import binascii
import hashlib
import html
import io
import json
import re
import socket
import threading
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath

from . import database as store
from .config import DATA_DIR

USER_AGENT = "SpiderECell/1.1 (local learning; contact: local-app)"
MAX_SEARCH_BYTES = 1_200_000
MAX_PAGE_BYTES = 180_000
MAX_REPO_FILE_BYTES = 160_000
MAX_REPO_TOTAL_BYTES = 8_000_000
MAX_REPO_FILES = 80
MAX_GITHUB_TREE_BYTES = 5_000_000
MAX_ARCHIVE_BYTES = 8_000_000
MAX_ARCHIVE_TOTAL_BYTES = 12_000_000
MAX_ARCHIVE_FILES = 120
SEARCH_QUERIES = [
    "Python official documentation current language library",
    "Termux Android official wiki documentation packages",
    "GitHub REST API official documentation repository contents git trees",
    "Godot 4 official documentation scripting engine",
    "MDN JavaScript HTML Canvas official documentation",
]


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _validate_remote_url(url: str):
    """Allow public HTTPS targets only; validate DNS answers before every request/redirect."""
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("يسمح بروابط HTTPS العامة فقط")
    try:
        if parsed.port not in (None, 443):
            raise ValueError("يُسمح بمنفذ HTTPS القياسي فقط")
    except ValueError as exc:
        if "منفذ" in str(exc):
            raise
        raise ValueError("منفذ الرابط غير صالح") from exc
    host = parsed.hostname.lower().rstrip(".")
    if host in ("localhost", "localhost.localdomain") or host.endswith((".local", ".internal", ".test", ".localhost")):
        raise ValueError("عنوان الشبكة المحلي غير مسموح")
    try:
        ip = ipaddress.ip_address(host)
        addresses = [ip]
    except ValueError:
        try:
            records = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise RuntimeError("تعذر التحقق من عنوان الموقع عبر DNS: " + str(exc)[:140]) from exc
        addresses = []
        for record in records:
            try:
                addresses.append(ipaddress.ip_address(record[4][0].split("%", 1)[0]))
            except ValueError:
                continue
        if not addresses:
            raise RuntimeError("لم يُرجع DNS عنواناً صالحاً للموقع")
    if any(not address.is_global for address in addresses):
        raise ValueError("عنوان الموقع يحل إلى شبكة خاصة أو محلية؛ تم رفضه")
    return host


class _PublicHTTPSRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        target = urllib.parse.urljoin(req.full_url, newurl)
        _validate_remote_url(target)
        return super().redirect_request(req, fp, code, msg, headers, target)


def _fetch(url: str, *, accept="text/html,application/json,text/plain,*/*", limit=MAX_PAGE_BYTES, timeout=14):
    _validate_remote_url(url)
    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": accept,
        "Accept-Encoding": "identity",
    })
    opener = urllib.request.build_opener(_PublicHTTPSRedirectHandler())
    try:
        with opener.open(req, timeout=timeout) as response:
            final_url = response.geturl()
            _validate_remote_url(final_url)
            data = response.read(limit + 1)
            if len(data) > limit:
                raise ValueError("حجم المحتوى تجاوز الحد الآمن")
            charset = response.headers.get_content_charset() or "utf-8"
            return data, response.headers.get_content_type(), charset, final_url, dict(response.headers)
    except urllib.error.HTTPError as exc:
        if exc.code in (403, 429):
            raise RuntimeError(f"الخدمة حدّت الطلبات مؤقتاً (HTTP {exc.code})") from exc
        raise RuntimeError(f"تعذر جلب المصدر (HTTP {exc.code})") from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise RuntimeError("تعذر الاتصال بالإنترنت: " + str(exc)[:180]) from exc


class _SearchParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.results = []
        self._cur = None
        self._capture = None
        self._buf = []
        self._inside_result = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        classes = a.get("class", "")
        if tag == "div":
            if self._inside_result == 0 and "result" in classes.split():
                self._inside_result = 1
                self._cur = {"title": "", "url": "", "snippet": ""}
            elif self._inside_result:
                self._inside_result += 1
        if self._inside_result and tag == "a" and "result__a" in classes.split():
            self._capture = "title"
            self._cur["url"] = a.get("href", "")
            self._buf = []
        elif self._inside_result and tag in ("a", "div", "td") and "result__snippet" in classes.split():
            self._capture = "snippet"
            self._buf = []

    def handle_data(self, data):
        if self._capture:
            self._buf.append(data)

    def handle_endtag(self, tag):
        if self._capture and ((self._capture == "title" and tag == "a") or
                              (self._capture == "snippet" and tag in ("a", "div", "td"))):
            value = re.sub(r"\s+", " ", " ".join(self._buf)).strip()
            if self._cur is not None:
                self._cur[self._capture] = value
            self._capture = None
            self._buf = []
        if tag == "div" and self._inside_result:
            self._inside_result -= 1
            if self._inside_result == 0 and self._cur:
                url = self._cur.get("url", "")
                if url:
                    self.results.append(self._cur)
                self._cur = None


class _TextParser(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "header", "footer", "nav"}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in ("p", "div", "br", "li", "h1", "h2", "h3", "h4", "pre", "article"):
            self.parts.append("\n")
    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        elif tag in ("p", "div", "li", "h1", "h2", "h3", "h4", "pre", "article"):
            self.parts.append("\n")
    def handle_data(self, data):
        if not self.skip:
            t = re.sub(r"[\t\r\f\v ]+", " ", data).strip()
            if t:
                self.parts.append(t)
    def text(self):
        lines = [x.strip() for x in " ".join(self.parts).splitlines() if x.strip()]
        return "\n".join(lines)


def _normalise_result_url(url):
    url = html.unescape(str(url or "")).strip()
    if url.startswith("//"):
        url = "https:" + url
    if "duckduckgo.com/l/?" in url:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        url = qs.get("uddg", [url])[0]
    p = urllib.parse.urlsplit(url)
    if p.scheme != "https" or not p.hostname or p.username or p.password:
        return ""
    if p.hostname in ("localhost", "127.0.0.1", "::1"):
        return ""
    return urllib.parse.urlunsplit(("https", p.netloc, p.path, p.query, ""))


def search_web(query: str, limit=6):
    query = re.sub(r"\s+", " ", str(query or "")).strip()
    if not query or len(query) > 300:
        raise ValueError("اكتب عبارة بحث بين 1 و300 حرف")
    url = "https://html.duckduckgo.com/html/?" + urllib.parse.urlencode({"q": query})
    results = []
    try:
        raw, _, charset, _, _ = _fetch(url, limit=MAX_SEARCH_BYTES, timeout=12)
        parser = _SearchParser()
        parser.feed(raw.decode(charset, errors="replace"))
        for item in parser.results:
            dest = _normalise_result_url(item.get("url"))
            if not dest:
                continue
            results.append({"title": item.get("title") or dest, "url": dest,
                            "snippet": item.get("snippet", "")[:1200], "query": query,
                            "source": urllib.parse.urlsplit(dest).hostname})
            if len(results) >= limit:
                break
    except Exception:
        results = []
    if not results:
        # Search fallback: Wikipedia's public search endpoint. This is narrower than web search,
        # and is explicitly identified as an encyclopedia fallback in the result metadata.
        wurl = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
            "action": "query", "list": "search", "srsearch": query, "format": "json",
            "utf8": "1", "srlimit": str(min(limit, 8)),
        })
        raw, _, _, _, _ = _fetch(wurl, accept="application/json", limit=MAX_SEARCH_BYTES)
        data = json.loads(raw.decode("utf-8"))
        for item in data.get("query", {}).get("search", []):
            title = item.get("title", "")
            page = "https://en.wikipedia.org/wiki/" + urllib.parse.quote(title.replace(" ", "_"))
            results.append({"title": title, "url": page,
                            "snippet": re.sub(r"<[^>]+>", "", html.unescape(item.get("snippet", "")))[:1200],
                            "query": query, "source": "wikipedia.org", "fallback": True})
    for result in results:
        save_source(result["url"], result["title"], result["snippet"], "search", "")
    return results[:limit]


def extract_page(url: str):
    safe_url = _normalise_result_url(url)
    if not safe_url:
        raise ValueError("الرابط ليس HTTPS صالحاً")
    raw, content_type, charset, final_url, headers = _fetch(safe_url, limit=MAX_PAGE_BYTES)
    if "html" in content_type:
        parser = _TextParser()
        parser.feed(raw.decode(charset, errors="replace"))
        text = parser.text()
    elif any(x in content_type for x in ("text/", "json", "xml")):
        text = raw.decode(charset, errors="replace")
    else:
        raise ValueError("نوع الملف غير نصي؛ لا يمكن تعلمه كمعرفة نصية")
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return final_url, text[:18000], headers


def _index_full_text(items, source_prefix="learned"):
    """Index complete source text in compact overlapping chunks under the brain's row cap."""
    documents = []
    chunk_size = 9_000
    overlap = 500
    for index, item in enumerate(items if isinstance(items, list) else []):
        if not isinstance(item, dict):
            continue
        source = str(item.get("source", f"{source_prefix}:{index}"))[:220]
        content = str(item.get("content", "")).strip()
        if len(content) < 20:
            continue
        if len(content) <= chunk_size:
            documents.append({"source": source, "content": content})
            continue
        start = 0
        part = 0
        while start < len(content):
            end = min(len(content), start + chunk_size)
            chunk = content[start:end]
            documents.append({"source": f"{source}#part-{part + 1}", "content": chunk})
            if end >= len(content):
                break
            start = end - overlap
            part += 1
    if not documents:
        return {"indexed_documents": 0, "indexed_terms": 0}
    from .brain import brain
    return brain.index_local_data(documents)


def save_source(url, title, snippet, kind="web", body=""):
    url = _normalise_result_url(url)
    if not url:
        return None
    body = str(body or "")[:18000]
    compressed = gzip.compress(body.encode("utf-8"), compresslevel=9) if body else b""
    digest = hashlib.sha256((url + "\0" + body + "\0" + str(snippet)).encode()).hexdigest()
    with store.db() as con:
        con.execute("""INSERT INTO web_sources(url,title,snippet,body_gzip,body_hash,source_type,updated_at)
                    VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(url) DO UPDATE SET title=excluded.title,snippet=excluded.snippet,
                    body_gzip=CASE WHEN length(excluded.body_gzip)>0 THEN excluded.body_gzip ELSE web_sources.body_gzip END,
                    body_hash=excluded.body_hash,source_type=excluded.source_type,updated_at=CURRENT_TIMESTAMP""",
                    (url, str(title or url)[:300], str(snippet or "")[:1200], compressed, digest, kind[:40]))
    indexed = body or str(snippet or "")
    if len(indexed.strip()) >= 24:
        _index_full_text([{"source": url, "content": f"{title}\n{indexed}"}])
    return digest


def learn_url(url, title=None):
    final, text, headers = extract_page(url)
    title = title or final
    save_source(final, title, text[:1200], "page", text)
    return {"url": final, "title": title, "characters": len(text),
            "compressed_kb": round(len(gzip.compress(text.encode("utf-8"), compresslevel=9)) / 1024, 1)}


def evolve_local_knowledge():
    """Re-index user-owned memories and past user prompts locally at every startup.

    Conversation text is never sent to the search provider. Only explicitly saved
    memories and user-authored messages are re-indexed; assistant output is excluded
    to avoid turning generated answers into unquestioned facts.
    """
    state = store.get_state() or {}
    memory_documents = []
    conversation_documents = []
    memories = state.get("mem", []) if isinstance(state, dict) else []
    for item in memories if isinstance(memories, list) else []:
        if not isinstance(item, dict):
            continue
        content = str(item.get("content", "")).strip()
        if len(content) >= 20:
            tags = item.get("tags", [])
            tags_text = " ".join(str(x) for x in tags[:20]) if isinstance(tags, list) else ""
            memory_documents.append({"source": "saved-memory:" + str(item.get("id", "local")),
                                     "content": content + " " + tags_text})
    conversations = state.get("convs", []) if isinstance(state, dict) else []
    for conversation in conversations if isinstance(conversations, list) else []:
        if not isinstance(conversation, dict):
            continue
        cid = str(conversation.get("id", "local"))[:80]
        messages = conversation.get("msgs", [])
        for index, message in enumerate(messages if isinstance(messages, list) else []):
            if not isinstance(message, dict) or message.get("role") != "user":
                continue
            content = str(message.get("content", "")).strip()
            if len(content) >= 30:
                conversation_documents.append({"source": f"conversation:{cid}:user:{index}", "content": content})
    # Keep explicit memories first, then the latest user-authored prompts. This deterministic
    # cap prevents an unusually large browser export from exhausting RAM.
    documents = memory_documents[-100:] + conversation_documents[-200:]
    if documents:
        from .brain import brain
        result = brain.index_local_data(documents)
        with store.db() as con:
            con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)",
                        ("learning.local_evolution", f"documents={result['indexed_documents']}"))
        return result["indexed_documents"]
    return 0


def startup_sync(force=False):
    """Search a small fixed set of technical areas on each explicit server startup.
    Search results and snippets are persisted; page bodies are fetched only for a few
    official domains to keep network use and local storage bounded.
    """
    if not _sync_lock.acquire(blocking=False):
        return {"queries": 0, "results": 0, "errors": ["مزامنة أخرى قيد التنفيذ"]}
    try:
        return _startup_sync_locked(force)
    finally:
        _sync_lock.release()


def _startup_sync_locked(force=False):
    started = _now()
    with store.db() as con:
        con.execute("INSERT INTO learning_runs(status,started_at) VALUES('running',?)", (started,))
        run_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    total = 0
    errors = []
    try:
        local_docs = evolve_local_knowledge()
    except Exception as exc:
        local_docs = 0
        errors.append("الفهرسة المحلية: " + str(exc)[:120])
    for query in SEARCH_QUERIES:
        try:
            results = search_web(query, limit=3)
            total += len(results)
            # Fetch only first-party technical documentation, not arbitrary search targets.
            trusted = ("docs.python.org", "termux.dev", "github.com", "docs.github.com",
                       "docs.godotengine.org", "developer.mozilla.org")
            fetched = 0
            for item in results:
                host = urllib.parse.urlsplit(item["url"]).hostname or ""
                if fetched >= 1 or not any(host == d or host.endswith("." + d) for d in trusted):
                    continue
                try:
                    learn_url(item["url"], item["title"])
                    fetched += 1
                except Exception as exc:
                    errors.append(f"{host}: {str(exc)[:100]}")
        except Exception as exc:
            errors.append(f"{query[:35]}: {str(exc)[:140]}")
    with store.db() as con:
        con.execute("UPDATE learning_runs SET status=?,finished_at=?,query_count=?,results_count=?,error=? WHERE id=?",
                    ("completed" if total else "offline", _now(), len(SEARCH_QUERIES), total,
                     " | ".join(errors[:5])[:1200], run_id))
        con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)",
                    ("learning.startup", f"queries={len(SEARCH_QUERIES)};results={total}"))
    return {"queries": len(SEARCH_QUERIES), "results": total, "local_docs": local_docs, "errors": errors[:5]}


_start_lock = threading.Lock()
_sync_lock = threading.Lock()
_start_thread = None

def start_background_sync():
    global _start_thread
    with _start_lock:
        if _start_thread and _start_thread.is_alive():
            return False
        _start_thread = threading.Thread(target=startup_sync, name="spider-internet-learning", daemon=True)
        _start_thread.start()
        return True


def _github_parts(url):
    p = urllib.parse.urlsplit(str(url or "").strip())
    if p.scheme != "https" or p.hostname not in ("github.com", "www.github.com"):
        raise ValueError("أدخل رابط مستودع أو ملف من github.com فقط")
    raw_parts = [x for x in p.path.strip("/").split("/") if x]
    parts = [urllib.parse.unquote(x) for x in raw_parts]
    if len(parts) < 2:
        raise ValueError("رابط GitHub يجب أن يتضمن owner/repository")
    owner, repo = parts[0], parts[1].removesuffix(".git")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", owner) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", repo):
        raise ValueError("اسم مالك أو مستودع غير صالح")
    ref = ""
    path = ""
    if len(raw_parts) >= 4 and parts[2] in ("tree", "blob"):
        # GitHub encodes branch names containing '/' inside one path segment (%2F).
        ref = urllib.parse.unquote(raw_parts[3])
        path = "/".join(urllib.parse.unquote(x) for x in raw_parts[4:])
        if not re.fullmatch(r"[A-Za-z0-9_./-]{1,200}", ref) or ".." in PurePosixPath(ref).parts:
            raise ValueError("فرع GitHub غير صالح")
    return owner, repo, ref, path


def _github_json(url, limit=MAX_SEARCH_BYTES):
    raw, _, _, _, headers = _fetch(url, accept="application/vnd.github+json", limit=limit)
    return json.loads(raw.decode("utf-8")), headers


def _repo_file_priority(path):
    p = path.lower()
    name = PurePosixPath(p).name
    if name.startswith(("readme", "license", "copying", "contributing", "changelog")) or name in ("spider_skill.json", "spider-skill.json"):
        return 0
    if p.startswith(("docs/", "doc/", "examples/", "example/", ".github/")):
        return 1
    if p.startswith(("src/", "lib/", "app/", "packages/")):
        return 2
    if "/test" in p or p.startswith(("test/", "tests/")):
        return 3
    if name in ("pyproject.toml", "package.json", "cargo.toml", "go.mod", "requirements.txt", "setup.py"):
        return 1
    return 5


def _is_text_repo_file(path):
    p = path.lower()
    if any(x in p for x in ("node_modules/", "vendor/", "dist/", "build/", ".git/", "__pycache__/")):
        return False
    suffix = PurePosixPath(p).suffix
    return suffix in {".md", ".mdx", ".rst", ".txt", ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".json", ".toml", ".yaml", ".yml", ".java", ".kt", ".go", ".rs", ".html", ".css", ".sh", ".xml", ".sql", ".gd", ".cs", ".swift", ".ipynb"} or PurePosixPath(p).name.lower() in {"dockerfile", "makefile"}



def _extract_python_api(path, source):
    """Extract public Python signatures/docstrings as reference metadata only."""
    import ast
    if not path.lower().endswith((".py", ".pyi")):
        return []
    try:
        tree = ast.parse(source[:MAX_REPO_FILE_BYTES])
    except (SyntaxError, ValueError):
        return []
    found = []
    def fmt(node):
        try:
            return ast.unparse(node)
        except Exception:
            return "?"
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
            args = [a.arg + (":" + fmt(a.annotation) if a.annotation else "") for a in node.args.args]
            signature = f"{node.name}({', '.join(args)})"
            doc = (ast.get_docstring(node) or "").strip()
            found.append({"kind": "async-function" if isinstance(node, ast.AsyncFunctionDef) else "function",
                          "name": node.name, "signature": signature, "doc": doc[:700], "path": path})
        elif isinstance(node, ast.ClassDef) and not node.name.startswith("_"):
            doc = (ast.get_docstring(node) or "").strip()
            methods = []
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and not child.name.startswith("_"):
                    args = [a.arg for a in child.args.args]
                    methods.append(f"{child.name}({', '.join(args)})")
            found.append({"kind": "class", "name": node.name, "signature": node.name,
                          "doc": doc[:700], "methods": methods[:30], "path": path})
    return found[:80]


def _compile_python_function(path, source):
    """Port one very small, pure Python function into the closed Spider DSL.

    Only a single public positional parameter and a single return expression are
    eligible. This is AST translation, never eval/exec/import or source execution.
    """
    import ast
    try:
        tree = ast.parse(source[:MAX_REPO_FILE_BYTES])
    except (SyntaxError, ValueError):
        return None
    from .skill_runtime import validate_manifest
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or node.name.startswith("_"):
            continue
        if node.decorator_list or node.args.vararg or node.args.kwarg or node.args.kwonlyargs:
            continue
        args = node.args.posonlyargs + node.args.args
        if len(args) != 1 or node.args.defaults:
            continue
        param = args[0].arg
        body = [x for x in node.body if not (isinstance(x, ast.Expr) and isinstance(x.value, ast.Constant) and isinstance(x.value.value, str))]
        if len(body) != 1 or not isinstance(body[0], ast.Return) or body[0].value is None:
            continue
        steps = []
        step_no = 0

        def constant(n):
            if isinstance(n, ast.Constant) and isinstance(n.value, (str, int, float, bool, type(None))):
                return n.value
            raise ValueError("non-constant parameter")

        def emit(op, source_ref, params=None):
            nonlocal step_no
            step_no += 1
            step_id = f"s{step_no}"
            steps.append({"id": step_id, "op": op, "from": source_ref, "params": params or {}})
            return step_id

        def compile_expr(expr):
            if isinstance(expr, ast.Name) and expr.id == param:
                return "input." + param
            if isinstance(expr, ast.Call):
                # Pure string/collection methods on the sole input value.
                if isinstance(expr.func, ast.Attribute):
                    method = expr.func.attr
                    source_ref = compile_expr(expr.func.value)
                    if method in ("strip", "lower", "upper", "capitalize", "title", "split"):
                        if len(expr.args) > 1 or expr.keywords:
                            raise ValueError("unsupported arguments")
                        params = {}
                        if method == "split":
                            if expr.args:
                                params["separator"] = constant(expr.args[0])
                                op = "text.split"
                            else:
                                op = "text.split_whitespace"
                        else:
                            op = "text." + method
                        return emit(op, source_ref, params)
                    if method == "replace":
                        if not 2 <= len(expr.args) <= 3 or expr.keywords:
                            raise ValueError("unsupported replace")
                        params = {"old": constant(expr.args[0]), "new": constant(expr.args[1])}
                        if len(expr.args) == 3: params["count"] = constant(expr.args[2])
                        return emit("text.replace", source_ref, params)
                    raise ValueError("unsupported method")
                if isinstance(expr.func, ast.Name) and expr.func.id in ("len", "sum", "sorted", "min", "max", "set", "str"):
                    if len(expr.args) != 1 or expr.keywords:
                        raise ValueError("unsupported builtin arguments")
                    source_ref = compile_expr(expr.args[0])
                    mapping = {"len": "text.length", "sum": "list.sum", "sorted": "list.sort",
                               "min": "list.min", "max": "list.max", "set": "list.unique", "str": "value.stringify"}
                    return emit(mapping[expr.func.id], source_ref)
                # re.sub(pattern, replacement, input) with literal arguments only.
                if (isinstance(expr.func, ast.Attribute) and isinstance(expr.func.value, ast.Name)
                        and expr.func.value.id == "re" and expr.func.attr == "sub" and len(expr.args) == 3):
                    pattern, replacement = constant(expr.args[0]), constant(expr.args[1])
                    source_ref = compile_expr(expr.args[2])
                    return emit("text.regex_replace", source_ref, {"pattern": pattern, "replacement": replacement})
                raise ValueError("unsupported call")
            raise ValueError("unsupported expression")

        try:
            output_ref = compile_expr(body[0].value)
            if output_ref.startswith("input."):
                output_ref = emit("value.identity", output_ref)
            if not steps or len(steps) > 30:
                continue
            spec = validate_manifest({"name": node.name, "description": ast.get_docstring(node) or "دالة Python نقية تم تحويلها من AST إلى Spider DSL.",
                                     "inputs": {param: "any"}, "steps": steps, "output": output_ref})
            return {"function": node.name, "path": path, "manifest": spec,
                    "translation": "safe-ast-subset", "source_executed": False}
        except Exception:
            continue
    return None


def _extract_js_api(path, source):
    """Extract exported JavaScript/TypeScript declarations without executing code."""
    if not path.lower().endswith((".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx")):
        return []
    found = []
    patterns = [
        ("function", re.compile(r"export\s+(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)")),
        ("class", re.compile(r"export\s+class\s+([A-Za-z_$][\w$]*)")),
        ("const", re.compile(r"export\s+(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>")),
    ]
    for kind, pattern in patterns:
        for m in pattern.finditer(source[:MAX_REPO_FILE_BYTES]):
            found.append({"kind": kind, "name": m.group(1),
                          "signature": f"{m.group(1)}({m.group(2)})" if m.lastindex and m.lastindex > 1 else m.group(1),
                          "doc": "", "path": path})
            if len(found) >= 80:
                return found
    return found

def import_github(url: str):
    owner, repo, ref, requested_path = _github_parts(url)
    api_base = f"https://api.github.com/repos/{owner}/{repo}"
    meta, _ = _github_json(api_base)
    branch = ref or meta.get("default_branch") or "main"
    full_name = meta.get("full_name") or f"{owner}/{repo}"
    license_name = (meta.get("license") or {}).get("spdx_id") or "غير محدد من بيانات المستودع"
    if meta.get("private"):
        raise ValueError("المستودع خاص ولا يمكن الوصول إليه دون تسجيل دخول؛ لا يرسل Spider بيانات اعتماد")
    tree, _ = _github_json(api_base + "/git/trees/" + urllib.parse.quote(branch, safe="") + "?recursive=1",
                           limit=MAX_GITHUB_TREE_BYTES)
    if tree.get("truncated"):
        tree_items = tree.get("tree", [])[:5000]
    else:
        tree_items = tree.get("tree", [])
    files = [x for x in tree_items if x.get("type") == "blob" and _is_text_repo_file(x.get("path", ""))]
    if requested_path:
        requested_path = requested_path.strip("/")
        files = [x for x in files if x.get("path") == requested_path or x.get("path", "").startswith(requested_path + "/")]
        if not files:
            raise ValueError("لم يتم العثور على الملف/المجلد المطلوب داخل المستودع")
    files.sort(key=lambda x: (_repo_file_priority(x.get("path", "")), x.get("path", "").count("/"), x.get("path", "")))
    selected = []
    total_size = 0
    for item in files:
        size = int(item.get("size", 0) or 0)
        if size <= 0 or size > MAX_REPO_FILE_BYTES or total_size + size > MAX_REPO_TOTAL_BYTES:
            continue
        selected.append(item)
        total_size += size
        if len(selected) >= MAX_REPO_FILES:
            break
    if not selected:
        raise ValueError("لا توجد ملفات نصية صغيرة مناسبة للتعلّم في هذا الرابط")

    content_items = []
    downloaded = 0
    for item in selected:
        path = item["path"]
        raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{urllib.parse.quote(branch, safe='/')}/{urllib.parse.quote(path, safe='/')}"
        try:
            raw, _, charset, _, _ = _fetch(raw_url, accept="text/plain,*/*", limit=MAX_REPO_FILE_BYTES, timeout=18)
            text = raw.decode(charset, errors="replace")
            if "\x00" in text[:2000]:
                continue
            if path.lower().endswith(".ipynb"):
                try:
                    nb = json.loads(text)
                    text = "\n\n".join("".join(c.get("source", [])) for c in nb.get("cells", []) if c.get("cell_type") in ("markdown", "code"))
                except Exception:
                    continue
            text = text[:MAX_REPO_FILE_BYTES]
            if len(text.strip()) < 15:
                continue
            content_items.append({"path": path, "content": text, "bytes": len(raw)})
            downloaded += len(raw)
        except Exception:
            continue
    if not content_items:
        raise RuntimeError("تم الوصول للمستودع لكن لم يمكن تنزيل أي ملف نصي مناسب")

    summary = str(meta.get("description") or f"مستودع {full_name}")[:500]
    root_readme = next((x["content"] for x in content_items if PurePosixPath(x["path"]).name.lower().startswith("readme")), "")
    api_symbols = []
    for item in content_items:
        api_symbols.extend(_extract_python_api(item["path"], item["content"]))
        api_symbols.extend(_extract_js_api(item["path"], item["content"]))
        if len(api_symbols) >= 240:
            api_symbols = api_symbols[:240]
            break
    runtime_manifest = None
    dsl_file = next((x for x in content_items if PurePosixPath(x["path"]).name.lower() in ("spider_skill.json", "spider-skill.json")), None)
    auto_compiled = None
    if dsl_file:
        try:
            from .skill_runtime import validate_manifest
            runtime_manifest = validate_manifest(json.loads(dsl_file["content"]))
        except Exception as exc:
            raise ValueError("وجد Spider ملف تعريف مهارة لكنه غير صالح: " + str(exc)[:180]) from exc
    else:
        candidates = []
        for source_file in content_items:
            if source_file["path"].lower().endswith((".py", ".pyi")):
                compiled = _compile_python_function(source_file["path"], source_file["content"])
                if compiled:
                    candidates.append(compiled)
        if candidates:
            # Prefer an operation with a useful docstring; do not silently compile a
            # complex dependency graph or combine unrelated repository functions.
            candidates.sort(key=lambda x: (bool(x["manifest"]["description"]), len(x["manifest"]["steps"])), reverse=True)
            auto_compiled = candidates[0]
            runtime_manifest = auto_compiled["manifest"]
    slug = re.sub(r"[^a-z0-9-]+", "-", f"{owner}-{repo}".lower()).strip("-")[:70]
    skill_name = full_name + " — مهارة محلية"
    skill_doc = (
        f"# {skill_name}\n\nالمصدر: {meta.get('html_url', url)}\n\n"
        f"الوصف: {summary}\n\nالترخيص: {license_name}\n\n"
        "## طريقة استخدام المهارة داخل SPIDER\n" +
        (("تم تحويل دالة Python نقية واحدة إلى Spider DSL بتحليل AST دون تشغيل المصدر؛ بقية الملفات مرجعية.\n\n"
          if auto_compiled else
          "يحتوي المستودع على تعريف SPIDER_SKILL.json متوافق؛ يمكن تشغيل خطواته داخل بيئة Spider DSL المحدودة.\n\n") if runtime_manifest else
         "هذه حزمة معرفة محلية مفهرسة من مستودع عام. اسأل SPIDER عن اسم المكتبة أو ملف أو وظيفة؛ "
         "سيسترجع المقاطع ذات الصلة من الملفات المحفوظة. الشيفرة لا تُنفّذ تلقائياً.\n\n") +
        "## ما الذي تم استيراده؟\n" + "\n".join(f"- `{x['path']}` ({len(x['content'])} حرف)" for x in content_items) +
        "\n\n## واجهات Python/JavaScript المكتشفة (تحليل ساكن)\n\n" +
        ("\n".join(f"- `{x['signature']}` — {x['path']}\n  {x['doc']}" for x in api_symbols[:100]) if api_symbols else "لم يتم اكتشاف واجهات عامة") +
        "\n\n## ملخص README\n\n" + root_readme[:12000]
    )
    manifest = {
        "id": slug, "name": skill_name, "repository": full_name,
        "source_url": meta.get("html_url", url), "branch": branch,
        "description": summary, "license": license_name,
        "files": [{"path": x["path"], "bytes": x["bytes"], "sha256": hashlib.sha256(x["content"].encode()).hexdigest()} for x in content_items],
        "downloaded_bytes": downloaded, "file_count": len(content_items),
        "api_symbols": api_symbols,
        "created_at": _now(), "execution": "safe-declarative-runtime" if runtime_manifest else "knowledge-only; imported code is not executed",
        "runtime": "spider-dsl-v1" if runtime_manifest else "reference-only",
        "runtime_manifest": runtime_manifest,
        "auto_compiled_function": auto_compiled["function"] if auto_compiled else None,
        "translation": auto_compiled["translation"] if auto_compiled else ("explicit-spider-dsl" if dsl_file else None),
        "limitations": ["تعلّم الوثائق والأنماط والأمثلة لا يعادل تشغيل الاعتماديات الأصلية.",
                        "المكتبات الأصلية التي تحتاج إلى مترجم أو ملفات native أو خادم لا تصبح مكافئة لمجرد فهرسة مصدرها."]
    }
    _persist_skill(slug, skill_name, meta.get("html_url", url), summary, manifest, content_items, skill_doc)
    docs = [{"source": f"github:{full_name}:{x['path']}",
             "content": f"{skill_name}\n{x['path']}\n{x['content']}"} for x in content_items]
    _index_full_text(docs, f"github:{full_name}")
    return {"skill": slug, "name": skill_name, "repository": full_name,
            "files_learned": len(content_items), "bytes_learned": downloaded,
            "license": license_name, "summary": summary,
            "api_symbols": len(api_symbols), "runtime": "spider-dsl-v1" if runtime_manifest else "reference-only",
        "note": ("تم استيراد تعريف SPIDER_SKILL.json، وأصبحت خطواته تعمل داخل محرك Spider الآمن." if dsl_file and runtime_manifest else
                 (f"حوّل Spider الدالة النقية {auto_compiled['function']} من {auto_compiled['path']} إلى Spider DSL عبر تحليل AST دون تشغيل المصدر. الوظائف الأخرى تبقى مرجعية." if auto_compiled else
                  "تم حفظ الملفات وفهرستها واستخراج واجهاتها العامة. لم يتم تثبيت أو تشغيل الشيفرة الأصلية؛ المهارة مرجعية وليست بديلاً تنفيذياً مكافئاً."))}


def _persist_skill(slug, name, source_url, summary, manifest, files, skill_doc):
    data_dir = DATA_DIR / "skills" / slug
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "SKILL.md").write_text(skill_doc, encoding="utf-8")
    (data_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    # Source files are stored once, compressed in SQLite. The on-disk skill folder
    # contains only its small manifest and operator-facing SKILL.md file.
    packed = gzip.compress(json.dumps(manifest, ensure_ascii=False).encode(), compresslevel=9)
    with store.db() as con:
        con.execute("DELETE FROM skill_files WHERE skill_id=?", (slug,))
        con.execute("""INSERT INTO skills(id,name,source_url,summary,manifest_gzip,created_at,updated_at)
                     VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                     ON CONFLICT(id) DO UPDATE SET name=excluded.name,source_url=excluded.source_url,
                     summary=excluded.summary,manifest_gzip=excluded.manifest_gzip,updated_at=CURRENT_TIMESTAMP""",
                    (slug, name[:200], source_url[:1000], summary[:1000], packed, _now()))
        for item in files:
            body_gzip = gzip.compress(item["content"].encode("utf-8"), compresslevel=9)
            con.execute("""INSERT OR REPLACE INTO skill_files(skill_id,path,body_gzip,byte_count,sha256)
                         VALUES(?,?,?,?,?)""", (slug, item["path"], body_gzip, item["bytes"],
                         hashlib.sha256(item["content"].encode()).hexdigest()))
        con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)", ("skill.import", slug))


def learn_uploaded_file(name, content):
    name = PurePosixPath(str(name or "uploaded.txt").replace("\\", "/")).name[:120]
    content = str(content or "")
    if not content.strip():
        raise ValueError("الملف فارغ أو غير نصّي")
    if len(content.encode("utf-8")) > MAX_REPO_FILE_BYTES:
        raise ValueError("الملف يتجاوز الحد الحالي 160 كيلوبايت لكل ملف")
    if name.lower() in ("spider_skill.json", "spider-skill.json"):
        try:
            from .skill_runtime import validate_manifest, create_skill
            spec = validate_manifest(json.loads(content))
        except Exception as exc:
            raise ValueError("تعريف SPIDER_SKILL.json غير صالح: " + str(exc)[:180]) from exc
        result = create_skill(spec["name"], spec["description"], spec["steps"], spec["inputs"], spec["output"])
        result.update({"files_learned": 1, "bytes_learned": len(content.encode()),
                       "note": "تم تحويل تعريف SPIDER_SKILL.json إلى مهارة تنفيذية محلية آمنة."})
        return result
    slug = re.sub(r"[^a-z0-9-]+", "-", Path(name).stem.lower()).strip("-")[:60] or "uploaded-file"
    slug += "-" + hashlib.sha1((name + content[:500]).encode()).hexdigest()[:8]
    item = {"path": name, "content": content, "bytes": len(content.encode())}
    manifest = {"id": slug, "name": name + " — معرفة محلية", "source_url": "local-upload://" + name,
                "description": "ملف رفعه المستخدم وتم حفظ محتواه وفهرسته.", "license": "ملف المستخدم",
                "files": [{"path": name, "bytes": item["bytes"]}], "created_at": _now(),
                "execution": "knowledge-only; never executed"}
    skill_doc = f"# {name}\n\nملف محلي أضافه المستخدم.\n\n## المحتوى\n\n{content[:12000]}"
    _persist_skill(slug, name, "local-upload://" + name, "ملف معرفة محلي", manifest, [item], skill_doc)
    _index_full_text([{"source": f"upload:{name}", "content": content}])
    return {"skill": slug, "name": name, "files_learned": 1, "bytes_learned": item["bytes"],
            "note": "حُفظ الملف كمهارة معرفية محلية؛ لم تُشغّل شيفرته."}



def learn_uploaded_archive(name, archive_b64):
    try:
        raw = base64.b64decode(str(archive_b64 or ""), validate=True)
    except (binascii.Error, ValueError):
        raise ValueError("ترميز ملف ZIP غير صالح")
    if not raw or len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError("حجم ملف ZIP يجب ألا يتجاوز 8 ميغابايت")
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile as exc:
        raise ValueError("الملف ليس أرشيف ZIP صالحاً") from exc
    files = []
    total = 0
    with zf:
        archive_infos = zf.infolist()
        if len(archive_infos) > 5000:
            raise ValueError("ملف ZIP يحتوي عدداً مفرطاً من العناصر")
        for info in archive_infos:
            if info.is_dir() or len(files) >= MAX_ARCHIVE_FILES:
                continue
            path = info.filename.replace("\\", "/")
            posix = PurePosixPath(path)
            if "\x00" in path or posix.is_absolute() or ".." in posix.parts or not _is_text_repo_file(path):
                continue
            if info.file_size <= 0 or info.file_size > MAX_REPO_FILE_BYTES or total + info.file_size > MAX_ARCHIVE_TOTAL_BYTES:
                continue
            # Reject Unix symbolic links and suspicious compression ratios.
            mode = (info.external_attr >> 16) & 0o170000
            if mode == 0o120000 or (info.compress_size and info.file_size / info.compress_size > 120):
                continue
            try:
                body = zf.read(info)
                if b"\x00" in body[:2048]:
                    continue
                text = body.decode("utf-8", errors="replace")[:MAX_REPO_FILE_BYTES]
            except Exception:
                continue
            if len(text.strip()) < 15:
                continue
            files.append({"path": str(posix), "content": text, "bytes": len(body)})
            total += len(body)
    if not files:
        raise ValueError("لم أجد ملفات نصية آمنة وقابلة للتعلّم داخل الأرشيف")
    base = Path(str(name or "project.zip")).stem.lower()
    slug = re.sub(r"[^a-z0-9-]+", "-", base).strip("-")[:55] or "uploaded-project"
    slug += "-" + hashlib.sha1(raw).hexdigest()[:8]
    manifest = {"id": slug, "name": Path(str(name or "project.zip")).name + " — مهارة محلية",
                "source_url": "local-upload://" + Path(str(name or "project.zip")).name,
                "description": "مشروع ZIP رفعه المستخدم وتم انتقاء ملفاته النصية وفهرستها.",
                "license": "ملف المستخدم", "files": [{"path": x["path"], "bytes": x["bytes"]} for x in files],
                "created_at": _now(), "execution": "knowledge-only; never executed",
                "runtime": "reference-only", "runtime_manifest": None}
    descriptor = next((x for x in files if PurePosixPath(x["path"]).name.lower() in ("spider_skill.json", "spider-skill.json")), None)
    if descriptor:
        try:
            from .skill_runtime import validate_manifest
            manifest["runtime_manifest"] = validate_manifest(json.loads(descriptor["content"]))
            manifest["runtime"] = "spider-dsl-v1"
            manifest["execution"] = "safe-declarative-runtime"
        except Exception as exc:
            raise ValueError("تعريف SPIDER_SKILL.json داخل ZIP غير صالح: " + str(exc)[:180]) from exc
    skill_doc = "# " + manifest["name"] + "\n\nحزمة محلية استخرج Spider ملفاتها النصية فقط.\n\n## الملفات\n" + \
                "\n".join("- `" + x["path"] + "`" for x in files) + \
                "\n\nلا يتم تشغيل أي شيفرة من الأرشيف تلقائياً."
    _persist_skill(slug, manifest["name"], manifest["source_url"], manifest["description"], manifest, files, skill_doc)
    _index_full_text([{"source": f"upload-zip:{name}:{x['path']}", "content": x["content"]} for x in files])
    return {"skill": slug, "name": manifest["name"], "files_learned": len(files),
            "bytes_learned": total, "runtime": manifest.get("runtime", "reference-only"),
            "note": ("استُخرجت الملفات النصية وفُهرست وضُغطت محلياً؛ وتم تحويل وصف Spider DSL إلى مهارة قابلة للتنفيذ." if descriptor and manifest.get("runtime") == "spider-dsl-v1" else
                     "استُخرجت الملفات النصية وفُهرست وضُغطت محلياً؛ لم تُشغّل الشيفرة الأصلية.")}

def list_skills():
    with store.db() as con:
        rows = con.execute("SELECT id,name,source_url,summary,manifest_gzip,created_at,updated_at FROM skills ORDER BY updated_at DESC").fetchall()
        counts = {r["skill_id"]: r["n"] for r in con.execute("SELECT skill_id,COUNT(*) AS n FROM skill_files GROUP BY skill_id")}
    out = []
    for row in rows:
        try:
            manifest = json.loads(gzip.decompress(row["manifest_gzip"]).decode("utf-8"))
        except Exception:
            manifest = {}
        out.append({"id": row["id"], "name": row["name"], "source_url": row["source_url"],
                    "summary": row["summary"], "created_at": row["created_at"],
                    "updated_at": row["updated_at"], "files": counts.get(row["id"], 0),
                    "runtime": manifest.get("runtime", "reference-only"),
                    "api_symbols": len(manifest.get("api_symbols", [])),
                    "can_run": manifest.get("runtime") == "spider-dsl-v1"})
    return out


def search_sources(query, limit=8):
    query = str(query or "").strip()
    if not query:
        raise ValueError("عبارة البحث مطلوبة")
    with store.db() as con:
        rows = con.execute("""SELECT title,url,snippet,source_type,updated_at FROM web_sources
                           WHERE title LIKE ? OR snippet LIKE ? ORDER BY updated_at DESC LIMIT ?""",
                           ("%" + query[:100] + "%", "%" + query[:100] + "%", max(1,min(limit,20)))).fetchall()
    return [dict(r) for r in rows]


def status():
    with store.db() as con:
        last = con.execute("SELECT status,started_at,finished_at,query_count,results_count,error FROM learning_runs ORDER BY id DESC LIMIT 1").fetchone()
        sources = con.execute("SELECT COUNT(*) FROM web_sources").fetchone()[0]
        pages = con.execute("SELECT COUNT(*) FROM web_sources WHERE length(body_gzip)>0").fetchone()[0]
        skills = con.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
        learned_files = con.execute("SELECT COUNT(*) FROM skill_files").fetchone()[0]
        indexed_docs = con.execute("SELECT COUNT(*) FROM model_docs").fetchone()[0]
    return {"last_run": dict(last) if last else None, "sources": sources, "full_pages": pages,
            "skills": skills, "skill_files": learned_files, "indexed_docs": indexed_docs,
            "mode": "internet-search + local-persistent-learning"}
