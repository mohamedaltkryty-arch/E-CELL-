"""Small, fully local adaptive intent model trained from explicit user corrections.

This is a compact multinomial Naive Bayes classifier, not a generative LLM.
It learns only from labelled examples the user deliberately submits.
"""
from __future__ import annotations
import gzip
import json
import math
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from . import database as store

VALID_INTENTS = {
    "chat", "greeting", "help", "cells", "memory", "remember", "security",
    "math", "plan", "analyze", "build"
}
TOKEN_RE = re.compile(r"[\u0621-\u064A\u0660-\u0669A-Za-z0-9_]+")
DIACRITICS = re.compile(r"[\u064B-\u065F\u0670\u0640]")
STOP = set("في من على الى إلى عن مع هذا هذه ذلك تلك هو هي انا نحن انت ان أن كان تكون يتم تم قد ما لا لم لن هل او أو ثم كما بعد قبل عند بين كل بعض جدا فقط الآن أيضا ايضا كيف لماذا ماذا متى أين اين أي إذا اذا".split())
MODEL_VERSION = 1


def normalize(text: str) -> str:
    value = unicodedata.normalize("NFKC", str(text or ""))
    return DIACRITICS.sub("", value).replace("ـ", "").lower()


def features(text: str):
    value = normalize(text)
    words = [x for x in TOKEN_RE.findall(value) if len(x) > 1 and x not in STOP]
    out = Counter("w:" + x for x in words)
    # Character trigrams retain useful morphology and tolerate spelling variants.
    compact = " " + re.sub(r"\s+", " ", value)[:1200] + " "
    compact = compact[:600]
    for i in range(0, max(0, len(compact) - 2), 2):
        tri = compact[i:i + 3]
        if not tri.isspace() and len(tri.strip()) >= 2:
            out["c:" + tri] += 1
    return out


def _model_path():
    folder = Path(store.DATA_DIR) / "models"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "adaptive_intent.json.gz"


def add_example(prompt: str, correction: str, intent: str):
    prompt = str(prompt or "").strip()
    correction = str(correction or "").strip()
    intent = str(intent or "").strip().lower()
    if intent not in VALID_INTENTS:
        raise ValueError("تصنيف التعلّم غير صالح")
    if len(prompt) < 3 or len(prompt) > 8000:
        raise ValueError("نص الطلب يجب أن يتراوح بين 3 و8000 حرف")
    if len(correction) < 2 or len(correction) > 12000:
        raise ValueError("التصحيح يجب أن يتراوح بين حرفين و12000 حرف")
    with store.db() as con:
        row = con.execute("SELECT id FROM adaptive_examples WHERE prompt=? AND intent=?", (prompt, intent)).fetchone()
        if row:
            example_id = int(row["id"])
            con.execute("UPDATE adaptive_examples SET correction=?,created_at=CURRENT_TIMESTAMP WHERE id=?",
                        (correction, example_id))
        else:
            cur = con.execute(
                "INSERT INTO adaptive_examples(prompt,correction,intent) VALUES(?,?,?)",
                (prompt, correction, intent))
            example_id = cur.lastrowid
    train()
    store.event("adaptive.feedback", f"example={example_id};intent={intent}")
    return {"id": example_id, "intent": intent, "examples": count_examples(),
            "model": "local-naive-bayes-v1"}


def _load_examples():
    with store.db() as con:
        return [dict(x) for x in con.execute(
            "SELECT id,prompt,correction,intent,created_at FROM adaptive_examples ORDER BY id DESC LIMIT 300")]


def count_examples():
    with store.db() as con:
        return int(con.execute("SELECT COUNT(*) FROM adaptive_examples").fetchone()[0])


def train():
    examples = _load_examples()
    class_docs = Counter()
    class_terms = defaultdict(Counter)
    class_totals = Counter()
    vocab = set()
    for item in examples:
        label = item["intent"]
        feats = features(item["prompt"])
        if not feats:
            continue
        class_docs[label] += 1
        for feat, amount in feats.items():
            # Cap each feature per sample to reduce repeated-token domination.
            amount = min(int(amount), 4)
            class_terms[label][feat] += amount
            class_totals[label] += amount
            vocab.add(feat)
    labels = sorted(class_docs)
    model = {
        "version": MODEL_VERSION,
        "trained_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
        "examples": len(examples),
        "labels": labels,
        "class_docs": dict(class_docs),
        "class_totals": dict(class_totals),
        "vocab_size": len(vocab),
        "terms": {label: dict(counts) for label, counts in class_terms.items()},
    }
    path = _model_path()
    raw = json.dumps(model, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    path.write_bytes(gzip.compress(raw, compresslevel=9))
    return model


def _read_model():
    path = _model_path()
    if not path.exists():
        return train()
    try:
        return json.loads(gzip.decompress(path.read_bytes()).decode("utf-8"))
    except Exception:
        return train()


def predict(text: str):
    model = _read_model()
    labels = model.get("labels", [])
    if not labels or not model.get("examples"):
        return None
    query = features(text)
    if not query:
        return None
    class_docs = model["class_docs"]
    terms = model["terms"]
    vocab_size = max(1, int(model.get("vocab_size", 1)))
    total_docs = sum(class_docs.values())
    scores = {}
    for label in labels:
        docs = class_docs[label]
        score = math.log((docs + 1) / (total_docs + len(labels)))
        counts = terms.get(label, {})
        denom = int(model["class_totals"].get(label, 0)) + vocab_size
        for feature, amount in query.items():
            tf = int(counts.get(feature, 0))
            # Include absent features in the likelihood; otherwise a class with zero
            # matching vocabulary would incorrectly receive an artificially high score.
            score += min(amount, 3) * math.log((tf + 1) / denom)
        scores[label] = score
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    # Convert log-score separation to a stable confidence estimate.
    peak = ranked[0][1]
    exps = [math.exp(max(-40, value - peak)) for _, value in ranked]
    confidence = exps[0] / max(1e-12, sum(exps))
    margin = (ranked[0][1] - ranked[1][1]) if len(ranked) > 1 else 99.0
    return {"intent": ranked[0][0], "confidence": round(confidence, 4),
            "margin": round(margin, 4), "examples": int(model["examples"]),
            "label_examples": int(class_docs[ranked[0][0]]),
            "scores": {k: round(v, 4) for k, v in ranked[:5]}}


def retrieve_corrections(prompt: str, limit=3):
    q = features(prompt)
    if not q:
        return []
    qset = set(q)
    ranked = []
    for item in _load_examples():
        d = features(item["prompt"])
        dset = set(d)
        if not dset:
            continue
        overlap = len(qset & dset)
        score = overlap / max(1, len(qset | dset))
        # Token overlap is independently weighted to avoid noisy char-only matches.
        qw = {x for x in qset if x.startswith("w:")}
        dw = {x for x in dset if x.startswith("w:")}
        wscore = len(qw & dw) / max(1, len(qw | dw)) if qw or dw else 0
        score = 0.35 * score + 0.65 * wscore
        if score > 0:
            ranked.append((score, item))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return [{"prompt": x[1]["prompt"], "correction": x[1]["correction"],
             "intent": x[1]["intent"], "similarity": round(x[0], 4)}
            for x in ranked[:max(1, min(int(limit), 5))]]


def status():
    examples = _load_examples()
    by_intent = dict(Counter(x["intent"] for x in examples))
    path = _model_path()
    model = _read_model()
    return {"type": "multinomial-naive-bayes", "version": MODEL_VERSION,
            "examples": count_examples(), "trained_examples": int(model.get("examples", 0)),
            "labels": by_intent,
            "model_bytes": path.stat().st_size if path.exists() else 0,
            "trained_at": model.get("trained_at"),
            "generative_llm": False,
            "description": "نموذج تصنيف محلي يتعلم من التصحيحات المعلّمة؛ لا يولّد لغة حرة."}
