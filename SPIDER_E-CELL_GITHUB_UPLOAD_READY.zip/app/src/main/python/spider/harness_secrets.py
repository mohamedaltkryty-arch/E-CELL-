"""Android Keystore-backed storage for Harness provider credentials."""
from __future__ import annotations

import base64
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ALIAS = "spider.ecell.harness.credentials.v1"


class HarnessSecretError(RuntimeError):
    pass


def _android_crypto():
    try:
        from java import jclass
        KeyStore = jclass("java.security.KeyStore")
        KeyGenerator = jclass("javax.crypto.KeyGenerator")
        Cipher = jclass("javax.crypto.Cipher")
        GCMParameterSpec = jclass("javax.crypto.spec.GCMParameterSpec")
        KeyGenParameterSpecBuilder = jclass("android.security.keystore.KeyGenParameterSpec$Builder")
        KeyProperties = jclass("android.security.keystore.KeyProperties")
        return KeyStore, KeyGenerator, Cipher, GCMParameterSpec, KeyGenParameterSpecBuilder, KeyProperties
    except Exception as exc:
        raise HarnessSecretError("Android Keystore غير متاح") from exc


def _get_key(create: bool):
    KeyStore, KeyGenerator, _, _, Builder, Properties = _android_crypto()
    store = KeyStore.getInstance("AndroidKeyStore")
    store.load(None)
    if store.containsAlias(ALIAS):
        return store.getKey(ALIAS, None)
    if not create:
        return None
    purposes = Properties.PURPOSE_ENCRYPT | Properties.PURPOSE_DECRYPT
    spec = (Builder(ALIAS, purposes)
            .setBlockModes([Properties.BLOCK_MODE_GCM])
            .setEncryptionPaddings([Properties.ENCRYPTION_PADDING_NONE])
            .setRandomizedEncryptionRequired(True)
            .build())
    generator = KeyGenerator.getInstance(Properties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(spec)
    return generator.generateKey()


def _credential_path(data_dir: str) -> Path:
    root = Path(data_dir).resolve() / "harness"
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    return root / "credentials.enc"


def save_credentials(data_dir: str, provider: str, model: str, api_key: str) -> dict[str, Any]:
    provider, model, api_key = str(provider).strip(), str(model).strip(), str(api_key).strip()
    if not provider or len(provider) > 100 or not model or len(model) > 160:
        raise HarnessSecretError("اسم مزود النموذج أو النموذج غير صالح")
    if not api_key or len(api_key) > 4096 or any(ord(c) < 32 for c in api_key):
        raise HarnessSecretError("مفتاح API غير صالح")
    KeyStore, KeyGenerator, Cipher, _, _, _ = _android_crypto()
    key = _get_key(True)
    payload = json.dumps({"provider": provider, "model": model, "apiKey": api_key}, separators=(",", ":")).encode("utf-8")
    cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key)
    encrypted = cipher.doFinal(payload)
    envelope = json.dumps({
        "version": 1,
        "iv": base64.b64encode(bytes(cipher.getIV())).decode("ascii"),
        "ciphertext": base64.b64encode(bytes(encrypted)).decode("ascii"),
    }, separators=(",", ":")).encode("utf-8")
    path = _credential_path(data_dir)
    fd, temp_name = tempfile.mkstemp(prefix=".credentials-", suffix=".part", dir=str(path.parent))
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as output:
            output.write(envelope)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_name, path)
        os.chmod(path, 0o600)
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
    return {"ok": True, "provider": provider, "model": model, "stored": True}


def load_credentials(data_dir: str) -> dict[str, str] | None:
    path = _credential_path(data_dir)
    if not path.is_file() or path.is_symlink():
        return None
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
        if envelope.get("version") != 1:
            raise ValueError("version")
        iv = base64.b64decode(envelope["iv"], validate=True)
        ciphertext = base64.b64decode(envelope["ciphertext"], validate=True)
        _, _, Cipher, GCMParameterSpec, _, _ = _android_crypto()
        key = _get_key(False)
        if key is None:
            raise ValueError("keystore key missing")
        cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        value = json.loads(bytes(cipher.doFinal(ciphertext)).decode("utf-8"))
        if not all(isinstance(value.get(k), str) for k in ("provider", "model", "apiKey")):
            raise ValueError("fields")
        return value
    except Exception as exc:
        raise HarnessSecretError("تعذر فتح بيانات اعتماد Harness المحفوظة") from exc


def delete_credentials(data_dir: str) -> None:
    path = _credential_path(data_dir)
    try:
        path.unlink()
    except FileNotFoundError:
        pass
