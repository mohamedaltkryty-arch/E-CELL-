from pathlib import Path
import os

APP_NAME = "SPIDER E-CELL"
VERSION = "1.2.1"
HOST = "127.0.0.1"
PORT = 8765
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("SPIDER_DATA_DIR", str(BASE_DIR / "data"))).expanduser()
DB_PATH = DATA_DIR / "spider_ecell.sqlite3"
MAX_BODY_BYTES = 12 * 1024 * 1024
MAX_CELLS = 512
MAX_TEXT_CHARS = 12000
