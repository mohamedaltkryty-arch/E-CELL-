"""Pinned on-demand installer for the DeepSeek Harness Android ARM64 rootfs.

Downloads the runtime manifest and rootfs from the upstream v0.3.7 stable
release, verifies both byte lengths and SHA-256 digests, and extracts only safe
regular files, directories, symlinks, and hardlinks into an app-private staging
folder. No archive path is executed and no archive entry can escape the rootfs.
"""
from __future__ import annotations

import gzip
import hashlib
import os
import shutil
import stat
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath
from typing import Callable, Any

MANIFEST_URL = "https://github.com/dphmoblie/deepseek-harness-android/releases/download/v0.3.7/runtime-manifest.json"
MANIFEST_SHA256 = "be350fc22da35116a6bdc474e6e728b01b9d92f76969b5f66d1e35a6b4dcf6aa"
MANIFEST_BYTES = 1057
MAX_MANIFEST_BYTES = 16 * 1024
MAX_COMPRESSED_BYTES = 1024 * 1024 * 1024
MAX_EXTRACTED_BYTES = 3 * 1024 * 1024 * 1024
MAX_ARCHIVE_ENTRIES = 200_000
MAX_PATH_CHARS = 4096
BUFFER_SIZE = 1024 * 1024
ALLOWED_DOWNLOAD_HOSTS = {
    "github.com",
    "release-assets.githubusercontent.com",
    "objects.githubusercontent.com",
    "github-releases.githubusercontent.com",
}


class HarnessInstallError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class _PinnedRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        if parsed.scheme != "https" or parsed.hostname not in ALLOWED_DOWNLOAD_HOSTS:
            raise HarnessInstallError("DOWNLOAD_REDIRECT_REJECTED", "تم رفض تحويل رابط تنزيل بيئة Harness")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(BUFFER_SIZE), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_https_release_url(raw: Any, expected_name: str) -> str:
    if not isinstance(raw, str) or len(raw) > 2048:
        raise HarnessInstallError("MANIFEST_INVALID", "رابط ملف بيئة Harness غير صالح")
    parsed = urllib.parse.urlsplit(raw)
    if (
        parsed.scheme != "https"
        or parsed.hostname != "github.com"
        or parsed.username is not None
        or parsed.password is not None
        or parsed.fragment
        or not parsed.path.endswith("/" + expected_name)
    ):
        raise HarnessInstallError("DOWNLOAD_URL_REJECTED", "رابط تنزيل بيئة Harness غير موثوق")
    return raw


def _parse_runtime_manifest(raw: bytes) -> dict[str, Any]:
    import json

    if len(raw) != MANIFEST_BYTES or hashlib.sha256(raw).hexdigest() != MANIFEST_SHA256:
        raise HarnessInstallError("MANIFEST_DIGEST_MISMATCH", "فشل التحقق من بصمة بيان بيئة Harness")
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise HarnessInstallError("MANIFEST_INVALID", "بيان بيئة Harness غير صالح") from exc
    if not isinstance(manifest, dict) or manifest.get("schemaVersion") != 1:
        raise HarnessInstallError("MANIFEST_SCHEMA_UNSUPPORTED", "إصدار بيان بيئة Harness غير مدعوم")
    if manifest.get("architecture") != "arm64-v8a":
        raise HarnessInstallError("ARCHITECTURE_UNSUPPORTED", "بيئة Harness متاحة لمعمارية ARM64 فقط")
    if not isinstance(manifest.get("runtimeId"), str) or not isinstance(manifest.get("version"), str):
        raise HarnessInstallError("MANIFEST_INVALID", "هوية إصدار بيئة Harness غير صالحة")
    rootfs = manifest.get("rootfs")
    if not isinstance(rootfs, dict):
        raise HarnessInstallError("MANIFEST_INVALID", "بيان Harness لا يحتوي ملف Ubuntu")
    url = _require_https_release_url(rootfs.get("url"), "rootfs.bundle")
    digest = rootfs.get("sha256")
    compressed = rootfs.get("compressedBytes")
    extracted = rootfs.get("extractedBytes")
    compression = rootfs.get("compression", "gzip")
    if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise HarnessInstallError("MANIFEST_INVALID", "بصمة أرشيف Ubuntu غير صالحة")
    if isinstance(compressed, bool) or not isinstance(compressed, int) or not 1 <= compressed <= MAX_COMPRESSED_BYTES:
        raise HarnessInstallError("MANIFEST_INVALID", "حجم أرشيف Ubuntu غير صالح")
    if isinstance(extracted, bool) or not isinstance(extracted, int) or not 1 <= extracted <= MAX_EXTRACTED_BYTES:
        raise HarnessInstallError("MANIFEST_INVALID", "حجم Ubuntu بعد فك الضغط غير صالح")
    if compression != "gzip":
        raise HarnessInstallError("ARCHIVE_COMPRESSION_UNSUPPORTED", "صيغة ضغط بيئة Ubuntu غير مدعومة")
    entrypoints = manifest.get("entrypoints")
    if not isinstance(entrypoints, dict):
        raise HarnessInstallError("MANIFEST_INVALID", "مداخل تشغيل Harness غير موجودة")
    harness_argv = entrypoints.get("harness")
    if (
        not isinstance(harness_argv, list)
        or len(harness_argv) != 6
        or harness_argv[:5] != ["/usr/local/bin/dsh", "web", "--host", "127.0.0.1", "--port"]
        or not isinstance(harness_argv[5], str)
        or not harness_argv[5].isdigit()
        or not 1024 <= int(harness_argv[5]) <= 65535
    ):
        raise HarnessInstallError("MANIFEST_INVALID", "مدخل تشغيل Harness في البيان غير صالح")
    return {
        "runtimeId": manifest["runtimeId"],
        "version": manifest["version"],
        "architecture": manifest["architecture"],
        "rootfsUrl": url,
        "rootfsSha256": digest,
        "compressedBytes": compressed,
        "extractedBytes": extracted,
        "compression": compression,
        "harnessArgv": list(harness_argv),
        "dshVersion": manifest.get("dshVersion"),
    }


def _safe_archive_name(name: str) -> tuple[str, ...]:
    if (
        not isinstance(name, str)
        or not name
        or len(name) > MAX_PATH_CHARS
        or name.startswith("/")
        or name.startswith("\\")
        or "\\" in name
        or "\x00" in name
        or "\n" in name
        or "\r" in name
    ):
        raise HarnessInstallError("ARCHIVE_PATH_INVALID", "يحتوي أرشيف Ubuntu على مسار غير آمن")
    normalized = name.removesuffix("/")
    if normalized in ("", ".", "./"):
        return ()
    parts = tuple(normalized.split("/"))
    if any(part in ("", ".", "..") or len(part) > 255 for part in parts):
        raise HarnessInstallError("ARCHIVE_PATH_INVALID", "يحتوي أرشيف Ubuntu على مسار متجاوز")
    return parts


def _ensure_directory(path: Path, root: Path) -> None:
    if path == root:
        return
    try:
        relative = path.relative_to(root)
    except ValueError as exc:
        raise HarnessInstallError("ARCHIVE_PATH_INVALID", "مسار فك الضغط خرج من مجلد Ubuntu") from exc
    cursor = root
    for part in relative.parts:
        cursor = cursor / part
        try:
            metadata = cursor.lstat()
        except FileNotFoundError:
            try:
                cursor.mkdir(mode=0o700)
            except FileExistsError:
                metadata = cursor.lstat()
            else:
                continue
        if not stat.S_ISDIR(metadata.st_mode):
            raise HarnessInstallError("ARCHIVE_PATH_CONFLICT", "تعارض مسارات داخل أرشيف Ubuntu")


def _resolve_link_target(root: Path, link_path: Path, raw_target: str, *, hardlink: bool) -> Path:
    if (
        not isinstance(raw_target, str)
        or not raw_target
        or len(raw_target) > MAX_PATH_CHARS
        or raw_target.startswith("\\")
        or "\\" in raw_target
        or "\x00" in raw_target
        or "\n" in raw_target
        or "\r" in raw_target
    ):
        raise HarnessInstallError("ARCHIVE_LINK_INVALID", "يحتوي أرشيف Ubuntu على رابط غير صالح")
    candidate = root.joinpath(*raw_target.lstrip("/").split("/")) if (hardlink or raw_target.startswith("/")) else link_path.parent.joinpath(*raw_target.split("/"))
    normalized = Path(os.path.normpath(str(candidate)))
    if normalized == root or not normalized.is_relative_to(root):
        raise HarnessInstallError("ARCHIVE_LINK_INVALID", "رابط في أرشيف Ubuntu يتجاوز المجلد المسموح")
    return normalized


def _copy_link_fallback(destination: Path, target: Path, root: Path) -> None:
    try:
        resolved = target.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise HarnessInstallError("ARCHIVE_LINK_INVALID", "تعذر حل رابط داخل أرشيف Ubuntu") from exc
    if not resolved.is_relative_to(root):
        raise HarnessInstallError("ARCHIVE_LINK_INVALID", "رابط Ubuntu يشير إلى خارج بيئته")
    if resolved.is_file():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(resolved, destination, follow_symlinks=False)
        os.chmod(destination, (stat.S_IMODE(resolved.stat().st_mode) | 0o600) & 0o777)
        return
    if not resolved.is_dir():
        raise HarnessInstallError("ARCHIVE_LINK_INVALID", "هدف رابط Ubuntu ليس ملفاً أو مجلداً")
    # Ubuntu's top-level /bin, /lib and /sbin links are structural. A shallow
    # directory copy that drops nested symlinks produces a deceptively
    # successful but unusable rootfs. Fail closed on ROMs that forbid them.
    raise HarnessInstallError(
        "ROOTFS_SYMLINK_UNAVAILABLE",
        "يتطلب تشغيل Ubuntu إنشاء الروابط الرمزية للمجلدات؛ لم يكتمل تثبيت البيئة على هذا الجهاز",
    )


def extract_rootfs(archive_path: Path, destination: Path, expected_bytes: int,
                   progress: Callable[[int, int], None] | None = None,
                   cancelled: Callable[[], bool] | None = None) -> int:
    """Safely extract a gzip TAR bundle without tarfile.extract/extractall."""
    if destination.exists() or destination.is_symlink():
        raise HarnessInstallError("STAGING_NOT_EMPTY", "مجلد تثبيت Ubuntu ليس فارغاً")
    destination.mkdir(parents=True, mode=0o700)
    root = destination.resolve()
    seen: set[Path] = set()
    symlinks: list[tuple[Path, Path]] = []
    hardlinks: list[tuple[Path, Path]] = []
    directory_modes: list[tuple[Path, int]] = []
    executable_files: list[Path] = []
    extracted_bytes = 0
    entry_count = 0
    check_cancel = cancelled or (lambda: False)
    report = progress or (lambda _done, _total: None)
    try:
        with tarfile.open(archive_path, mode="r|gz") as tar:
            for entry in tar:
                if check_cancel():
                    raise HarnessInstallError("INSTALL_CANCELLED", "تم إلغاء تثبيت بيئة Harness")
                entry_count += 1
                if entry_count > MAX_ARCHIVE_ENTRIES:
                    raise HarnessInstallError("ARCHIVE_ENTRY_LIMIT", "عدد ملفات بيئة Ubuntu أكبر من الحد")
                parts = _safe_archive_name(entry.name)
                if not parts:
                    if not entry.isdir():
                        raise HarnessInstallError("ARCHIVE_ENTRY_TYPE_REJECTED", "نوع مدخل جذر Ubuntu غير صالح")
                    continue
                path = root.joinpath(*parts)
                if not path.is_relative_to(root) or path == root:
                    raise HarnessInstallError("ARCHIVE_PATH_INVALID", "مسار Ubuntu غير آمن")
                if path in seen:
                    raise HarnessInstallError("ARCHIVE_DUPLICATE_ENTRY", "يحتوي أرشيف Ubuntu على مسارات مكررة")
                seen.add(path)

                if entry.isdir():
                    _ensure_directory(path, root)
                    directory_modes.append((path, (entry.mode & 0o777) | 0o700))
                    continue
                if entry.issym():
                    target = _resolve_link_target(root, path, entry.linkname, hardlink=False)
                    _ensure_directory(path.parent, root)
                    symlinks.append((path, target))
                    continue
                if entry.islnk():
                    target = _resolve_link_target(root, path, entry.linkname, hardlink=True)
                    _ensure_directory(path.parent, root)
                    hardlinks.append((path, target))
                    continue
                if not entry.isreg() or entry.size < 0:
                    raise HarnessInstallError("ARCHIVE_ENTRY_TYPE_REJECTED", "يحتوي أرشيف Ubuntu على ملف خاص مرفوض")
                if entry.size > expected_bytes - extracted_bytes:
                    raise HarnessInstallError("ARCHIVE_EXPANSION_LIMIT", "حجم Ubuntu بعد فك الضغط تجاوز البيان")
                _ensure_directory(path.parent, root)
                if path.exists() or path.is_symlink():
                    raise HarnessInstallError("ARCHIVE_DUPLICATE_ENTRY", "مسار ملف Ubuntu موجود مسبقاً")
                source = tar.extractfile(entry)
                if source is None:
                    raise HarnessInstallError("ARCHIVE_TRUNCATED", "بيانات ملف Ubuntu غير مكتملة")
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
                written = 0
                try:
                    with os.fdopen(fd, "wb") as output:
                        while written < entry.size:
                            if check_cancel():
                                raise HarnessInstallError("INSTALL_CANCELLED", "تم إلغاء تثبيت بيئة Harness")
                            block = source.read(min(BUFFER_SIZE, entry.size - written))
                            if not block:
                                raise HarnessInstallError("ARCHIVE_TRUNCATED", "بيانات ملف Ubuntu غير مكتملة")
                            output.write(block)
                            written += len(block)
                        output.flush()
                        os.fsync(output.fileno())
                finally:
                    source.close()
                extracted_bytes += written
                mode = (entry.mode & 0o777) | 0o600
                os.chmod(path, mode)
                if entry.mode & 0o111:
                    executable_files.append(path)
                report(extracted_bytes, expected_bytes)

        if extracted_bytes != expected_bytes:
            raise HarnessInstallError("ARCHIVE_SIZE_MISMATCH", "حجم ملفات Ubuntu بعد فك الضغط لا يطابق البيان")

        for path, target in hardlinks:
            if check_cancel():
                raise HarnessInstallError("INSTALL_CANCELLED", "تم إلغاء تثبيت بيئة Harness")
            try:
                metadata = target.lstat()
            except OSError as exc:
                raise HarnessInstallError("ARCHIVE_LINK_INVALID", "هدف رابط Ubuntu غير موجود") from exc
            if not stat.S_ISREG(metadata.st_mode) or path.exists() or path.is_symlink():
                raise HarnessInstallError("ARCHIVE_LINK_INVALID", "هدف رابط Ubuntu غير صالح")
            try:
                os.link(target, path, follow_symlinks=False)
            except OSError:
                shutil.copyfile(target, path, follow_symlinks=False)
                os.chmod(path, (stat.S_IMODE(metadata.st_mode) | 0o600) & 0o777)

        for path, target in symlinks:
            if check_cancel():
                raise HarnessInstallError("INSTALL_CANCELLED", "تم إلغاء تثبيت بيئة Harness")
            if path.exists() or path.is_symlink():
                raise HarnessInstallError("ARCHIVE_DUPLICATE_ENTRY", "وجهة رابط Ubuntu موجودة مسبقاً")
            try:
                relative_target = os.path.relpath(target, path.parent)
                os.symlink(relative_target, path)
            except OSError as exc:
                if exc.errno not in (1, 13, 18, 95):
                    raise
                _copy_link_fallback(path, target, root)

        for path, mode in reversed(directory_modes):
            os.chmod(path, mode)

        # Android 15+ may require this xattr before executing ELF files from app data.
        failures = 0
        for path in executable_files:
            try:
                os.setxattr(path, "security.android.exec", b"1", follow_symlinks=False)
                failures = 0
            except (AttributeError, OSError):
                failures += 1
                if failures >= 8:
                    break
        report(expected_bytes, expected_bytes)
        return extracted_bytes
    except Exception:
        try:
            shutil.rmtree(destination)
        except OSError:
            pass
        raise


class HarnessRootfsInstaller:
    def __init__(self, harness_dir: str, status_callback: Callable[[dict[str, Any]], None] | None = None,
                 opener: urllib.request.OpenerDirector | None = None):
        self.root = Path(harness_dir).resolve()
        self.download_dir = self.root / "downloads"
        self.status_callback = status_callback or (lambda _status: None)
        self.opener = opener or urllib.request.build_opener(_PinnedRedirectHandler())
        self.cancel_event = threading.Event()
        self._lock = threading.RLock()
        self.state: dict[str, Any] = {"state": "idle", "progress": 0.0, "bytesDownloaded": 0,
                                     "bytesExtracted": 0, "message": ""}

    def cancel(self) -> None:
        self.cancel_event.set()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return dict(self.state)

    def install(self) -> dict[str, Any]:
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.download_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.cancel_event.clear()
        try:
            self._set_state(state="downloading_manifest", progress=0.0, message="تنزيل بيان بيئة Harness")
            manifest_path = self.download_dir / "runtime-manifest.json"
            self._download_verified(MANIFEST_URL, manifest_path, MANIFEST_BYTES, MANIFEST_SHA256, manifest=True)
            runtime = _parse_runtime_manifest(manifest_path.read_bytes())
            free = shutil.disk_usage(self.root).free
            required = runtime["compressedBytes"] + runtime["extractedBytes"] + 256 * 1024 * 1024
            if free < required:
                raise HarnessInstallError("INSUFFICIENT_STORAGE", "المساحة الحرة لا تكفي لتنزيل واستخراج Ubuntu")
            archive = self.download_dir / "rootfs.bundle"
            self._set_state(state="downloading_rootfs", progress=0.0, message="تنزيل بيئة Ubuntu وNode وHarness")
            self._download_verified(runtime["rootfsUrl"], archive, runtime["compressedBytes"], runtime["rootfsSha256"])
            if self.cancel_event.is_set():
                raise HarnessInstallError("INSTALL_CANCELLED", "تم إلغاء تثبيت بيئة Harness")
            staging = self.root / "rootfs.staging"
            if staging.exists() or staging.is_symlink():
                shutil.rmtree(staging, ignore_errors=True)
            self._set_state(state="extracting_rootfs", progress=0.0, message="استخراج بيئة Ubuntu بأمان")
            extracted = extract_rootfs(
                archive, staging, runtime["extractedBytes"],
                progress=lambda done, total: self._set_state(
                    state="extracting_rootfs", progress=(done / max(total, 1)), bytesExtracted=done),
                cancelled=self.cancel_event.is_set,
            )
            dsh = staging / "usr" / "local" / "bin" / "dsh"
            if not dsh.is_file() or dsh.is_symlink():
                shutil.rmtree(staging, ignore_errors=True)
                raise HarnessInstallError("HARNESS_ENTRYPOINT_MISSING", "ملف تشغيل dsh غير موجود داخل Ubuntu")
            target = self.root / "rootfs"
            backup = self.root / "rootfs.previous"
            if backup.exists() or backup.is_symlink():
                shutil.rmtree(backup, ignore_errors=True)
            if target.exists():
                os.replace(target, backup)
            try:
                os.replace(staging, target)
            except Exception:
                if backup.exists() and not target.exists():
                    os.replace(backup, target)
                raise
            if backup.exists():
                shutil.rmtree(backup, ignore_errors=True)
            try:
                archive.unlink()
                manifest_path.unlink()
            except OSError:
                pass
            result = {"ok": True, "runtimeId": runtime["runtimeId"], "version": runtime["version"],
                      "dshVersion": runtime.get("dshVersion"), "extractedBytes": extracted,
                      "harnessProfile": "web-bundle-present; SDK profile must pass preflight"}
            self._set_state(state="installed", progress=1.0, message="اكتمل تثبيت بيئة Harness", **result)
            return result
        except HarnessInstallError as exc:
            self._set_state(state="failed", message=exc.message, errorCode=exc.code)
            raise
        except (OSError, tarfile.TarError, urllib.error.URLError) as exc:
            self._set_state(state="failed", message="تعذر تثبيت بيئة Harness", errorCode="INSTALL_IO_FAILED")
            raise HarnessInstallError("INSTALL_IO_FAILED", "تعذر تنزيل أو استخراج بيئة Harness") from exc

    def _download_verified(self, url: str, destination: Path, expected_bytes: int,
                           expected_sha256: str, manifest: bool = False) -> None:
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname not in ALLOWED_DOWNLOAD_HOSTS:
            raise HarnessInstallError("DOWNLOAD_URL_REJECTED", "رابط تنزيل بيئة Harness غير مسموح")
        if (not destination.is_symlink() and destination.is_file()
                and destination.stat().st_size == expected_bytes
                and _sha256_file(destination) == expected_sha256):
            return
        if destination.exists() or destination.is_symlink():
            destination.unlink()
        partial = destination.with_suffix(destination.suffix + ".part")
        if partial.exists():
            partial.unlink()
        request = urllib.request.Request(url, headers={"User-Agent": "SPIDER-E-CELL-Harness-Installer/1"})
        digest = hashlib.sha256()
        count = 0
        try:
            with self.opener.open(request, timeout=60) as response, partial.open("xb") as output:
                content_length = response.headers.get("Content-Length")
                if content_length and content_length.isdigit() and int(content_length) != expected_bytes:
                    raise HarnessInstallError("DOWNLOAD_SIZE_MISMATCH", "حجم ملف تنزيل Harness لا يطابق البيان")
                while True:
                    if self.cancel_event.is_set():
                        raise HarnessInstallError("INSTALL_CANCELLED", "تم إلغاء تثبيت بيئة Harness")
                    block = response.read(BUFFER_SIZE)
                    if not block:
                        break
                    count += len(block)
                    if count > expected_bytes:
                        raise HarnessInstallError("DOWNLOAD_SIZE_MISMATCH", "ملف تنزيل Harness تجاوز الحجم المحدد")
                    output.write(block)
                    digest.update(block)
                    if not manifest:
                        self._set_state(state="downloading_rootfs", bytesDownloaded=count,
                                        progress=count / max(expected_bytes, 1))
                output.flush()
                os.fsync(output.fileno())
            if count != expected_bytes or digest.hexdigest() != expected_sha256:
                raise HarnessInstallError("DOWNLOAD_DIGEST_MISMATCH", "فشل التحقق من ملف تنزيل Harness")
            os.replace(partial, destination)
        except Exception:
            try:
                partial.unlink()
            except OSError:
                pass
            raise

    def _set_state(self, **values: Any) -> None:
        with self._lock:
            self.state.update(values)
            self.state["updatedAt"] = time.time()
            snapshot = dict(self.state)
        self.status_callback(snapshot)
