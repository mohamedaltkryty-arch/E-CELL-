import json
import mimetypes
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from pathlib import Path
from .config import HOST, PORT, MAX_BODY_BYTES, VERSION
from . import database as store
from .brain import brain
from . import learning
from . import adaptive
from . import skill_runtime

STATIC = Path(__file__).resolve().parent / "static"
MIME = {".webmanifest": "application/manifest+json", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml"}

class SpiderHandler(BaseHTTPRequestHandler):
    server_version = "SpiderLocal/1.0"
    sys_version = ""

    def log_message(self, fmt, *args):
        # No user prompts or message contents are written to console logs.
        print("[SPIDER] " + (fmt % args))

    def _json(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), usb=(), bluetooth=()")
        self.send_header("Content-Security-Policy", "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(raw)

    def _body(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > MAX_BODY_BYTES:
            raise ValueError("حجم الطلب أكبر من الحد المسموح")
        raw = self.rfile.read(length)
        try:
            value = json.loads(raw.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("صيغة JSON غير صالحة")
        if not isinstance(value, dict):
            raise ValueError("جسم الطلب يجب أن يكون كائن JSON")
        return value

    def _local_guard(self):
        host = self.headers.get("Host", "").split(":", 1)[0].strip("[]").lower()
        if host not in ("127.0.0.1", "localhost", "::1"):
            self._json(403, {"error": "يُسمح بالوصول المحلي فقط"})
            return False
        origin = self.headers.get("Origin")
        if origin:
            from urllib.parse import urlsplit
            parsed = urlsplit(origin)
            if parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
                self._json(403, {"error": "مصدر الطلب غير مسموح"})
                return False
        return True

    def do_GET(self):
        if not self._local_guard():
            return
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self._static("index.html")
        if path in ("/manifest.webmanifest", "/sw.js", "/spider-icon.svg", "/extension-worker.js"):
            return self._static(path.lstrip("/"))
        if path == "/api/health":
            return self._json(200, {"app": "SPIDER E-CELL", "version": VERSION,
                                    "mode": "local-core-with-internet-learning", "network": "backend-outbound-only",
                                    "stats": store.stats(), "learning": learning.status(),
                                    "adaptive": adaptive.status()})
        if path == "/api/harness/status":
            from .harness_runtime import get_runtime
            return self._json(200, get_runtime().status())
        if path == "/api/harness/events":
            from urllib.parse import parse_qs
            from .harness_runtime import get_runtime
            query = parse_qs(urlparse(self.path).query)
            after = query.get("after", ["0"])[0]
            session_id = query.get("session", [None])[0]
            try:
                sequence = max(0, int(after))
            except (TypeError, ValueError):
                sequence = 0
            return self._json(200, get_runtime().events_since(sequence, session_id))
        if path == "/api/harness/approvals":
            from .harness_runtime import get_runtime
            return self._json(200, {"approvals": get_runtime().pending_approvals()})
        if path == "/api/learning/status":
            return self._json(200, learning.status())
        if path == "/api/brain/adaptive":
            return self._json(200, adaptive.status())
        if path == "/api/learning/search":
            from urllib.parse import parse_qs
            query = parse_qs(urlparse(self.path).query).get("q", [""])[0]
            return self._json(200, {"query": query, "results": learning.search_sources(query)})
        if path == "/api/skills":
            return self._json(200, {"skills": learning.list_skills()})
        if path == "/api/state":
            return self._json(200, {"state": store.get_state(), "cells": store.list_cells(),
                                    "stats": store.stats(), "tasks": store.list_tasks(15)})
        if path == "/api/cells":
            return self._json(200, {"cells": store.list_cells()})
        if path == "/api/tasks":
            return self._json(200, {"tasks": store.list_tasks(100)})
        return self._json(404, {"error": "المسار غير موجود"})

    def do_POST(self):
        if not self._local_guard():
            return
        path = urlparse(self.path).path
        try:
            data = self._body()
            if path == "/api/harness/credentials":
                from .harness_runtime import get_runtime
                provider = data.get("provider", "deepseek")
                model = data.get("model", "deepseek-chat")
                api_key = data.get("api_key", "")
                if not all(isinstance(value, str) for value in (provider, model, api_key)):
                    raise ValueError("بيانات مزود النموذج غير صالحة")
                return self._json(200, get_runtime().save_credentials(provider, model, api_key))
            if path == "/api/harness/credentials/delete":
                from .harness_runtime import get_runtime
                return self._json(200, get_runtime().clear_credentials())
            if path == "/api/harness/install":
                from .harness_runtime import get_runtime
                return self._json(202, get_runtime().start_install())
            if path == "/api/harness/install/cancel":
                from .harness_runtime import get_runtime
                return self._json(200, get_runtime().cancel_install())
            if path == "/api/harness/initialize":
                from .harness_runtime import get_runtime
                provider = data.get("provider")
                model = data.get("model")
                effort = data.get("reasoning_effort")
                max_tokens = data.get("max_tokens")
                if provider is None and model is None:
                    return self._json(200, get_runtime().initialize_saved())
                if not isinstance(provider, str) or not isinstance(model, str):
                    raise ValueError("مزود النموذج أو اسمه غير صالح")
                if effort is not None and not isinstance(effort, str):
                    raise ValueError("مستوى الاستدلال غير صالح")
                if max_tokens is not None and (isinstance(max_tokens, bool) or not isinstance(max_tokens, int)):
                    raise ValueError("حد الرموز غير صالح")
                return self._json(200, get_runtime().initialize(provider, model, effort, max_tokens))
            if path == "/api/harness/prompt":
                from .harness_runtime import get_runtime
                session_id = data.get("session_id")
                prompt = data.get("prompt", "")
                if session_id is not None and not isinstance(session_id, str):
                    raise ValueError("معرّف الجلسة غير صالح")
                if not isinstance(prompt, str):
                    raise ValueError("نص الرسالة غير صالح")
                return self._json(202, get_runtime().prompt(session_id, prompt))
            if path == "/api/harness/wait":
                from .harness_runtime import get_runtime
                session_id = data.get("session_id")
                timeout_seconds = data.get("timeout_seconds", 15)
                if session_id is not None and not isinstance(session_id, str):
                    raise ValueError("معرّف الجلسة غير صالح")
                if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float)) or not 1 <= timeout_seconds <= 120:
                    raise ValueError("مهلة انتظار Harness غير صالحة")
                return self._json(200, get_runtime().wait(session_id, float(timeout_seconds)))
            if path == "/api/harness/approval":
                from .harness_runtime import get_runtime
                approval_id = data.get("approval_id")
                outcome = data.get("outcome")
                if not isinstance(approval_id, str) or not isinstance(outcome, str):
                    raise ValueError("بيانات الموافقة غير صالحة")
                return self._json(200, get_runtime().answer_approval(approval_id, outcome))
            if path == "/api/harness/resume":
                from .harness_runtime import get_runtime
                raw_session_id = data.get("session_id")
                if raw_session_id is not None and not isinstance(raw_session_id, str):
                    raise ValueError("معرّف الجلسة غير صالح")
                session_id = raw_session_id.strip() if isinstance(raw_session_id, str) else None
                return self._json(200, get_runtime().resume(session_id))
            if path == "/api/harness/shutdown":
                from .harness_runtime import get_runtime
                get_runtime().close()
                return self._json(200, {"ok": True})
            if path == "/api/state":
                state = data.get("state")
                if not isinstance(state, dict):
                    raise ValueError("حالة التطبيق غير صالحة")
                store.save_state(state)
                return self._json(200, {"ok": True})
            if path == "/api/brain/chat":
                result = brain.respond(data)
                return self._json(200, result)
            if path == "/api/brain/feedback":
                result = adaptive.add_example(str(data.get("prompt", "")),
                                              str(data.get("correction", "")),
                                              str(data.get("intent", "chat")))
                # The corrected answer becomes searchable local knowledge too.
                from .learning import _index_full_text
                _index_full_text([{"source": f"user-correction:{result['id']}",
                                   "content": f"سؤال مشابه: {data.get('prompt','')}\nالتصحيح المعتمد: {data.get('correction','')}"}])
                return self._json(201, result)
            if path == "/api/brain/index":
                docs = data.get("documents", [])
                return self._json(200, brain.index_local_data(docs))
            if path == "/api/skills/create":
                result = skill_runtime.create_skill(
                    str(data.get("name", "")), str(data.get("description", "")),
                    data.get("steps", []), data.get("inputs", {}), data.get("output"))
                return self._json(201, result)
            if path == "/api/skills/run":
                result = skill_runtime.execute_skill(str(data.get("id", "")), data.get("inputs", {}))
                store.event("skill.run", str(data.get("id", "")))
                return self._json(200, result)
            if path == "/api/learning/search":
                query = str(data.get("query", "")).strip()
                results = learning.search_web(query, limit=8)
                return self._json(200, {"query": query, "results": results, "status": learning.status()})
            if path == "/api/learning/sync":
                result = learning.startup_sync(force=True)
                return self._json(200, {"result": result, "status": learning.status()})
            if path == "/api/learning/page":
                url = str(data.get("url", "")).strip()
                title = str(data.get("title", "")).strip() or None
                return self._json(200, learning.learn_url(url, title))
            if path == "/api/github/import":
                url = str(data.get("url", "")).strip()
                return self._json(200, learning.import_github(url))
            if path == "/api/learning/file":
                name = str(data.get("name", "uploaded.txt"))
                if data.get("archive_b64"):
                    result = learning.learn_uploaded_archive(name, str(data.get("archive_b64")))
                else:
                    result = learning.learn_uploaded_file(name, str(data.get("content", "")))
                return self._json(201, result)
            if path == "/api/cells":
                result = store.create_cell(str(data.get("code", "")), str(data.get("name", "")),
                                           str(data.get("description", "")), str(data.get("role", "custom")))
                return self._json(201, {"cell": result})
            if path.startswith("/api/cells/") and path.endswith("/status"):
                cell_id = path.split("/")[3]
                result = store.set_cell_status(cell_id, str(data.get("status", "paused")))
                return self._json(200, {"cell": result})
            return self._json(404, {"error": "المسار غير موجود"})
        except ValueError as exc:
            return self._json(400, {"error": str(exc)[:300]})
        except sqlite3.IntegrityError:
            return self._json(409, {"error": "رمز الخلية مستخدم بالفعل"})
        except RuntimeError as exc:
            # Harness errors expose only controlled messages/codes; raw process
            # diagnostics and credential-bearing environment data never reach HTTP.
            from .harness_runtime import HarnessRuntimeError
            if isinstance(exc, HarnessRuntimeError):
                status = 503 if exc.code in ("HARNESS_RUNTIME_MISSING", "HARNESS_NOT_RUNNING", "HARNESS_NOT_INITIALIZED", "HARNESS_CREDENTIALS_MISSING") else 502
                return self._json(status, {"error": exc.message, "code": exc.code})
            return self._json(502, {"error": str(exc)[:400]})
        except Exception:
            return self._json(500, {"error": "حدث خطأ داخلي في النواة المحلية"})

    def _static(self, name):
        target = (STATIC / name).resolve()
        if not target.is_relative_to(STATIC.resolve()) or not target.is_file():
            return self._json(404, {"error": "الملف غير موجود"})
        raw = target.read_bytes()
        mime = MIME.get(target.suffix.lower(), mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        if mime.startswith("text/") or mime in ("application/manifest+json",):
            mime += "" if "charset" in mime else "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-cache" if name in ("index.html", "sw.js") else "public, max-age=86400")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), usb=(), bluetooth=()")
        if name == "extension-worker.js":
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self' 'unsafe-eval'; connect-src 'none'; img-src 'none'; object-src 'none'; base-uri 'none'")
        else:
            self.send_header("Content-Security-Policy", "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        if name == "sw.js":
            self.send_header("Service-Worker-Allowed", "/")
        self.end_headers()
        self.wfile.write(raw)

class LocalServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

def run(host=HOST, port=PORT):
    store.init_db()
    # Rebuild the compact adaptive classifier from saved corrections automatically.
    if adaptive.count_examples():
        adaptive.train()
    learning.start_background_sync()
    server = LocalServer((host, port), SpiderHandler)
    print("=" * 54)
    print("SPIDER E-CELL v" + VERSION)
    print("النواة والذاكرة محليتان؛ البحث الخارجي يبدأ في الخلفية عند التشغيل")
    print(f"افتح: http://{host}:{port}")
    print("أوقف التشغيل عبر Ctrl+C")
    print("=" * 54)
    try:
        server.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print("\nإيقاف SPIDER E-CELL...")
    finally:
        server.server_close()
