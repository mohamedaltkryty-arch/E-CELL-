'use strict';
// Runs imported tools in a separate worker with no DOM, storage, or network APIs.
self.fetch = undefined;
self.XMLHttpRequest = undefined;
self.WebSocket = undefined;
self.EventSource = undefined;
self.importScripts = undefined;
self.indexedDB = undefined;
self.caches = undefined;
self.onmessage = event => {
  try {
    const code = String(event.data.code || '');
    const input = JSON.parse(JSON.stringify(event.data.input ?? {}));
    const fn = new Function('input', '"use strict";\n' + code);
    const value = fn(input);
    const encoded = JSON.stringify(value);
    if (typeof encoded !== 'string' || encoded.length > 262144) throw new Error('الناتج غير صالح أو يتجاوز 256 كيلوبايت');
    self.postMessage({ok: 1, out: JSON.parse(encoded)});
  } catch (error) {
    self.postMessage({ok: 0, err: String(error && error.message || error).slice(0, 500)});
  }
};
