"""Android/PRoot adapter for Harness' Landlock sandbox backend."""
from __future__ import annotations

SANDBOX_RUNNER_SCRIPT = r'''#!/bin/sh
# PRoot/Android compatibility layer for DeepSeek Harness' Landlock sandbox.
# It grants the guest root and required Android bind mounts, plus the APK-backed
# native library directory containing the PRoot loader. Unknown bwrap options
# fail closed rather than silently weakening the sandbox.
set -u

LAUNCHER="${DSH_MOBILE_LANDLOCK_RUN:-}"
if [ -z "$LAUNCHER" ]; then
    for candidate in /opt/dsh/node_modules/.pnpm/@deepseek-ai+node-addon-system-*/node_modules/@deepseek-ai/node-addon-system-*/bin/landlock-run; do
        if [ -x "$candidate" ]; then
            LAUNCHER="$candidate"
            break
        fi
    done
fi

GRANT_ARGS="--ro /"
NATIVE_LIB="${DSH_MOBILE_NATIVE_LIB:-/.dsh-native}"

fail() {
    echo "dsh-sandbox-runner: $1" >&2
    exit 125
}

valid_path() {
    case "$1" in /*) ;; *) return 1 ;; esac
    case "$1" in *" "*|*".."*) return 1 ;; esac
    return 0
}

add_ro() {
    valid_path "$1" || fail "unsupported read-only path"
    GRANT_ARGS="$GRANT_ARGS --ro $1"
}

add_rw() {
    valid_path "$1" || fail "unsupported read-write path"
    GRANT_ARGS="$GRANT_ARGS --rw $1"
}

while [ "$#" -gt 0 ]; do
    argument="$1"
    shift
    case "$argument" in
        --) break ;;
        --ro-bind)
            [ "$#" -ge 2 ] || fail "missing operands for --ro-bind"
            source_path="$1"; shift
            target_path="$1"; shift
            [ "$source_path" = "$target_path" ] || fail "renamed bind is unsupported"
            add_ro "$source_path"
            ;;
        --bind)
            [ "$#" -ge 2 ] || fail "missing operands for --bind"
            source_path="$1"; shift
            target_path="$1"; shift
            [ "$source_path" = "$target_path" ] || fail "renamed bind is unsupported"
            add_rw "$source_path"
            ;;
        --tmpfs)
            [ "$#" -ge 1 ] || fail "missing operand for --tmpfs"
            tmpfs_path="$1"; shift
            [ ! -e "$tmpfs_path" ] || add_rw "$tmpfs_path"
            ;;
        --dev|--proc)
            [ "$#" -ge 1 ] || fail "missing operand for $argument"
            shift
            ;;
        --unshare-pid|--die-with-parent)
            # The upstream Landlock backend provides neither PID nor mount namespaces.
            ;;
        *) fail "unsupported argument: $argument" ;;
    esac
done

[ "$#" -gt 0 ] || fail "missing command"
[ -n "$LAUNCHER" ] || fail "landlock launcher not found"
[ -x "$LAUNCHER" ] || fail "landlock launcher is not executable"
[ -e "$NATIVE_LIB" ] || fail "native library directory not found"
add_ro "$NATIVE_LIB"
for fixed_ro in /dev /proc; do
    [ ! -e "$fixed_ro" ] || add_ro "$fixed_ro"
done
for fixed_rw in /dev/null /dev/ptmx /dev/pts; do
    [ ! -e "$fixed_rw" ] || add_rw "$fixed_rw"
done

# The grant list contains only validated, space-free absolute paths.
set -f
# shellcheck disable=SC2086
exec "$LAUNCHER" $GRANT_ARGS -- "$@"
'''

def sandbox_provider_patch() -> list[dict[str, object]]:
    return [{
        "id": "sandbox",
        "config": {
            "runnerCommand": ["/bin/sh", "/root/.dsh-mobile/sandbox-runner.sh"],
            "runnerFailureSignatures": ["dsh-sandbox-runner: "],
        },
    }]
