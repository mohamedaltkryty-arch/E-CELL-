"""Safe declarative skill runtime. It never executes imported source code."""
from __future__ import annotations
import csv
import hashlib
import io
import json
import re
from collections import Counter
from . import database as store

RUNTIME_ID = "spider-dsl-v1"
MAX_STEPS = 30
MAX_INPUT_BYTES = 256_000

ALLOWED_OPS = {
    "value.identity", "value.stringify", "text.lower", "text.upper", "text.capitalize", "text.title", "text.reverse",
    "text.strip", "text.length", "text.split_whitespace", "text.word_count",
    "text.unique_words", "text.contains", "text.replace", "text.split", "text.join",
    "text.truncate", "text.regex_extract", "text.regex_replace", "text.summarize",
    "json.parse", "json.get", "json.stringify", "csv.summary", "list.unique",
    "list.count", "list.join", "list.sum", "list.sort", "list.min", "list.max",
    "math.eval", "hash.sha256"
}


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError("تعريف المهارة يجب أن يكون كائن JSON")
    name = str(manifest.get("name", "")).strip()
    if not name or len(name) > 120:
        raise ValueError("اسم المهارة مطلوب وبحد أقصى 120 حرفاً")
    steps = manifest.get("steps")
    if not isinstance(steps, list) or not 1 <= len(steps) <= MAX_STEPS:
        raise ValueError(f"يجب أن تحتوي المهارة على 1 إلى {MAX_STEPS} خطوة")
    ids = set()
    clean = []
    for i, raw in enumerate(steps):
        if not isinstance(raw, dict):
            raise ValueError(f"الخطوة {i+1} غير صالحة")
        step_id = str(raw.get("id", f"step{i+1}")).strip()
        op = str(raw.get("op", "")).strip()
        source = str(raw.get("from", "input" if i == 0 else clean[-1]["id"])).strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,32}", step_id) or step_id in ids:
            raise ValueError(f"معرّف الخطوة {i+1} غير صالح أو مكرر")
        if op not in ALLOWED_OPS:
            raise ValueError(f"العملية {op or '(فارغة)'} غير مسموحة في بيئة المهارات")
        if source != "input" and source not in ids and not source.startswith("input."):
            raise ValueError(f"مصدر الخطوة {i+1} غير معروف: {source}")
        params = raw.get("params", {})
        if not isinstance(params, dict) or len(json.dumps(params, ensure_ascii=False)) > 4000:
            raise ValueError(f"إعدادات الخطوة {i+1} غير صالحة")
        clean.append({"id": step_id, "op": op, "from": source, "params": params})
        ids.add(step_id)
    output = str(manifest.get("output", clean[-1]["id"]))
    if output not in ids:
        raise ValueError("حقل output يجب أن يشير إلى خطوة موجودة")
    return {"runtime": RUNTIME_ID, "name": name,
            "description": str(manifest.get("description", ""))[:600],
            "inputs": manifest.get("inputs", {}) if isinstance(manifest.get("inputs", {}), dict) else {},
            "steps": clean, "output": output}


def _safe_math(value):
    from .brain import safe_math
    return safe_math(str(value))


def _resolve(source, inputs, values):
    if source == "input":
        return inputs
    if source.startswith("input."):
        current = inputs
        for key in source[6:].split("."):
            if not isinstance(current, dict):
                return None
            current = current.get(key)
        return current
    return values.get(source)


def _safe_pattern(pattern):
    pattern = str(pattern)
    if len(pattern) > 100:
        raise ValueError("نمط regex طويل جداً")
    # Keep the DSL's regex subset intentionally small: no groups, alternations,
    # lookarounds, backreferences, or repeated quantifiers.
    if any(ch in pattern for ch in "()|\n\r") or re.search(r"\\[1-9]|\(\?", pattern):
        raise ValueError("نمط regex يحتوي بنية غير مسموحة")
    quantifiers = re.findall(r"(?<!\\)[*+?]|\{\d+(?:,\d*)?\}", pattern)
    if len(quantifiers) > 1:
        raise ValueError("يسمح بمحدد تكرار واحد فقط في نمط regex")
    return pattern


def _run_op(op, value, params):
    if op == "value.identity": return value
    if op == "value.stringify":
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        if value is None:
            return "None"
        if value is True:
            return "True"
        if value is False:
            return "False"
        return str(value)
    if op == "text.lower": return str(value if value is not None else "").lower()
    if op == "text.upper": return str(value if value is not None else "").upper()
    if op == "text.capitalize": return str(value if value is not None else "").capitalize()
    if op == "text.title": return str(value if value is not None else "").title()
    if op == "text.reverse": return str(value if value is not None else "")[::-1]
    if op == "text.strip": return str(value if value is not None else "").strip()
    if op == "text.length": return len(value) if isinstance(value, (str, list, dict)) else 0
    if op == "text.word_count": return len(re.findall(r"[\w\u0600-\u06FF]+", str(value or ""), re.UNICODE))
    if op == "text.unique_words":
        words = re.findall(r"[\w\u0600-\u06FF]+", str(value or "").lower(), re.UNICODE)
        return list(dict.fromkeys(words))
    if op == "text.contains": return str(params.get("needle", "")) in str(value or "")
    if op == "text.replace": return str(value or "").replace(str(params.get("old", "")), str(params.get("new", "")), int(params.get("count", -1)))
    if op == "text.split": return str(value or "").split(str(params.get("separator", " ")))
    if op == "text.split_whitespace": return str(value or "").split()
    if op == "text.join":
        if not isinstance(value, list): raise ValueError("text.join يحتاج قائمة")
        return str(params.get("separator", " ")).join(str(x) for x in value)
    if op == "text.truncate": return str(value or "")[:max(0, min(100000, int(params.get("max", 500))))]
    if op == "text.regex_extract":
        pattern = _safe_pattern(params.get("pattern", ""))
        matches = re.findall(pattern, str(value or "")[:4000])
        return matches[:100]
    if op == "text.regex_replace":
        pattern = _safe_pattern(params.get("pattern", ""))
        return re.sub(pattern, str(params.get("replacement", "")), str(value or "")[:4000], count=100)
    if op == "text.summarize":
        from .brain import summarize
        return summarize(str(value or ""), max_sentences=max(1, min(12, int(params.get("sentences", 4)))))
    if op == "json.parse": return json.loads(str(value or "{}"))
    if op == "json.get":
        current = value
        for key in str(params.get("path", "")).split("."):
            if not key: continue
            if isinstance(current, dict): current = current.get(key)
            elif isinstance(current, list) and key.isdigit() and int(key) < len(current): current = current[int(key)]
            else: return None
        return current
    if op == "json.stringify": return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if op == "csv.summary":
        text = str(value or "")
        rows = list(csv.reader(io.StringIO(text)))
        if not rows: return {"rows": 0, "columns": 0, "headers": []}
        return {"rows": max(0, len(rows)-1), "columns": len(rows[0]), "headers": rows[0][:100]}
    if op == "list.unique":
        if not isinstance(value, list): raise ValueError("list.unique يحتاج قائمة")
        out, seen = [], set()
        for item in value:
            marker = json.dumps(item, sort_keys=True, ensure_ascii=False, default=str)
            if marker not in seen:
                seen.add(marker)
                out.append(item)
        return out
    if op == "list.count": return len(value) if isinstance(value, (list, dict, str)) else 0
    if op == "list.sum":
        if not isinstance(value, list) or len(value) > 10000 or any(not isinstance(x, (int, float)) or isinstance(x, bool) for x in value):
            raise ValueError("list.sum يحتاج قائمة أرقام")
        result = sum(value)
        if abs(result) > 1e15: raise ValueError("نتيجة الجمع خارج النطاق")
        return result
    if op == "list.sort":
        if not isinstance(value, list) or len(value) > 10000 or any(not isinstance(x, (str, int, float)) for x in value):
            raise ValueError("list.sort يحتاج قائمة نصوص أو أرقام بسيطة")
        return sorted(value, reverse=bool(params.get("reverse", False)))
    if op == "list.min":
        if not isinstance(value, list) or not value: return None
        if any(type(x) not in (str, int, float) for x in value): raise ValueError("list.min يحتاج قيماً بسيطة")
        return min(value)
    if op == "list.max":
        if not isinstance(value, list) or not value: return None
        if any(type(x) not in (str, int, float) for x in value): raise ValueError("list.max يحتاج قيماً بسيطة")
        return max(value)
    if op == "list.join":
        if not isinstance(value, list): raise ValueError("list.join يحتاج قائمة")
        return str(params.get("separator", ", ")).join(str(x) for x in value)
    if op == "math.eval":
        result = _safe_math(value)
        if result is None: raise ValueError("تعذر تقييم العملية الحسابية بأمان")
        return result
    if op == "hash.sha256": return hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()
    raise ValueError("عملية غير مدعومة")


def execute_manifest(manifest, inputs):
    spec = validate_manifest(manifest)
    inputs = inputs if isinstance(inputs, dict) else {}
    encoded = json.dumps(inputs, ensure_ascii=False).encode("utf-8")
    if len(encoded) > MAX_INPUT_BYTES:
        raise ValueError("مدخلات المهارة تتجاوز 256KB")
    values = {}
    for step in spec["steps"]:
        source_value = _resolve(step["from"], inputs, values)
        value = _run_op(step["op"], source_value, step["params"])
        if len(json.dumps(value, ensure_ascii=False, default=str).encode("utf-8")) > MAX_INPUT_BYTES:
            raise ValueError("نتيجة إحدى الخطوات تجاوزت حد الذاكرة")
        values[step["id"]] = value
    return {"skill": spec["name"], "result": values[spec["output"]],
            "steps_completed": len(spec["steps"]), "runtime": RUNTIME_ID}


def create_skill(name, description, steps, inputs=None, output=None):
    raw = {"name": name, "description": description, "inputs": inputs or {},
           "steps": steps, "output": output or (steps[-1].get("id") if steps else None)}
    spec = validate_manifest(raw)
    import gzip, hashlib, uuid, datetime
    slug = re.sub(r"[^a-z0-9-]+", "-", name.lower()).strip("-")[:45] or "native-skill"
    slug += "-" + uuid.uuid4().hex[:8]
    manifest = {**spec, "id": slug, "source_url": "local-native://" + slug,
                "execution": "safe-declarative-runtime", "created_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds")}
    summary = spec["description"] or "مهارة قابلة للتنفيذ داخل محرك Spider الآمن"
    folder = store.DATA_DIR / "skills" / slug
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    skill_doc = "# " + spec["name"] + "\n\n" + summary + "\n\nتنفيذ محلي عبر قائمة عمليات آمنة محددة. لا ينفذ Python/JavaScript عشوائياً."
    (folder / "SKILL.md").write_text(skill_doc, encoding="utf-8")
    packed = gzip.compress(json.dumps(manifest, ensure_ascii=False).encode(), compresslevel=9)
    with store.db() as con:
        con.execute("INSERT INTO skills(id,name,source_url,summary,manifest_gzip,created_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)",
                     (slug, spec["name"], manifest["source_url"], summary[:1000], packed))
        con.execute("INSERT INTO brain_events(event_type,detail) VALUES(?,?)", ("skill.native.create", slug))
    return {"id": slug, "name": spec["name"], "runtime": RUNTIME_ID, "manifest": manifest}


def execute_skill(skill_id, inputs):
    import gzip
    with store.db() as con:
        row = con.execute("SELECT manifest_gzip FROM skills WHERE id=?", (str(skill_id),)).fetchone()
    if not row:
        raise ValueError("المهارة غير موجودة")
    try:
        manifest = json.loads(gzip.decompress(row["manifest_gzip"]).decode("utf-8"))
    except Exception as exc:
        raise ValueError("تعريف المهارة تالف") from exc
    if manifest.get("runtime_manifest"):
        manifest = manifest["runtime_manifest"]
    if manifest.get("runtime") != RUNTIME_ID:
        raise ValueError("هذه حزمة معرفة مرجعية وليست مهارة تنفيذية متوافقة مع Spider DSL")
    return execute_manifest(manifest, inputs)
