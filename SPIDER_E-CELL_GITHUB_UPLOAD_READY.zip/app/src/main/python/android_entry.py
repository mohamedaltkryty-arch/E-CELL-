import os
import threading
import time
import urllib.request

_server_thread = None

def start_server(data_dir, native_library_directory=None):
    global _server_thread
    os.environ['SPIDER_DATA_DIR'] = data_dir
    if native_library_directory:
        try:
            from spider.harness_native import stage_native_runtime
            stage_native_runtime(native_library_directory, data_dir)
            os.environ.pop('SPIDER_HARNESS_NATIVE_STAGE_ERROR', None)
        except Exception as exc:
            # Harness is an optional capability; a native-runtime failure must never
            # prevent the existing Spider/E-CELL core and UI from starting.
            os.environ['SPIDER_HARNESS_NATIVE_STAGE_ERROR'] = type(exc).__name__
    from spider import database
    from spider.server import run
    database.init_db()
    if _server_thread is None or not _server_thread.is_alive():
        _server_thread = threading.Thread(target=run, kwargs={'host': '127.0.0.1', 'port': 8765}, daemon=True)
        _server_thread.start()
    for _ in range(100):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8765/api/health', timeout=0.5) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.2)
    raise RuntimeError('تعذر تشغيل نواة SPIDER E-CELL')
