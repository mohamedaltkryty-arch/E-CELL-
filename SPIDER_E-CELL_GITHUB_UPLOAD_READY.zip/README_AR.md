# SPIDER E-CELL — مشروع Android

تطبيق Android يدمج واجهة Spider الأصلية مع نواة E-CELL المبنية بـ Python عبر Chaquopy، ويعمل دون الحاجة إلى Termux بعد تثبيته.

## محتويات الحزمة

- `app/`: تطبيق Android ونواة Python وواجهة Spider.
- `tests/`: اختبارات النواة والذاكرة والمهارات والواجهة.
- `.github/workflows/android-apk.yml`: فحص المصدر وبناء APK آلياً والتحقق منه.
- ملفات Gradle: إعدادات مشروع Android.

## البناء والتنزيل

تُرفع الحزمة المصدرية إلى جذر المستودع باسم `SPIDER_E-CELL_GITHUB_UPLOAD.zip`. عند وصول Push إلى `main`، يستخرج GitHub Actions المشروع، يشغّل اختبارات Python، ثم يبني APK.

بعد نجاح Workflow افتح **Actions**، ثم تشغيل **Build SPIDER E-CELL APK**، ونزّل Artifact باسم `SPIDER-E-CELL-debug-apk`.

## مواصفات APK

- Application ID: `com.spider.ecell`
- Version: `1.2.1`، versionCode `121`
- minSdk 24، compileSdk/targetSdk 35
- JDK 17، Gradle 8.13، Android Gradle Plugin 8.13.2
- Chaquopy 17.2.0، Python 3.11
- ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`

## البيانات والتوقيع

قاعدة SQLite والذاكرة تحفظان داخل مساحة التطبيق الخاصة. البحث على الإنترنت يحتاج اتصالاً. ملف APK الناتج Debug وموقّع بمفتاح بيئة GitHub Actions، ومناسب للاختبار والتثبيت؛ النشر الدائم يحتاج مفتاح توقيع خاصاً.
