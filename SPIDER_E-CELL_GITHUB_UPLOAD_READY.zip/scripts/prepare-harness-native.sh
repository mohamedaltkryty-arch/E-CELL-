#!/usr/bin/env bash
set -euo pipefail

VERSION='v0.3.7'
APK_SHA256='48f8adc984aeb7bc7726cb6ace5f5312ef0052e7c905cc8d0fd7d1c01f72a163'
PROOT_SHA256='cb40a1ced11cee76569b4008a9e478c87883ce831152be4eb9570763b82e580d'
LOADER_SHA256='f149774236db1e69b36cc1e4ed3866c7094db2eee52da0d4956aa63a9bb26929'
URL="https://github.com/dphmoblie/deepseek-harness-android/releases/download/${VERSION}/app-release.apk"
TMP_DIR="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/spider-harness-native"
APK="${TMP_DIR}/dsh-android.apk"
DEST='app/src/main/jniLibs/arm64-v8a'

mkdir -p "$TMP_DIR" "$DEST"
curl --fail --location --retry 3 --retry-all-errors --connect-timeout 30 "$URL" -o "$APK"
printf '%s  %s\n' "$APK_SHA256" "$APK" | sha256sum --check --status

unzip -p "$APK" 'lib/arm64-v8a/libdsh_proot.so' > "$DEST/libdsh_proot.so"
unzip -p "$APK" 'lib/arm64-v8a/libdsh_proot_loader.so' > "$DEST/libdsh_proot_loader.so"
printf '%s  %s\n' "$PROOT_SHA256" "$DEST/libdsh_proot.so" | sha256sum --check --status
printf '%s  %s\n' "$LOADER_SHA256" "$DEST/libdsh_proot_loader.so" | sha256sum --check --status
file "$DEST/libdsh_proot.so" "$DEST/libdsh_proot_loader.so"
